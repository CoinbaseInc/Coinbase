I have read and understand GitHub's Guide to Filing a DMCA Notice.

The following github repo (https://github.com/codemadhorse/java_code) has files related to my companies interview question, more specifically the following:

README.md

SlimeTorpedo.txt

Starship.txt

TestData.txt

The entire solution needs to be removed as the question is owned by ServiceNow as thus the solution should also not be posted, my contact information is below

I have a good faith belief that use of the copyrighted materials described above on the infringing web pages is not authorized by the copyright owner, or its agent, or the law.

I swear, under penalty of perjury, that the information in this notification is accurate and that I am the copyright owner, or am authorized to act on behalf of the owner, of an exclusive right that is allegedly infringed.

Signed

[private]

Thank you
_________________________________

[private] | Director, Development

ServiceNow | Transform IT

[private]
