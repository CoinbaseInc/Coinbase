To Whom It May Concern,

This email is a Notice of Infringement as authorized in § 512© of the U.S. Copyright Law under the Digital Millennium Copyright Act (DMCA). I wish to report an instance of Copyright Infringement.

1. The copyrighted materials, which I contend belong to aheadWorks Co. and appear illegally on https://github.com, are as follows:
http://ecommerce.aheadworks.com/magento-extensions/advanced-reports.html
http://ecommerce.aheadworks.com/magento-extensions/advanced-reports-units/new-vs-returning-customers.html
http://ecommerce.aheadworks.com/magento-extensions/advanced-reports-units/sales-by-coupon-code.html
http://ecommerce.aheadworks.com/magento-extensions/advanced-reports-units/customers-by-country.html
http://ecommerce.aheadworks.com/magento-extensions/checkout-promo.html
http://ecommerce.aheadworks.com/magento-extensions/follow-up-email.html
http://ecommerce.aheadworks.com/magento-extensions/ajax-cart-pro.html
http://ecommerce.aheadworks.com/magento-extensions/one-step-checkout.html
http://ecommerce.aheadworks.com/magento-extensions/rma.html
http://ecommerce.aheadworks.com/magento-extensions/ajax-catalog.html
http://ecommerce.aheadworks.com/magento-extensions/points-and-rewards.html
http://ecommerce.aheadworks.com/magento-extensions/facebook-link.html
http://ecommerce.aheadworks.com/magento-extensions/custom-smtp.html
http://ecommerce.aheadworks.com/magento-extensions/better-thank-you-page.html
http://ecommerce.aheadworks.com/magento-extensions/help-desk-ultimate.html
http://ecommerce.aheadworks.com/magento-extensions/market-segmentation-suite.html
http://ecommerce.aheadworks.com/magento-extensions/mobile-order-tracking.html
http://ecommerce.aheadworks.com/magento-extensions/iphone-theme.html
http://ecommerce.aheadworks.com/magento-extensions/refer-a-friend.html
http://ecommerce.aheadworks.com/magento-extensions/sociable.html
http://ecommerce.aheadworks.com/magento-extensions/subscriptions-and-recurring-payments.html

2. The unauthorized materials appear at the website address:
https://github.com/georgi-kovachev/HCFExtension/tree/b477bbb94eaf4f33686bac5b97f6e311c1f08667/app/code/local/AW
https://github.com/ibobriakov/escape/tree/b8c861202a265e23945a81341744caede908faf2/build/app/code/local/AW

aheadWorks Blog is included into the specified theme without consent of the copyright holder. aheadWorks did not authorize the use of its product in this case.

3. My contact information is as follows:

[private]

4. I have a good faith belief that use of the copyrighted materials as described above is not authorized by the copyright owner, its agent, or the law.

5. I swear, under penalty of perjury, that the information in the notification is accurate and that I am the copyright owner or am authorized to act on behalf of the owner of an exclusive right that is allegedly infringed.

Signed: [private]
