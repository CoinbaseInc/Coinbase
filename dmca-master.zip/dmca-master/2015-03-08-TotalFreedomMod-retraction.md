Dear GitHub Copyright Agent:

I, the undersigned, represent the staff and players of TotalFreedom
L.L.C. and other affiliates. It has come to our attention that there
has been a mistake in our findings and does not violate the
"TotalFreedomMod" license, and therefore, the repository identified
below is not in violation of U.S. Copyright laws, in particular
section(s) 1201(a)(2) and/or 1201(b)(1) of Title 17 of the United
States Code, commonly referred to as the Digital Millennium Copyright
Act, or "DMCA".

We request that the following repositories be brought back to GitHub:
-https://github.com/RFreedomContents/RFreedomModv2.0-DONT-REMOVE-THIS

(Entire Repository)

[...]

[private]
