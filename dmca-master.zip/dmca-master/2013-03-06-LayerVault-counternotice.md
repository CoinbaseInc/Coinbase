[private]

[private]

tel: [private]

email: info@designmodo.com and [private]

http://designmodo.github.com/Flat-UI/

https://github.com/github/dmca/commit/735e17614cca63102b8414ed2846c3effbfe9535

By typing or otherwise writing my name here, I [private] managing partner at Designmodo, do represent and warrant, under the penalty of perjury, that I believe, in good faith, that the material I have identified above was only removed or disabled as the result of a mistake or misidentification. My submission of this form signifies my consent to
the jurisdiction of the Federal District Court for the judicial district in which the address I have furnished above is located, or, if the address I provided above is outside the United States. I understand that by typing or otherwise writing my name above I am providing an electronic signature that is in all ways equivalent to providing a physical signature on a tangible legal document.

[private]