Counter DMCA Sulake
Date: March 22, 2015

DMCA Link: https://github.com/github/dmca/blob/master/2015-03-20-Sulake.md

Repository Link: https://github.com/xesau/raycms

Dear GitHub Copyright Agent,

I have read and understand GitHub's Guide to Filing a DMCA Counter Notice
and swear, under penalty of perjury, that I have a good-faith belief that
the material was removed or disabled as a result of a mistake or
misidentification of the material to be removed or disabled. I consent to
the jurisdiction of Federal District Court for the judicial district in
which my address is located (if in the United States, otherwise the
Northern District of California where GitHub is located), and I will
accept service of process from the person who provided the DMCA
notification or an agent of such person. My signature is attached to this
e-mail.

The repository of RayCMS (https://github.com/xesau/raycms) does not
contain ANY code, and/or content that is connected to Sulake Corporation
Ltd (hereinafter "Sulake"). We request to put the repository back online.

Please don't hesitate to contact me for further information and/or questions.

Truthfully,

[REDACTED]
