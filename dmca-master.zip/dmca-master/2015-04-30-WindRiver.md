Notification of Claimed Copyright Infringement
(Digital Millennium Copyright Act, 17 U.S.C. Â§ 512)
To: GitHub
1. Name of copyright holder: Wind River Systems, Inc.

2. Name of person authorized to act on behalf of copyright holder: [REDACTED]

3. Identify the copyrighted work claimed to have been infringed: Proprietary source code VxWorks. The source code for VxWorks has directly been copied by the user.

4. Identification of the material that is claimed to be infringing or to be the subject of infringing activity that is to be removed or access to which is to be disabled:
The website provides unauthorized access to proprietary source code VxWorks

https://github.com/Abner-Sun/vx6.8_modification

5. GitHub user: AbnerSun: https://github.com/Abner-Sun/

6. Name of complaining party: Wind River Systems, Inc.

7. Address: [REDACTED]

8. Phone: [REDACTED]

9. E- mail: [REDACTED]

I hereby affirm I have read and understand GitHub's Guide to Filing a DMCA Notice.

I hereby affirm, I have a good faith belief that use of the copyrighted materials described above on the infringing web pages is not authorized by the copyright owner, or its agent, or the law.

I hereby swear, under penalty of perjury, that the information in this notification is accurate and that I am the copyright owner, or am authorized to act on behalf of the owner, of an exclusive right that is allegedly infringed.

[REDACTED]

Signature of person authorized to act

Date: April 28, 2015
