TAKEDOWN NOTICE PURSUANT TO THE DIGITAL MILLENNIUM COPYRIGHT ACT OF 1998

Dear Sir or Madam,

This is a notice in accordance with the Digital Millennium Copyright Act of 1998 requesting that you immediately cease to provide access to copyrighted material.

The original material is located at the following URLs:

https://www.coingateway.net

The infringing material is located at the following URLs:

https://github.com/CheckoutCrypto/site/blob/d328edf088dfbd440f92e3e87c26216648779030/modules/CheckoutCrypto/ccAccount/includes/cc-php/cc.inc

https://github.com/CheckoutCrypto/site/blob/d328edf088dfbd440f92e3e87c26216648779030/modules/CheckoutCrypto/ccGroup/ccGroup.install

https://github.com/CheckoutCrypto/site/blob/d328edf088dfbd440f92e3e87c26216648779030/modules/CheckoutCrypto/ccGroup/includes/cc-php/lib.inc

https://github.com/CheckoutCrypto/site/blob/7c7339fce304f69b991748226fba73195a2480ad/modules/CheckoutCrypto/ccGroup/includes/cc-php/lib.inc~

https://github.com/CheckoutCrypto/site/blob/d328edf088dfbd440f92e3e87c26216648779030/modules/CheckoutCrypto/ccBalance/ccBalance.module

https://github.com/CheckoutCrypto/site/blob/d328edf088dfbd440f92e3e87c26216648779030/modules/CheckoutCrypto/cgTrading/includes/service.inc

https://github.com/CheckoutCrypto/site/blob/d328edf088dfbd440f92e3e87c26216648779030/modules/CheckoutCrypto/ccOTP/includes/forms.inc

https://github.com/CheckoutCrypto/site/blob/d328edf088dfbd440f92e3e87c26216648779030/modules/CheckoutCrypto/cgTrading/includes/layout.inc

https://github.com/CheckoutCrypto/site/blob/d328edf088dfbd440f92e3e87c26216648779030/modules/CheckoutCrypto/cgTrading/theme/style_trans.css~

https://github.com/CheckoutCrypto/site/blob/d328edf088dfbd440f92e3e87c26216648779030/modules/CheckoutCrypto/cgTrading/includes/forms.inc

https://github.com/CheckoutCrypto/site/blob/d328edf088dfbd440f92e3e87c26216648779030/modules/CheckoutCrypto/cgTrading/includes/api.inc

https://github.com/CheckoutCrypto/site/blob/d328edf088dfbd440f92e3e87c26216648779030/modules/CheckoutCrypto/ccBalance/includes/cc-php/table.inc

https://github.com/CheckoutCrypto/site/blob/d328edf088dfbd440f92e3e87c26216648779030/modules/CheckoutCrypto/ccOTP/templates/otp.tpl.php

https://github.com/CheckoutCrypto/site/blob/d328edf088dfbd440f92e3e87c26216648779030/modules/CheckoutCrypto/cgTrading/includes/cc.inc

https://github.com/CheckoutCrypto/site/blob/d328edf088dfbd440f92e3e87c26216648779030/modules/CheckoutCrypto/ccCoin/ccCoin.install

https://github.com/CheckoutCrypto/site/blob/d328edf088dfbd440f92e3e87c26216648779030/modules/CheckoutCrypto/ccOTP/includes/mail.inc

https://github.com/CheckoutCrypto/site/blob/d328edf088dfbd440f92e3e87c26216648779030/modules/CheckoutCrypto/ccStore/includes/cc-php/cc.inc

https://github.com/CheckoutCrypto/site/blob/d328edf088dfbd440f92e3e87c26216648779030/modules/CheckoutCrypto/cgTrading/cgTrading.module

https://github.com/CheckoutCrypto/site/blob/d328edf088dfbd440f92e3e87c26216648779030/.gitignore

https://github.com/CheckoutCrypto/site/blob/d328edf088dfbd440f92e3e87c26216648779030/modules/CheckoutCrypto/cgPopup/cgPopup.info

https://github.com/CheckoutCrypto/site/blob/d328edf088dfbd440f92e3e87c26216648779030/modules/CheckoutCrypto/cgTrading/cgTrading.info

https://github.com/CheckoutCrypto/site/blob/d328edf088dfbd440f92e3e87c26216648779030/modules/CheckoutCrypto/ccBalance/includes/cc-php/api.inc

https://github.com/CheckoutCrypto/site/blob/7c7339fce304f69b991748226fba73195a2480ad/modules/CheckoutCrypto/ccCoin/includes/cc-php/api.inc~

https://github.com/CheckoutCrypto/site/blob/d328edf088dfbd440f92e3e87c26216648779030/modules/CheckoutCrypto/ccCoin/includes/cc-php/api.inc

https://github.com/CheckoutCrypto/site/blob/d328edf088dfbd440f92e3e87c26216648779030/modules/CheckoutCrypto/ccTransactions/includes/table.inc

https://github.com/CheckoutCrypto/site/blob/d328edf088dfbd440f92e3e87c26216648779030/modules/CheckoutCrypto/ccWallets/includes/table.inc

https://github.com/CheckoutCrypto/site/blob/d328edf088dfbd440f92e3e87c26216648779030/modules/CheckoutCrypto/cgTrading/includes/table.inc

https://github.com/CheckoutCrypto/site/blob/d328edf088dfbd440f92e3e87c26216648779030/modules/CheckoutCrypto/cgTrading/theme/style_trans.css

My contact information is:

Company: CoinGateway LIMITED
[REDACTED]

E-mail address: [REDACTED]


You can reach me at [REDACTED] for further information or clarification. My phone number is [REDACTED]

I have a good faith belief that the use of the described material in the manner complained of is not authorized by the copyright owner, its agent, or the law.

I swear that the information in the notification is accurate and, under penalty of perjury, that I am the copyright owner or am authorized to act on behalf of the owner of an exclusive right that is allegedly infringed.

Date: January 23, 2015
