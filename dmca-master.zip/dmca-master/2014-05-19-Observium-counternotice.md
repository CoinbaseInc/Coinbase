Hi Folks,

I've just received a DMCA takedown notice for this repo due to alleged
copyright infringement. As per your Counter-notification policy I am
providing you the required information.

1. Physical or electronic signature:

    [image: Inline image 1]

    Alternatively, [private]

2. Location of material that has been disabled is

    https://github.com/laf/librenms/

3. I swear under the penalty of perjury that I have a good faith belief
that none of the code at

    https://github.com/laf/librenms/compare/issue-laf-32 and

    https://github.com/laf/librenms/commit/dc2503a2ff1c16807ccfa0d5227bb25232282f7e

infringes
on Observium's copyrights and that their take down request is in error. The
links provided to Observium's work don't function but having been made
aware of a claim like this before then I am confident I'm aware of which
code they claim is copyrighted. 95% of the code within this issue that has
changed is either taken from http://uk.php.net or is previously used within
the code base (librenms is a fork of Observium from a GPL compatible
version). I also don't believe that enough information has been provided to
accurately work out which code is claimed as copyright as the code linked
to contains existing code from when the project was forked.

4.
[private]

I [private] consent for any judicial district in which GitHub may be
found, and that I will accept service of process from the person who
provided notification or an agent of such person.

Kind Regards,

[private]
