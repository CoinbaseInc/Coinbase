Cyveillance represents Qualcomm in protecting their security interests
online. You received a request from us to remove content on October 27,
2014 at 2:54 PM EST for the following URLs:

https://github.com/abhishekkeshri/vuforia-project/blob/master/src/com/qualcomm/QCARSamples/CloudRecognition/model/Book.java
https://github.com/joseguru/Will.i.reach/blob/master/jni/VideoPlayback.cpp
https://github.com/airgames/vuforia-gamekit-integration/blob/master/ImageTargets/build/include/QCAR/Trackable.h
https://github.com/cctsao1008/sdcc/blob/master/sdcc_api.h

We are rescinding our request and ask that you discontinue all action
related to this request. Please provide confirmation of receipt of this
notice and the cessation of action.

Thank you for your cooperation.

Regards,

[private]
