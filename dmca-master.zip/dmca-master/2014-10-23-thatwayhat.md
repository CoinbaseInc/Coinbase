Dear Sirs:

Please remove all of the code on this page: https://github.com/chrisblythe812/hat

The entire repository is a copy of our proprietary code off our server. It may have been taken from ourunfuddle account by one of our many odesk contractors. We suspect [private] who worked for us under an alias, [private]. Neither [private] nor [private] is a person I hired or a name Irecognize.

1.& 2. The code is my copyrighted code. You can see it says “Committing thatwayhat project to github”. Thatwayhat.com is a website registered to me, [private]. Thecode includes a copy of the thatwayhat.com

But he did not just put the code from thatwayhat.com onto github, but also all the code from my server, including for my other websites (registered to me)they include:thatwayhat.comdittocart.com , goal2020.com , hapful.com, 22hapful.com, and mydirectories for hats and jewelry (such as directory.thatwayhat.com )and my sql and my readme with the password he added, and my forumcode.

All of these are websites registered to me and my copyrighted code.

3.You can contact me [private]. 

4. I don't know of other infringingwebsites other than github

5. "I have a good faith belief that use of the copyrighted materials described above on the infringing web pages is not authorized by the copyright owner, or its agent, or the law."

6. "I swear, under penalty of perjury, that the information in this notification is accurate and that I am the copyright owner, or am authorized to act on behalf of the owner, of an exclusive right that is allegedly infringed."

Thanks,

[private]
