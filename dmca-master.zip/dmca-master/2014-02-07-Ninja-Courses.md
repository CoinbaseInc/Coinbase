GitHub Inc,

The repository at https://github.com/ucb-ist-eas/Ninja is a private repository that is licensed for private use, but was temporarily published publicly (as of Feb 3rd, 2014) without my consent. The repository has been corrected to be a private repository, but there are three public forks that are unauthorized, and should be take down:

https://github.com/dotasif/Ninja

https://github.com/seidu626/Ninja

https://github.com/venturanima/Ninja

This letter is official notification under the provisions of Section 512(c) of the Digital Millennium Copyright Act ("DMCA") to effect removal of the above-reported infringements.

I have a good faith belief that use of the copyrighted materials described above on the infringing web pages is not authorized by the copyright owner, or its agent, or the law. 

I swear, under penalty of perjury, that the information in this notification is accurate and that I am the copyright owner, or am authorized to act on behalf of the owner, of an exclusive right that is allegedly infringed.

/s/ [private]

Ninja Courses LLC

[private]