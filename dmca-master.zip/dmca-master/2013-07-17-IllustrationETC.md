You are infringing my copyright by distributing on github.com Javascripts 
which I, James E. Talmage wrote for use in Adobe Illustrator, which were 
written by me, and for which I hold exclusive copyright as original works. 
This includes all the material on github at:

https://github.com/nvkelso/illustrator-scripts/tree/master/other-authors/james_talmage/JET_PathScripts

There may also be other locations on github.com.

The work was provided to you by one [private]. Mr. [private] has been 
blatantly stealing images, verbatum text, and Javascript downloads from my 
website, IllustrationETC.com without any license or permission whatsoever. 
He has admitted submitting the material to github.com it to me in email 
correspondence when I advised him to take down the same material, which he 
has been posting on his own site, one example of which can be seen here:

http://kelsocartography.com/blog/?p=1885

I have never granted anyone permisson to distribute my work. I have turned 
down every such request I have ever received. I have never received such a 
request from Mr. [private]. He simply has been stealing original work from me, 
and probably from others.

You may contact me regarding this at:

[private]

You MAY NOT use my personal contact information for any other purpose and 
you MAY NOT give it to anyone else, including Mr. Kelso.

Mr. [private]'s email is:

[private]

I have a good faith belief that use of the copyrighted materials described 
above on the infringing web pages is not authorized by the copyright owner, 
or its agent, or the law.

I swear, under penalty of perjury, that the information in this notification 
is accurate and that I am the copyright owner of an exclusive right that is 
allegedly infringed.

[private]
