Upon reflection we have decided we wish to withdraw the DMCA takedown
notice (February 9 2015) for the following repositories:

https://github.com/mukichou/cs241-2

https://github.com/mukichou/CS241-1

https://github.com/mukichou/cs241_mps

https://github.com/sam001040/CS241

https://github.com/wyang40/CS241-1

https://github.com/xiao25/CS241

https://github.com/BtXin/CS241-1

https://github.com/AdonisSaveYourLife/cs241_mps

https://github.com/wsypeter/cs241_mps

https://github.com/altybassarov/cs241_mps

https://github.com/hestendelin/cs241_mps

https://github.com/JeanCGP/cs241_mps

https://github.com/mikewang266/cs241_mps

https://github.com/missAnthrope/cs241_mps

https://github.com/mosaic0123/cs241_mps

https://github.com/mosaic0123/CS241

https://github.com/srikk595/cs241

https://github.com/amshah4/cs241mpx

https://github.com/Svengali0011/CS241-mp3--Fall-2014

https://github.com/Shanni/tilegame

https://github.com/neonmori/KMalloc

https://github.com/burabayev/CS_241

https://github.com/JLLLinn/System-Programming

https://github.com/ranmeng/map-reduce

https://github.com/ranmeng/memory-allocator

https://github.com/XiaowenLin/C-system-programming

https://github.com/karanghai/SystemsProgramming

https://github.com/liuguojun/Course/tree/master/UIUC/cs241

https://github.com/shilb10/Local/tree/master/Documents/School/old_classes/sp_2014/cs241/sbhttch2

[private]

*University of Illinois @ Urbana-Champaign*

[private]

---

Upon reflection we have decided we wish to withdraw the DMCA takedown
notice (February 2nd 2015) for the following repositories:

https://github.com/wyang40/CS233

https://github.com/AdonisSaveYourLife/CS398

https://github.com/mukichou/CS398

[redacted]

https://github.com/fchang1/UIUC-cs398

[private]

*University of Illinois @ Urbana-Champaign*

[private]
