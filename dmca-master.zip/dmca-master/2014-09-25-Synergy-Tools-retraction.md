Hello, I have worked out a settlement with the user, I hereby retract my claim.

[private]

Primary Operations Inner-CircleQuantum Research
(Formerly AngelFireNetworks)
