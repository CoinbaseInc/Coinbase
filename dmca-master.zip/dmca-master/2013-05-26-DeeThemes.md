Dear Sir / Dear Madam,

This is a notice in accordance with the Digital Millennium Copyright Act 
of 1998 requesting that you immediately cease to provide access to 
copyrighted material.

I'm the author and owner of computer software "LivIcons - truly animated 
icon pack" on behalf of DeeThemes.

The original material is located at the following URLs:

http://codecanyon.net/item/livicons-303-truly-animated-vector-icons/4618985

http://livicons.com

Please remove the infringing materials containing DeeThemes’ copyrighted 
material found at the following URLs:

1) https://github.com/vincent-li/svgicon
user: bashao / vincent-li

2) https://github.com/phoenixg/truelove/tree/master/material/livicons
user: phoenixg

I have a good faith belief that use of the copyrighted materials 
described above on the infringing web pages is not authorized by the 
copyright owner, or its agent, or the law.

I swear, under penalty of perjury, that the information in this 
notification is accurate and that I am the copyright owner, or am 
authorized to act on behalf of the owner, of an exclusive right that is 
allegedly infringed.

If you have any further questions or concerns, do not hesitate to 
contact me at the postal address, telephone number, or email address 
indicated below. Thank you.

Sincerely,

*private*