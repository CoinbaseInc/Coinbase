1. identifying the copyrighted work has been infringed:
Pushwoosh iOS SDK:
https://github.com/Pushwoosh/pushwoosh-ios-sdk

Pushwoosh Android SDK:
https://github.com/Pushwoosh/pushwoosh-android-sdk

2. The materials that are infringing copyrighted work #1

GameThrive iOS SDK located at:
https://github.com/GameThrive/ios-push-plugin/

This is a compiled library 99% based on Pushwoosh code without any attribution to Pushwoosh, violating Pushwoosh SDK MIT license.

GameThrive Android SDK located:
https://github.com/GameThrive/android-push-plugin

99% based on Pushwoosh code
Does not even have a license which is a clear violation.

GameThrive samples which incorporate SDK without attribution:
https://github.com/GameThrive/GameThrive-Push-Plugin-Samples

Unity Plugin which incorporate SDK without attribution:
https://github.com/GameThrive/Unity-push-plugin

I look forward this account to be blocked for MIT license violation.

I can be contacted by email: [private]
Phone: [private]
Physical address: [private]

I have a good faith belief that use of the copyrighted materials described above on the infringing web pages is not authorized by the copyright owner, or its agent, or the law.

I swear, under penalty of perjury, that the information in this notification is accurate and that I am the copyright owner, or am authorized to act on behalf of the owner, of an exclusive right that is allegedly infringed.
