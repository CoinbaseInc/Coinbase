I am the creator of a Minecraft mod known as Thaumcraft. I am known as Azanor in the Minecraft community and that is also
my username here on GitHub. You can look at the mod at the Minecraft forums here: 
http://www.minecraftforum.net/forums/mapping-and-modding/minecraft-mods/1292130-thaumcraft-4-1-1-14-updated-20-5-2014.

My copyright notices are clearly displayed at the bottom of the original post in that thread. The code is not open source. 
It has come to my attention that someone has decompiled my code and placed the source here: 
https://github.com/janinko/mctc. 

All the files contained in the mctc repository is the copyrighted source code and art assets of Thaumcraft.

I can be contacted on the above e-mail address [private], or:
[private]

I have a good faith belief that use of the copyrighted materials described above on the infringing web pages is not 
authorized by the copyright owner, or its agent, or the law. I swear, under penalty of perjury, that the information in 
this notification is accurate and that I am the copyright owner, or am authorized to act on behalf of the owner, of an 
exclusive right that is allegedly infringed.

[private]
