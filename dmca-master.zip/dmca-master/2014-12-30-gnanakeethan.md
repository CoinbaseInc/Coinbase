"I have read and understand GitHub's Guide to Filing a DMCA Notice."

ORIGINAL WORK - https://github.com/gnanakeethan/gnanakeethan.github.io

FORK REPO with INFRINGING CONTENT - https://github.com/sukan/gnanakeethan.github.io

FILES/FOLDER SPECIFIC TO INFRINGING MY WORK, - https://github.com/sukan/gnanakeethan.github.io/tree/master/_data

ACTIONS THAT CAN BE TAKEN -
* MAKING THE REPO STANDALONE and ADDING LATEST CHANGES TO LICENSE FROM THE PARENT REPO
* DISLODGING THE REPO FROM PARENT REPO.
* RENAMING THE REPO
* REMOVING THE INFRINGING PARTS

I have a good faith belief that use of the copyrighted materials described above on the infringing web pages is not authorized by the copyright owner, or its agent, or the law.

I swear, under penalty of perjury, that the information in this notification is accurate and that I am the copyright owner, or am authorized to act on behalf of the owner, of an exclusive right that is allegedly infringed.

I have inserted a Picture of my physical signature below. please send a notification if you can't see.

I have included the contact information here,

[telephone] : [private]
[mobile]: [private]
[email] : [private]
[address] : [private].

Please let me know if this is not enough to do the takedown.

Best Regards,
[private]
