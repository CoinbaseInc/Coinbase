the copyright work is the powercoin logo the name & trademark , and the wallet
that all link to our content on website and social media


<<http://www.powercoin.co.uk> >

<<http://www.powercoin-pool.co.uk> >

<<http://www.facebook.com/powercoin> >

<<http://www.twitter.com/powercoinrev> >



here is where the infingment starts on bitcoin talk  with links to the git to
download our stolen
source and replicating our user name with a slight diffrence ours is
powercoin-pow
they used powercoin.pow if you notice ours was set up weeks in advance theres
came online as they released our stolen source



<https://bitcointalk.org/index.php?action=profile;u=233850;sa=showPosts>



https://github.com/powercoin-power/powercoin-binary

also the sourceforge link i mentioned about in the previous email is now closed
as of today !! thanks to there staff and the dmca takedown



my details
[private]


I have a good faith belief that use of the copyrighted materials described above
on the infringing web pages is not authorized by the copyright owner, or its
agent, or the law."


I swear, under penalty of perjury, that the information in this notification is
accurate and that I am the copyright owner, or am authorized to act on behalf of
the owner, of an exclusive right that is allegedly infringed

my signature is attached and also a copy of the first l take down pictures  from
you  and the sourceforge take down picture
