GitHub,

My name is [private] and I work at the Process Type Foundry, a font software company based in Golden Valley, Minnesota USA. We have been notified that your servers are hosting unauthorized files that contains Process Type Foundry font software packages, thereby infringing our copyright in those interests.

The copyrighted and trademarked Process Type Foundry works included in the infringing files is: Klavika.

The infringing files are located on your servers at: 

https://github.com/mabels/Zuul/tree/master/Zuul/public/fonts

I have a good faith belief that use of the copyrighted materials described above on the infringing web pages is not authorized by the copyright owner, or its agent, or the law.

I swear, under penalty of perjury, that the information in this notification is accurate and that I am the copyright owner, or am authorized to act on behalf of the owner, of an exclusive right that is allegedly infringed.

Should you wish to discuss this, please contact me directly.

All the best,

[private]

Process Type Foundry

2505 Kyle Ave N

Golden Valley, MN 55422 USA