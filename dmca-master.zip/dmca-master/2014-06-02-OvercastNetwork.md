A GitHub user is violating copyrights on several of our codebases. Please remove the content. The copyrighted work at issue is three codebases by the names of PGM, Web, and ProjectAres. Below are screenshots

http://i.oc.tc/image/3H462b1S010M
http://i.oc.tc/image/2Z0U3t18223y
http://i.oc.tc/image/3t3v340q0d11

The source code is located at

https://github.com/OvercastNetwork/PGM
https://github.com/OvercastNetwork/Web
https://github.com/OvercastNetwork/ProjectAres

The URLs where our copyrighted material is located include

https://github.com/DancingWalrus/OvercastNetwork

[private]

I have a good faith belief that use of the copyrighted materials described above as allegedly infringing is not authorized by the copyright owner, its agent, or the law.

I swear, under penalty of perjury, that the information in the notification is accurate and that I am the copyright owner or am authorized to act on behalf of the owner of an exclusive right that is allegedly infringed.

[Private]

June 2, 2014
