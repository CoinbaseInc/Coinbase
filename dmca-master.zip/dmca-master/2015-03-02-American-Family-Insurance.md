Good Afternoon GitHub Administrator,

Below is a Copyright claim request for removal of the link listed below from Github.

1. The link below was found to have American Family Insurance corporate confidential information.

o https://gist.github.com/judgedice/5878094

2. [private]

3. American Family Insurance; 6000 American Parkway; Madison WI 53783

4. I have a good faith belief that use of the copyrighted materials described above on the infringing web pages is not authorized by the copyright owner, or its agent, or the law.

5. I swear, under penalty of perjury, that the information in this notification is accurate and that I am authorized to act on behalf of the owner, of an exclusive right that is allegedly infringed.

6. [private; Security Threat Intelligence Unit; American Family Insurance

Thank you,

[private]

