I, the undersigned, state UNDER PENALTY OF PERJURY that:

[1] I am, a person injured, or an agent authorized to act on behalf of a person injured by a violation of the U.S. Copyright laws, in particular section(s) 1201(a)(2) and/or 1201(b)(1) of Title 17 of the United States Code, commonly referred to as the Digital Millennium Copyright Act, or "DMCA";

[2] I May Be Contacted At:

[privste]

[3] I have a good faith belief that the file-downloads identified below (by URL) are unlawful under these laws because, among other things, the files circumvent effective access controls and/or copyright protection measures;

[4] Reason:

Copyrighted material Vectrosity (http://www.starscenesoftware.com/vectrosity.html)

[5] Please act expeditiously to remove the file-downloads found at the following URLs:

https://github.com/benloong/recipes/blob/master/unity-stuff/vectrosity.unitypackage

[6] I have a good faith belief that use of the copyrighted materials described above on the infringing web pages is not authorized by the copyright owner, or its agent, or the law; and

[7] The information in this notice is accurate.

I have read and understand GitHub's Guide to Filing a DMCA Notice. I swear, under penalty of perjury, that the information in this notification is accurate and that I am the copyright owner, or am authorized to act on behalf of the owner, of an exclusive right that is allegedly infringed.
[private]
