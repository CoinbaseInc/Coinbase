Hello,

The following public repository is a full dump of the proprietary codebase that runs http://myreferral.com and as owner of MyReferral LLC I am requesting it be taken down immediately. I was alerted by Amazon security services as my api keys are listed in plaintext in the repo.

Repository URL: 

https://github.com/valeriyr82/live

Private Passwords and AWS Keys: 

https://github.com/valeriyr82/l...cation/configs/application.ini

My Personal Info:

[private]

I have a good faith belief that use of the copyrighted materials described above on the infringing web pages is not authorized by the copyright owner, or its agent, or the law.

I swear, under penalty of perjury, that the information in this notification is accurate and that I am the copyright owner, or am authorized to act on behalf of the owner, of an exclusive right that is allegedly infringed.

Best Regards, [private]
