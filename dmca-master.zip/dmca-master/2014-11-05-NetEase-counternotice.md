Dear GitHub Copyright Agent:

I am [private], the independent developer and copyright holder of “TeamTalk” Software. Recently, my URLs were removed or disabled as a result of mistake. In order to solve this problem, I am submitting the counter notice on my behalf.

Firstly, I have read and understand GitHub's Guide to filing a DMCA Counter Notice.

Secondly, the URL details which has been disabled are shown in below:

https://github.com/mogutt/TTServer

https://github.com/mogutt/TTAndroidClient

https://github.com/mogutt/TTiOSClient

https://github.com/mogutt/TTMacClient

Thirdly, I swear, under penalty of perjury, that I have a good-faith belief that the material was removed or disabled as a result of a mistake or misidentification of the material to be removed or disabled.

The fourth, I consent to the jurisdiction of Federal District Court for the judicial district in which my address is located (if in the united states, otherwise the northern district of California where Github is located), and I will accept service of process from the person who provided the DMCA notification or an agent of such person.

The last, Please find my contact details below:

Name: [private]

Tel: [private]

Add: [private]

Thank you for your kind assistance.

Truthfully,
