Copyright Infringement Notification

Contact Information
Copyright Owner Name: Pragmatic Programmers, LLC.

DMCA Agent:
[REDACTED]

The following works are the copyrighted property of Pragmatic Programmers, LLC.:

https://github.com/maik/pragpub/tree/master/arduino_video_game

A representative list of these works is available at
http://www.pragmaticprogrammer.com

I state UNDER PENALTY OF PERJURY that:

1. Pragmatic Programmers, LLC. is the owner of the works described above, and I am its agent authorized to act on behalf of the owner of an exclusive right that is allegedly infringed;

2. I have a good faith belief that the use of the material in the manner complained of is not authorized by the copyright owner, its agent, or the law; and

3. This notification is accurate.

Nothing in this notification shall serve as a waiver of any rights or remedies of Pragmatic Programmers, LLC. with respect to the alleged infringement, all of which are expressly reserved.

[REDACTED]

Dated this 20th day of April, 2015.=
