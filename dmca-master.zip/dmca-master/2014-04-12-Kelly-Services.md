This letter is provided based on your requested format. Please remove our confidential and proprietary information from your domain. We are the owner/agent of the property and did not authorize distribution. We ask that each of the web pages displaying the information cited be blocked from public view while you conduct your internal investigation.

1. The following GitHub web pages contain confidential and proprietary information that a former employee of Kelly services has posted on your domain:
  
  Script name: Shell/ds_query_locked_account.bat
  Description: (2nd version) This is use to unlock user account when they are found
  Web Site: https://github.com/priendeau/Technical-PorteFolio/commit/3ca3564c99c86802c91d2270585337a3a5426ffc

  Script name: Python/FBN-PC-Tasklist-inspector.py
  Description: Query the Active Directory of the NBC
  Web Site: https://github.com/priendeau/Technical-PorteFolio/blob/e29984bbda9edf09ac74a831d8715be7a6a8b519/Python/FBN-PC-Tasklist-inspecter.py
  
  Script name: Python/LotusNotesDataBaseAccessor.py
  Description: This is used to connect to lotus notes personal mail files(.nsf)
  Web Site: https://github.com/priendeau/Technical-PorteFolio/blob/8d8e6837b424bd01442e51592572b3415b9f7adc/Python/LotusNotesDataBaseAccessor.py
  
2. The confidential and proprietary information posted to those web pages is considered work product and is the property of Kelly Services and our clients. As the owner/agent, we have not authorized distribution of the information located on your domain.

3. [private], Senior Manager, Kelly Global Services and Investigations, [private], [private]

4. [private] - [private]

5. I have a good faith belief that use of the copyrighted materials described above on the infringing web pages is not authorized by the copyright owner, or its agent, or the law.

6. I swear, under penalty of perjury, that the information in this notification is accurate and that I am the copyright owner, or am authorized to act on behalf of the owner, of an exclusive right that is allegedly infringed.

7. [private]
