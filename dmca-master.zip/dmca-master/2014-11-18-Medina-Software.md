I have read and understand GitHub's Guide to Filing a DMCA Notice.

The copyrighted work is our entire iOS RTMP Library functionality, including low level packet synchronization forked from the now legacy repo ( https://github.com/ifallah/RTMPLib ): https://github.com/RobinChao/RTMPLib , https://github.com/jerett/RTMPLib and https://github.com/mobdim/RTMPLib .

The infringing work is a copy of our iOS RTMP Library, available for sale here: www.realtimelibs.com . In the headers of the files you can see the copyright notice of our programmer: "Created by [private] on 10/19/11." and the copyright notice of our company: "Copyright (c) 2011 Medina Software. All rights reserved.".
Based on the contract that we have signed with our clients, no part of our code can be listed publicly and can only be used internally, within one application.

The user needs to remove the entire repository at: https://github.com/RobinChao/RTMPLib , https://github.com/jerett/RTMPLib and https://github.com/mobdim/RTMPLib (forked from https://github.com/ifallah/RTMPLib ) AND any other forked repositories from these ones.

My email address is [private] or [private] . I can be reached at [private] and our physical address is: [private]

I have a good faith belief that use of the copyrighted materials described above on the infringing web pages is not authorized by the copyright owner, or its agent, or the law.

I swear, under penalty of perjury, that the information in this notification is accurate and that I am the copyright owner, or am authorized to act on behalf of the owner, of an exclusive right that is allegedly infringed.

signature: [private], managing partner at Agilio Software (ex Medina Software)

Best regards,
[private]
