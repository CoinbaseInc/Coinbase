This work is an original plugin written by myself as a closed source plugin, It is not public and is decompiled illegally.

https://github.com/Sarabveer/Synergy-Tools/commit/9c6cf6a36ae8a732f6b31f33ae3384651d62d2c6

My details are

[private]

I have a good faith belief that use of the copyrighted materials described above on the infringing web pages is not authorized by the copyright owner, or its agent, or the law.

I swear, under penalty of perjury, that the information in this notification is accurate and that I am the copyright owner, or am authorized to act on behalf of the owner, of an exclusive right that is allegedly infringed.

[private]

Primary Operations Inner-Circle Quantum Research
(Formerly AngelFireNetworks)
