Ladies and gentlemen,

It has come to our attention that certain source code and other information including confidential access keys (the "Information") are publicly available at

https://github.com/icarusz/JDBuildManager/blob/master/config/s3.yml

Jesta Digital GmbH is the exclusive owner of the Information. Therefore, making the Information publicly available infringes the rights of Jesta Digital GmbH, in particular, but not only, the copyrights of Jesta Digital GmbH.

I therefore demand that you

1.) Immediately cease making the information publicly available;

2.) Immediately destroy the Information entirely; and

3.) Identify the person (Username: icarusz) who has uploaded the Information to the github websites.

For the sake of good order, I declare the following:

I have a good faith belief that use of the copyrighted materials described above on the infringing web pages is not authorized by the copyright owner, or its agent, or the law.
I swear, under penalty of perjury, that the information in this notification is accurate and that I am the copyright owner, or am authorized to act on behalf of the owner, of an exclusive right that is allegedly infringed.

The above is not intended to be a full recitation of all facts concerning this matter. This correspondence is not intended, and shall not be construed, to limit, waive or prejudice any rights or remedies that Jesta Digital GmbH may have at law, in equity or otherwise, with respect to any alleged infringement by your company or the users of your service. Any and all such rights and remedies are hereby expressly reserved.
Thank you for your anticipated courtesy and cooperation in this matter.

Kind regards
[private]

[private]
Director Legal and Business Affairs

Phone: [private]
Fax: [private]
Mobile: [private]
E-Mail: [private]

Jesta Digital GmbH, Karl-Liebknecht-Str. 32, 10178 Berlin, Germany
Gesellschaft mit beschränkter Haftung mit Sitz in Berlin
HRB Nr. 97990 Amtsgericht Charlottenburg
Geschäftsführer: [private]
