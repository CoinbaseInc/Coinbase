1. https://github.com/mrejhan/BusBookingOnlineSystem - was forked from a Project that wasposted in error onto Github. The original (https://github.com/heraclex/BusBookingOnlineSystem) work is copyright ALL RIGHTS RESERVED - Civica.Housing Coding. Unfortunately noLicense text accompanied the original product, regardless. Projects areconsidered All Rights Reserved unless otherwise stipulated regardless ofwhere code has been posted.

2. All forked material is infringing & project is infringing

3. You may contact me at this e-mail address "[private]" or under [private]

4. Person that has posted this material cannot be contacted because he didn't public his email contact.

5. I have a good faith belief that use of the copyrighted materialsdescribed above on the infringing web pages is not authorized by thecopyright owner, or its agent, or the law.

6. I swear, under penalty of perjury, that the information in thisnotification is accurate and that I am the copyright owner, or amauthorized to act on behalf of the owner, of an exclusive right that isallegedly infringed.

7. Signed - [private]

If you have anymore questions feel free to respond.
