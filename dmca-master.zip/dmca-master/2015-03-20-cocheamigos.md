Dear Madam/Sir,
I have read and understand GitHub's Guide to Filing a DMCA Notice.

I am the owner of the domain cocheamigos.com and the author of all content related to it. I am using the hosting provided by tsohost.co.uk and I am on the process of registering the brand "cocheamigos".

At the moment there are a couple of public repositories opened called:

https://github.com/meramoroscon/GALLINASLARAMONA and https://github.com/meramoroscon/PROYECTOTEST which contains folders and files called cocheamigos.

I, [private], do not authorize the contents of those two repositories being public.

I, [private], want the entire content of both repositories taken down as soon as possible.

This names have being indexed by google, therefore when someone makes a search for cocheamigos on google, this two repositories appears as results of the search. 

This two repositories were opened as a proof of concept, with a user called meramoroscon linked to one google account which we cannot access to, because we lost the password and the mobile which is linked to recover the password [private], is out of line, due to now we are living in Spain and we shut down that telephone line.

Also this repositories have a contributor which is josetortosacarcelen linked to josel.tortosacarcelen with the password [private] and  he tried to removed that names pushing different names for the solution file and suo file on the repository https://github.com/meramoroscon/GALLINASLARAMONA in order to stop google indexing that names on the different searches for Cocheamigos.

My current home address is:

[private]

Emails: 

[private]

So I am the owner of the repositories but due to I cannot access my user in github I would like to remove that public repositories as soon as you can.

I have a good faith belief that use of the copyrighted materials described above on the infringing web pages is not authorized by the copyright owner, or its agent, or the law.

I swear, under penalty of perjury, that the information in this notification is accurate and that I am the copyright owner, or am authorized to act on behalf of the owner, of an exclusive right that is allegedly infringed.

Thank you for your time and attention,

Kind regards,

[private]
