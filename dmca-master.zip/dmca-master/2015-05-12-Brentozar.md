*I have read and understand GitHub's Guide to Filing a DMCA Notice.*

I have identified the work at
https://github.com/ktaranov/sqlserver-kit/tree/master/First%20Responder%20Kit
to be in violation of the DMCA, relevant copyright, and the EULA for the
software (http://www.brentozar.com/first-aid/sql-server-downloads/).

This work was added in commit
https://github.com/ktaranov/sqlserver-kit/commit/2bdb81a864ad8e0ee969b7b076fdf757e81d62ec

To remedy this infringement, the user (@ktaranov
<https://github.com/ktaranov/>) needs to remove these files and their
history from the git repository.

I have a good faith belief that use of the copyrighted materials described
above on the infringing web pages is not authorized by the copyright owner,
or its agent, or the law.

I swear, under penalty of perjury, that the information in this
notification is accurate and that I am the copyright owner, or am
authorized to act on behalf of the owner, of an exclusive right that is
allegedly infringed.

I may be reached via the following means:

[private]

The following files are infringing:

- https://github.com/ktaranov/sqlserver-kit/blob/master/First%20Responder%20Kit/Catalog%20-%20Onsite%20Training.pdf
- https://github.com/ktaranov/sqlserver-kit/blob/master/First%20Responder%20Kit/Poster%20-%20Bandwidth%20Reference.pdf
- https://github.com/ktaranov/sqlserver-kit/blob/master/First%20Responder%20Kit/Poster%20-%20Dates%20and%20Times%20in%20SQL%20Server.pdf
- https://github.com/ktaranov/sqlserver-kit/blob/master/First%20Responder%20Kit/Poster%20-%20Isolation%20Levels.pdf
- https://github.com/ktaranov/sqlserver-kit/blob/master/First%20Responder%20Kit/Poster%20-%20SQL%20Server%20Failover%20Clustering.pdf
- https://github.com/ktaranov/sqlserver-kit/blob/master/First%20Responder%20Kit/Poster%20-%20SQL%20Server%20Table%20Partitioning.pdf
- https://github.com/ktaranov/sqlserver-kit/blob/master/First%20Responder%20Kit/Poster%20-%20Signs%20Your%20SQL%20Server%20Execution%20Plan%20Needs%20You.pdf
- https://github.com/ktaranov/sqlserver-kit/blob/master/First%20Responder%20Kit/Readme.md
- https://github.com/ktaranov/sqlserver-kit/blob/master/First%20Responder%20Kit/Stored%20Procedures%20-%20Temp%20Versions%20for%20SQL%202005.sql
- https://github.com/ktaranov/sqlserver-kit/blob/master/First%20Responder%20Kit/Stored%20Procedures%20-%20Temp%20Versions%20for%20SQL%202008%20and%20Newer.sql
- https://github.com/ktaranov/sqlserver-kit/blob/master/First%20Responder%20Kit/Video%20Demo%20Scripts%20-%20Reporting%20in%20Production.sql
- https://github.com/ktaranov/sqlserver-kit/blob/master/First%20Responder%20Kit/Worksheet%20-%20First%20Responder%20Checklist.pdf
- https://github.com/ktaranov/sqlserver-kit/blob/master/First%20Responder%20Kit/Worksheet%20-%20High%20Availability%20and%20Disaster%20Recovery%20Planning.pdf
- https://github.com/ktaranov/sqlserver-kit/blob/master/First%20Responder%20Kit/eBook%20-%20AlwaysOn%20Availability%20Groups%20-%20The%20Uneasy%20Button.pdf
- https://github.com/ktaranov/sqlserver-kit/blob/master/First%20Responder%20Kit/eBook%20-%20AlwaysOn%20Availability%20Groups%20Setup%20Checklist.pdf
- https://github.com/ktaranov/sqlserver-kit/blob/master/First%20Responder%20Kit/eBook%20-%20Factors%20of%20Cloud%20Success.pdf
- https://github.com/ktaranov/sqlserver-kit/blob/master/First%20Responder%20Kit/eBook%20-%20How%20to%20Develop%20Your%20DBA%20Career.pdf
- https://github.com/ktaranov/sqlserver-kit/blob/master/First%20Responder%20Kit/eBook%20-%20SQL%20Critical%20Care.pdf
- https://github.com/ktaranov/sqlserver-kit/blob/master/First%20Responder%20Kit/eBook%20-%20SQL%20Server%20DBA%20Training%20Plan.pdf
- https://github.com/ktaranov/sqlserver-kit/blob/master/First%20Responder%20Kit/eBook%20-%20SQL%20Server%20Setup%20Checklist.pdf
- https://github.com/ktaranov/sqlserver-kit/blob/master/First%20Responder%20Kit/eBook%20-%20Solid%20State%20Storage%20for%20SQL%20Server.pdf
- https://github.com/ktaranov/sqlserver-kit/blob/master/First%20Responder%20Kit/sp_AskBrent-CheckID-List.md
- https://github.com/ktaranov/sqlserver-kit/blob/master/First%20Responder%20Kit/sp_AskBrent.sql
- https://github.com/ktaranov/sqlserver-kit/blob/master/First%20Responder%20Kit/sp_Blitz.sql
- https://github.com/ktaranov/sqlserver-kit/blob/master/First%20Responder%20Kit/sp_BlitzCache%20for%20SQL%202005.sql
- https://github.com/ktaranov/sqlserver-kit/blob/master/First%20Responder%20Kit/sp_BlitzCache.sql
- https://github.com/ktaranov/sqlserver-kit/blob/master/First%20Responder%20Kit/sp_BlitzIndex.sql
- https://github.com/ktaranov/sqlserver-kit/blob/master/First%20Responder%20Kit/sp_BlitzRS.sql
- https://github.com/ktaranov/sqlserver-kit/blob/master/First%20Responder%20Kit/sp_BlitzTrace.sql
- https://github.com/ktaranov/sqlserver-kit/blob/master/First%20Responder%20Kit/sp_BlitzT%D0%BE-CheckID-List.md

---
[private]
