1.

The content being infringed upon:

https://github.com/schonstal/escape-mobile

https://github.com/schonstal/ld21

An example of the published work:

https://play.google.com/store/apps/details?id=air.com.kongregate.mobile.games.incredibleape.escape&hl=en

2.

The repository catmanjan/flixel-gdx-escape contains unauthorized and
modified redistributions of copyrighted material that is not under a
permissive license:

https://github.com/catmanjan/flixel-gdx-escape/

(The code can be clearly identified here:
https://github.com/catmanjan/flixel-gdx-escape/tree/master/src/escape)

catmanjan/flixel-gdx-escape-android also contains unauthorized and
modified redistributions of copyrighted material:

https://github.com/catmanjan/flixel-gdx-escape-android/

(The assets can be clearly identified in this example:
https://github.com/catmanjan/flixel-gdx-escape-android/blob/master/assets/pack.png
)

An example of the published work can be found here:

https://play.google.com/store/apps/details?id=au.com.twosquared.escape

3.

My contact information:

   [private]

4.

The email address of the infringer:

   [private]

5.

I have a good faith belief that use of the copyrighted materials
described above on the infringing web pages is not authorized by the
copyright owner, or its agent, or the law.

6.

I swear, under penalty of perjury, that the information in this
notification is accurate and that I am the copyright owner, or am
authorized to act on behalf of the owner, of an exclusive right that is
allegedly infringed.

7.

My digital signature:

   [private]
