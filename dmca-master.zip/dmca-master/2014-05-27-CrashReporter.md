1. My work is not online right now. I had uploaded it to github earlier but have since taken it down. It was in a repository called CrashReporter in my github account tied to email address ([private]).

2. https://github.com/RyanTech/CrashReporter This is a link to the repository that contains my work. Before I had taken it down, he had forked a copy, so now he has a repo of his own that contains all of my code.

3. [private]

4. https://github.com/RyanTech I don’t have the contact information of the user, but this is the link to his github profile.

5. “I have a good faith belief that use of the copyrighted materials described above on the infringing web pages is not authorized by the copyright onwer, or its agent, or the law.”

6. “I swear, under penalty of perjury, that the information in this notification is accurate and that I am the copyright owner, or am authorized to act on behalf of the owner, of an exclusive right that is allegedly infringed.”

7. [private]
