Dear Sir/Madam:

On behalf of The MathWorks, Inc. ("MathWorks") and pursuant to Sections 512(c)(3) and 512(d)(3) of the Copyright Act (17 U.S.C. 512(c)(3) and 512(d)(3)), I am writing to place you on notice of certain infringing materials made available on the GitHub.com web site at the URL 

https://github.com/zku/MatlabDecompiler

I have a good faith belief that the materials identified above infringe at least 17 U.S.C. 1201(a)(2) and/or 1201(b)(1) as they circumvent effective access controls and copyright protection measures of works protected under Title 17 of the United States Code, including MathWorks' MATLAB computer program and related toolbox add-on computer programs. I further swear, under penalty of perjury, that the information in this notification is accurate and that I am authorized to act on behalf of the owner of the exclusive right that is allegedly infringed.

Please act expeditiously to take down these materials, preferably no later than 5PM Eastern Standard Time on Wednesday May 22, 2013. If you have any further questions or concerns, do not hesitate to contact me at the postal address, telephone number, or email address indicated below. Thank you.

Sincerely,

[private]
