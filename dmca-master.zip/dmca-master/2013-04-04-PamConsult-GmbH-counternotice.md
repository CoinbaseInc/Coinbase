Hi,

we?ve received a DCMA takedown notification yesterday (
<https://github.com/github/dmca/blob/master/2013-04-03-PamConsult-GmbH.md>
https://github.com/github/dmca/blob/master/2013-04-03-PamConsult-GmbH.md)
for the public repository https://github.com/ScavixSoftware/WebFramework.



I declare, under penalty of perjury, that I have a good faith belief that
the complaint against me and/or Scavix Software Ltd. & Co. KG of copyright
violation is based on mistaken information, misidentification of the
material in question, or deliberate misreading of the law.

All published files under https://github.com/ScavixSoftware/WebFramework are
covered by GNU Lesser General Public License V3 as described in the files?
headers.



Our contact information is as follows:

Scavix Software Ltd. & Co. KG

[Private]

Am Hornsgehege 6

D-29574 Ebstorf

Germany

Phone: [Private]



I hereby consent to the jurisdiction of Federal District Court for the
judicial district in which I reside (or, if my address is outside the United
States, any judicial district in which you, GitHub, may be found). I agree
to accept service of process from the complainant.



My electronic signature follows:

[Private]






Regards / Mit freundlichen Grüßen
[Private]
Director




 <http://www.scavix.com/>



Scavix Software Ltd. & Co. KG
German High Quality Software Engineering

Am Hornsgehege 6, D-29574 Ebstorf, Germany
Amtsgericht Lüneburg, HRA 201713
 <http://www.scavix.com/> www.scavix.com
General partner: Scavix Software Verwaltungs Ltd.
