Hello,

I have read and understand GitHub's Guide to Filing a DMCA Notice.

As mentioned in the subject, a GitHub user is illegally sharing HTML templates created by us (Medium Rare) for sale on Themeforest (web template, theme marketplace).

The copyrighted works being infringed are:

Pivot HTML template:

http://themeforest.net/item/pivot-responsive-multipurpose-html-with-builder-v141/8748103 

Pangaea HTML template:

http://themeforest.net/item/pangaea-multipurpose-template-with-page-builder/8081993 

The infringing works found on the GitHub page of user natashavlahakis are:

https://github.com/natashavlahakis/themeforest-8748103-pivot-responsive-multipurpose-html-with-builder-v141-2 

https://github.com/natashavlahakis/themeforest-8748103-pivot-multipurpose-template-with-page-builder 

https://github.com/natashavlahakis/themeforest-8081993-pangaea-multipurpose-template-with-page-builder 

This user would be required to completely remove all traces of the above items from their GitHub repositories to remedy the infringement.

My contact details:

[private]

[private]

[private]

I have a good faith belief that use of the copyrighted materials described above on the infringing web pages is not authorized by the copyright owner, or its agent, or the law.

I swear, under penalty of perjury, that the information in this notification is accurate and that I am the copyright owner, or am authorized to act on behalf of the owner, of an exclusive right that is allegedly infringed.

Kind regards,

[private]

Medium Rare
