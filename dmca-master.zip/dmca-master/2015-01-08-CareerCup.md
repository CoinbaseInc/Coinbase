A copy of my book was posted at the following links and I request that it
is removed. The book is "Cracking the Coding Interview" by [private].

-
https://github.com/arthurguima/maratona/blob/master/Facebook/Hacking%20Interviews/Cracking%20the%20Coding%20Interview%2C%204%20Edition%20-%20150%20Programming%20Interview%20Questions%20and%20Solutions.pdf
-
https://github.com/arthurguima/maratona/blob/master/Facebook/Hacking%20Interviews.zip

I swear, under penalty of perjury, that the information in the notification
is accurate and that I am the (copyright) owner or am authorized to act on
behalf of the owner of an exclusive right that is allegedly infringed.

I have a good faith belief that use of the copyrighted materials described
above as allegedly infringing is not authorized by the copyright owner, its
agent, or the law.

*I have read and understand GitHub's Guide to Filing a DMCA Notice.*

Thank you for your consideration.

[private]

Founder / CEO, CareerCup.com

Author of Cracking the Coding Interview

Contact Information: [private]
