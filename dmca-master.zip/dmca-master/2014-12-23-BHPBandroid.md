Pursuant to 17 USC 512(c)(3)(A), this communication serves as a statement that:

1. I am the duly authorized representative of the exclusive rights holder for the 'BHPBandroid' document being made available through your website.

2. These exclusive rights are being violated by material available upon your site at the following URL(s):

https://github.com/jeuelc/BHPBandroid?<https://bitbucket.org/jmackritis/escalationform/src/baad3d1b4b3d?at=default>

I have a good faith belief that the use of this material in such a fashion is not authorized by the copyright holder, the copyright holder's agent, or the law;

3. Under penalty of perjury in a United States court of law, I state that the information contained in this notification is accurate, and that I am authorized to act on the behalf of the exclusive rights holder for the material in question;

4. I may be contacted by the following methods:

Name: [private]

Title: Security Compliance Lead - GBIS Security

Email:  [private]

Phone: [private]

Address:

BHP Billiton
Marina Bay Financial Centre
Tower 2 - level 46
10 Marina Boulevard
Singapore 018983

I hereby request that you remove or disable access to this material as it appears on your service in as expedient a fashion as possible. Thank you.

Regards,?

[private] (contractor)
SIS Security Operations, Group Business Information Systems
BHP Billiton Marketing Asia Pte Ltd 10 Marina Bay Financial Centre Tower 2, Singapore
