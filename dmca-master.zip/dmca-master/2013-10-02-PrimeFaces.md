Hi,

I have a good faith belief that use of the copyrighted materials described above on the infringing web pages is not authorized by the copyright owner, or its agent, or the law.

I swear, under penalty of perjury, that the information in this notification is accurate and that I am the copyright owner, or am authorized to act on behalf of the owner, of an exclusive right that is allegedly infringed.

This is a infringement report following;

https://help.github.com/articles/dmca-takedown

As an overview, PrimeFaces is a UI library for JavaServer Faces framework consisting of an open source version and the closed source commercial version (Elite). We also provide the sources for the clients who purchase the commercial version. Problem is a user with Elite subscription is distributing the releases from GitHub.

1) It is the Elite Releases of PrimeFaces that are subject to infringement

http://www.primefaces.org

http://www.primefaces.org/downloads.html

These can only be accessed by paying customers.

License does not permit redistribution;

http://www.primefaces.org/elite/license.xhtml

2) So called unofficial PrimeFaces project at GitHub is providing download links;

http://primefaces.github.io

https://github.com/primefaces

3) [private]

4) http://primefaces.github.io

and

https://github.com/primefaces

5) I have a good faith belief that use of the copyrighted materials described above on the infringing web pages is not authorized by the copyright owner, or its agent, or the law.

6) I swear, under penalty of perjury, that the information in this notification is accurate and that I am the copyright owner, or am authorized to act on behalf of the owner, of an exclusive right that is allegedly infringed.

7) Attached is the company stamp.

Regards,

[private]

PrimeFaces Lead

PrimeTek Informatics

www.primefaces.org
