We are the exclusive rights holder for the artwork contained within Flat UI (http://designmodo.com/flat/); These exclusive rights are being violated by material available upon your site at the following URL:

https://github.com/kendugu/flat-ui-p

I have a good faith belief that use of the copyrighted materials described above as allegedly infringing is not authorized by the copyright owner, its agent, or the law.

I swear, under penalty of perjury, that the information in the notification is accurate and that I am the copyright owner or am authorized to act on behalf of the owner of an exclusive right that is allegedly infringed.

I hereby request that you remove or disable access to this material as it appears on your service in as expedient a fashion as possible. Thank you.

Regards,

[private]

[private]

Designmodo Inc.

Email: info@designmodo.com
