Hi,

Below are the required details for DMCA removal.

1. Copyright infringement is being claimed against this copyrighted work.

Work Description: Shipping Details Plugin for WooCommerce

Copyright Owner: PatSaTECH
Copied From:
http://codecanyon.net/item/shipping-details-plugin-for-woocommerce/2018867

2. The claimed infringing material is located at the following links.

Material Location:
https://github.com/alexxxa/Shipping-Details-Plugin-for-WooCommerce <http://progsfiles.com/download/5/aHR0cDovL2xldGl0Yml0Lm5ldC9kb3dubG9hZC82OTMzMS42MThlOTQxNTZiYjg4ODRlZjI5MWE3NDUwYjU3L3NoaXBwaW5nLWRldGFpbHMtcGx1Z2luLWZvci13b29jb21tZXJjZV92MS42LnJhci5odG1s>

3. Contact information related to this claim:

Company: PatSaTECH

Name: [private]

Mailing Address: A-402, Heera Manek Residency CHS Ltd,

S N Mehta Marg, Maneklal Estate, Ghatkopar West,
Mumbai - 400086.

Telephone Number: [private]

Email Address: [private]

I hereby state that I have a good faith belief that the disputed use of the
copyrighted material is not authorized by the copyright owner, its agent,
or the law (e.g., as a fair use).

I hereby state that the information in this Notice is accurate and, under
penalty of perjury, that I am the owner, or authorized to act on behalf of,
the owner, of the copyright or of an exclusive right under the copyright
that is allegedly infringed.

Regards,
[private]
