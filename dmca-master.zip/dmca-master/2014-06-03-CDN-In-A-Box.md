It has come to my attention that GitHub is hosting on behalf of Stremor
several copies of "CDN IN A BOX" ( www.cdninabox.com
<http://www.cdninabox.com> ) which I am the copyright holder of and which
StremorCorp is not a licensee of.

StremorCorp has several Git Repos that contain "CDN In A Box" "Cache.py"
"UnUnicode.py" and derivatives such as "Stremor-Cache".

StremorCorp Additionally has unlicensed work product contained in AnswerBot,
BW_Magic, Coz, LiquidHelium, NLI, Stremor-LHE-Tools, Stremor-Qop

I have a good faith belief that use of the copyrighted materials described
above on the infringing web pages is not authorized by the copyright owner,
or its agent, or the law.

I swear, under penalty of perjury, that the information in this notification
is accurate and that I am the copyright owner, or am authorized to act on
behalf of the owner, of an exclusive right that is allegedly infringed.

[private]

I may be contacted at:

[private]

Stremor Corp can be contacted at:

[private]
