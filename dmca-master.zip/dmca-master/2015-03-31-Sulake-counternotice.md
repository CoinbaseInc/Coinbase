https://github.com/github/dmca/blob/master/2015-03-20-Sulake.md

https://github.com/xesau/raycms

Dear Github,

I have read and understand GitHub's Guide to Filing a DMCA Counter Notice.
I swear, under penalty of perjury, that I have a good-faith belief that the
material was removed or disabled as a result of a mistake or
misidentification of the material to be removed or disabled.

The probable reason Sulake Oy. marked my repository as copyright
infringement, is because the headers and the README.md file contained the
word Habbo. I assume they have, without further investigation, thought that
my project was, as they state in their DMCA notice, was "designed to bypass
technological protection measures that protect our product Habbo Hotel",
which it, I swear, doesn't. The reason the headers and the README.md file
contained the word Habbo, is because in an early stage the project
functioned as a system to manage Habbo styled site, but as progress was
made, the system grew out to a generic website CMS, like WordPress and
Joomla!, yet the README.md file and the headers were not updated and have
been copy-pasted during development. When the lock on the repository is
released, I will update every single file and remove the confusing sentences
to prevent further misconception.

The repository does not contain and has never contained any copyright
infringing material.

I consent to the jurisdiction of Federal District Court for the judicial
district in which my address is located the Northern District of California,
and I will accept service of process from the person who provided the DMCA
notification or an agent of such person.

Please send me a confirmation when you have re-enabled access to this
material.

The following linked image is a representation of my physical signature

[private]

[private]
