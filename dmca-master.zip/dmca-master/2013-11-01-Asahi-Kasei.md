Dear Sirs/Madame,

We, Asahi Kasei Microdevices Corporation, found our copyrighted software and files are placed on your web site without our permission. Please delete these  materials from your web site immediately. The following are the information instructed in the “DMCA Takedown":

1. The identification of the copyrighted work we believe has been infringed:

   The DOE compensation software owned by Asahi Kasei Microdevices Corporation, with an office at 1-105 Kanda Jinbocho, Chiyoda‐ku, Tokyo 101‐8101, Japan. Information about the DOE compensation software may be found here:

   http://www.akm.com/en/product/detail/0001

2. The identification of the material that we allege is infringing upon the copyright work listed in item #1 above:

   The following GitHub links contain the above DOE compensation software owned by Asahi Kasei Microdevices Corporation:

   https://github.com/Zmeya/StarV1277/tree/5cf89ccf425bc4654171db80b1f248d972494a68/mediatek/source/hardware/sensor/lib/akmd8963

   https://github.com/Zmeya/StarV1277/tree/5cf89ccf425bc4654171db80b1f248d972494a68/mediatek/source/hardware/sensor/lib/akmd8975

   https://github.com/asturel/android_device_zte_v970/tree/b56cfdbc21493813038cd6d23379859b3cf1840c/sensor/lib/akmd8963

   https://github.com/Surf1011/android_hardware_rk29/tree/df8ffb49c4b04cf5a4d4b1a8103c72586d916f5a/sensor/normal/akm8975

   https://github.com/azhe12/azhe_code/tree/a54b5957c26b58dd1a83590e0112f926a5a327a4/summary/sensor%E6%80%BB%E7%BB%93/sensorporting/akm8975_huashan

3. Contact Person:

   [private]

   ASAHI KASEI MICRODEVICES CORPORATION
   1-105 Kanda Jinchobo, Chiyoda-ku, Tokyo   , Japan 101-8101

   [private]

   [private]

4. Address of infringing owner/administator:

   Unknown

5. We have a good faith belief that the use of the copyrighted materials described above on the infringing webpages is not authorized by the copyright owner, or its agent, or the law.

6. We swear, under penalty of perjury, that the information in this notificiation is accurate and that we are the copyright owner, or are authorized to act on behalf of the owner, of an exclusive right that is allegedly infringed.

Sincerely,

[private]

General Manager, Multi-Sensors, Sensing Products Division

Asahi Kasei Microdevices Corporation
