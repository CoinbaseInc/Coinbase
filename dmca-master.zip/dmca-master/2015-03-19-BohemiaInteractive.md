Dear Madam or Sir,

I have read and understand GitHub's Guide to Filing a DMCA Notice.

I act on behalf of BOHEMIA INTERACTIVE a.s. and place you on notice that:

Company BOHEMIA INTERACTIVE a.s. (“the Owner”) is the exclusive owner of
the copyrights in and to the Arma: Cold War Crisis (Arma: Cold War
crisis has been previously known as Operation Flashpoint: Cold War
Crisis) game and the text, artwork, logos and photographs appearing
therein (singly and collectively, the “Arma Material”).

Following link/server (“Infringing Material”) contains unauthorized
copies of the Arma Material, unauthorized derivative works of the Arma
Material and/or original source code of the Arma Material which infringe
the Arma Material and the exclusive rights of the Owner:

https://github.com/galek/OperationFlashPoint

Please immediately remove or disable all access to the Infringing
Material to remedy the infringement.

I hereby state that I have a good faith belief that the disputed use of
the copyrighted material is not authorized by the copyright owner, its
agent, or the law (e.g., as a fair use).

I hereby state that the information in this Notice is accurate and,
under penalty of perjury, that I am the owner, or authorized to act on
behalf of, the owner, of the copyright or of an exclusive right under
the copyright that is allegedly infringed.

Should you require any further information regarding this matter, please
contact me at the address or email address indicated below.

Yours faithfully,

[REDACTED]  
Legal Department

*Bohemia Interactive a.s.*  
[REDACTED]

Email: [REDACTED]
