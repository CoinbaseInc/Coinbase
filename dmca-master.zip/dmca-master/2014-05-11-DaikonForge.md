The repository at

https://github.com/PedroMR/SpinnyNinja/tree/master/Assets/Daikon%20Forge 

is in violation of the Digital Millenium Copyright Act.


If you look within the majority of the source code files, you will see that
they are part of a copyrighted commercial product. Additionally, the
product (link <http://www.daikonforge.com/dfgui>) can only be legally
purchased on the Unity Asset Store (link <http://u3d.as/5dQ>), which has an
End-User License Agreement that specifically forbids distribution of the
source code (link <http://unity3d.com/company/legal/as_terms>).

As the copyright holder I am requesting that this content be removed or
made private. Publicly posting the source code for everyone to access is
clearly against the license agreement under which the software was
purchased, and is a clear violation of copyright law.

This repository appears to belong to PedroMR, who does not list a contact
email on his GitHub page.

I have a good faith belief that use of the copyrighted materials described
above on the infringing web pages is not authorized by the copyright owner,
or its agent, or the law.

I swear, under penalty of perjury, that the information in this
notification is accurate and that I am the copyright owner, or am
authorized to act on behalf of the owner, of an exclusive right that is
allegedly infringed.

[private]

Signed,

[private]
