Takedown Notice under DMCA

Date: April 09, 2014

Dear GitHub Copyright Agent:

I, the undersigned, state UNDER PENALTY OF PERJURY that:

[1] I am, a person injured, or an agent authorized to act on behalf of a 
person injured by a violation of the U.S. Copyright laws, in particular 
section(s) 1201(a)(2) and/or 1201(b)(1) of Title 17 of the United States 
Code, commonly referred to as the Digital Millennium Copyright Act, or 
"DMCA";

[2] I May Be Contacted At:

Name of Injured Party : X-PRESSIVE.COM Games & Multimedia

Name and Title: [private]

Company: X-PRESSIVE.COM Games & Multimedia

Address: [private]

Email address [private]

Telephone: [private]

[3] I have a good faith belief that the file-downloads identified below (by 
URL) are unlawful under these laws because, among other things, the files 
circumvent effective access controls and/or copyright protection measures;

[4] Reason:

Content Type: LUA source code library / LUA extension for Corona Mobile SDK

Violation(s): The source code posted on this GitHub page (URL see below) is 
under commercial distribution by X-PRESSIVE.COM / [private] and must not 
be published in plain, readable format (to be published as part of compiled, 
binary and executable code only). Publishing this file is a copyright 
infringement and against it's usage licence.

[5] Please act expeditiously to remove the file-downloads found at the 
following URLs:

https://github.com/DHdez/BirDoodle/blob/master/widget_candy.lua

[6] I have a good faith belief that the circumvention of effective access 
controls and/or copyright protection measures identified above is not 
authorized by law; and

[7] The information in this notice is accurate.

Thank you for your kind assistance.

Truthfully,

[private]
