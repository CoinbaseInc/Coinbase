Dear Github staff, 

My name is [private] and I am the President & CEO of Delicious Brains Inc. A web page that your 
company hosts is infringing on at least one copyright owned by my company. 
 
Our written work has been copied onto your servers without permission. The original written work to which 
we own the exclusive copyrights can be found at: 
 
https://deliciousbrains.com/wp-migrate-db-pro/ 
 
The unauthorized and infringing copy can be found at: 
 
https://github.com/slang800/wp-migrate-db/blob/5ab3ab9713fd30a5ead58224712a3ced909f5c48/README.md 
 
The following is a sample (and not the entirety) of the content that has been copied without permission: 
 
[private]
 
The Github user slang800 has forked our repository found at https://github.com/bradt/wp-migrate-db. This 
action alone would have been fine, but he has also added a new file named README.md containing content 
copied from our web site that we did not give him permission to use. 
 
This letter is official notification under Section 512(c) of the Digital Millennium Copyright Act (”DMCA”), and I 
seek the removal of the aforementioned infringing material from your servers. I request that you immediately 
notify the infringer of this notice and inform them of their duty to remove the infringing material immediately, 
and notify them to cease any further posting of infringing material to your server in the future. 
 
I have a good faith belief that use of the copyrighted materials described above on the infringing web pages 
is not authorized by the copyright owner, or its agent, or the law. I swear, under penalty of perjury, that the 
information in this notification is accurate and that I am the copyright owner, or am authorized to act on 
behalf of the owner, of an exclusive right that is allegedly infringed. 
 
Should you wish to discuss this with me please contact me directly. 
 
Thank you. 
 
Date: May 28, 2014 
 
[private]

[private]
