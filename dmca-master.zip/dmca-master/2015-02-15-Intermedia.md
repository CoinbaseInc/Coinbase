GitHub DMCA Agent:

My name is [private], and I am writing to you on behalf of Intermedia.net, Inc. ("Intermedia").

I have read and understand GitHub's Guide to Filing a DMCA Notice.

This request pertains to software code posted on the following GitHub site: https://github.com/RLIndia/intermedia. The code posted on this site is the confidential and proprietary intellectual property of Intermedia. Intermedia is the exclusive owner of the copyrights in this code, and it should not be publicly available. The posting on the above-mentioned site constitutes a violation of Intermedia's intellectual property and confidentiality rights in the code posted on this site.

Intermedia contracted with a third party ([private]) to develop code on Intermedia's behalf, and Intermedia is the owner of such code. [private] initially, and inadvertently, created a free GitHub site for their code collaboration efforts. When Intermedia identified that this free GitHub site made the code publicly visible, we promptly requested that [private] transition to a paid, private GitHub site, which [private] then did. However, the code remains visible on another free GitHub site (https://github.com/RLIndia/intermedia). Our requests to remove the code from this site have been ignored.

I have a good faith belief that use of the copyrighted materials described above on the infringing web pages is not authorized by the copyright owner, or its agent, or the law. I swear, under penalty of perjury, that the information in this notification is accurate and that I am the copyright owner, or am authorized to act on behalf of the owner, of an exclusive right that is allegedly infringed.

Should you require any additional information, please feel free to contact me at:

[private]

Thank you very much for your attention to this request.

Best regards,

[private]
