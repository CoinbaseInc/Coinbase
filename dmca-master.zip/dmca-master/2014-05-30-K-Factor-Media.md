Infringing Content: https://github.com/wp-plugins/fb-light-popup-solehnet

K-Factor Media, LLC owns the rights to this code. We currently own and
operate SF Globe: http://sfglobe.com. The original code can be found here
(if you view source): http://sfglobe.com/?id=806

----------------------------------------------------------

Please note that the infringing content overlaps in terms of functions,
function names, variable names, css classes, such as:
All css classes beginning with "kfm_" --> kfm stands for "K Factor Media"

shareArticleOnFB
showSharePrompt

showFBLikePrompt
showEmailPrompt
showEndVideoPrompt

the scroll function

var dlg = new DialogWrapper();

--------------------------------------------------------------------------

[private] on behalf of K-Factor Media, LLC

[private]

[private]

"I have a good faith belief that use of the copyrighted materials
described above on the infringing web pages is not authorized by the
copyright owner, or its agent, or the law."

"I swear, under penalty of perjury, that the information in this
notification is accurate and that I am the copyright owner, or am
authorized to act on behalf of the owner, of an exclusive right that is
allegedly infringed."

Signature: [private]

------------------------------------------------------------
