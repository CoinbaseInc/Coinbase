The file you are hosting on GitHub at the URL: https://gist.github.com/anonymous/11162421, titled airparrotactivator.m and created 20 hours ago, is a violation of the copyrighted work of Squirrels LLC. The previously mentioned file removes the activation and trial limitations of the AirParrot for Mac software (www.airsquirrels.com/airparrot/).

Squirrels LLC is the sole and only owner of AirParrot for Mac and has not authorized this illegal usage of it’s software. Removing and bypassing activation of software is forbidden by the DMCA.

I have a good faith belief that use of the copyrighted materials described above on the infringing web pages is not authorized by the copyright owner, or its agent, or the law.

I swear, under penalty of perjury, that the information in this notification is accurate and that I am the copyright owner, or am authorized to act on behalf of the owner, of an exclusive right that is allegedly infringed.

Best,

[private]

[private]
