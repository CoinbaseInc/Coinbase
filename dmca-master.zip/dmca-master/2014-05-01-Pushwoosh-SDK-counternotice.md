This is a DMCA counter notice for the following repositories:

https://github.com/GameThrive/android-push-plugin
https://github.com/GameThrive/ios-push-plugin
https://github.com/GameThrive/Unity-push-plugin
https://github.com/GameThrive/GameThrive-Push-Plugin-Samples

The copy of the takedown request is here:
https://github.com/github/dmca/blob/master/2014-05-01-Pushwoosh-SDK.md

The takedown request claims that these repositories infringed on their MIT licensed projects since they did not include their license and copyright file. This is untrue, all four repositories contained an MIT license and the PushWoosh copyright within the license.

Additionally, the request claims that 99% of the code was copied, which is also untrue. The repositories did use some code from PushWoosh, but a significant portion of the work was original. Even so, the MIT license is permissive and allows for this kind of use:http://opensource.org/licenses/MIT

I swear under the penalty of perjury that this information is accurate and the material was removed or disabled as a result of a mistake or misidentification.

I consent to the to the jurisdiction of Federal District Court for the judicial district of California to accept service of process from the person who provided notification or their agent.

Name: [private]
Address: [private]
Phone: [private]
Email: [private]

