Access has been denied to files at:

https://github.com/humphd/webvtt

https://github.com/rillian/webvtt

https://github.com/mozilla/webvtt

https://github.com/RickEyre/webvtt

https://github.com/jraff/webvtt

https://github.com/daleee/webvtt

https://github.com/ShayanZafar/webvtt

https://github.com/KyleBarnhart/webvtt

https://github.com/mafidchao/webvtt

https://github.com/limed3/webvtt

https://github.com/Lynart/webvtt

https://github.com/dperit/webvtt

https://github.com/datorman/webvtt

It is my belief, under penalty of perjury, that the files in question 
contain code from multiple copyright holders and were licensed in good 
faith under a BSD open source license, and that the files were removed 
because of a misunderstanding of Canadian copyright law. On behalf of 
our students, faculty and research partners, I ask that access be restored.

I realize that submitting this counter-notice may subject me to the 
jurisdiction of some judicial district in which GitHub may be found, and 
am prepared to accept service of process from the person who provided 
notification or an agent of that person.

17 July 2013

[private]

Co-Chair, School of Information and Communications Technology

Seneca College of Applied Arts and Technology

1750 Finch Avenue East

Toronto, Ontario, Canada

[private]

[private]
