To whom it may concern

Dear GitHub,

My name is [private] of Simple Machines, home of
the Simple Machines Forum (SMF) project.

It has come to our attention that a user/project is infringing upon our
intellectual property by having "forked" a version and removing our
copyright in the process.
Whilst we allow forking of our product through the BSD license, we do
not allow removal of the copyright and consider this a license breach
and therefor a infringement upon our intellectual property.
Our work being infringed is SMF 2.x. (You may download a copy to compare
here: http://download.simplemachines.org/ (See the "Sources" directory
in the zip/tar))
Specifically: the "Sources" files.

The infringing material can be found here:
https://github.com/tapatalk/tapatalk-smf2/tree/master/mobiquo/include

I have a good faith belief that use of the copyrighted materials
described above on the infringing web pages is not authorized by the
copyright owner, or its agent, or the law.

Our own attempts to contact [private] has once proven to be fruitful and
they fixed their scripts. However, unfortunately, they have now removed
our copyright again and no longer respond to our requests to bring their
forked material in to compliance with our license.
We request that your promptly contact them with a warning to bring the
material in to compliance with our license by restoring our copyright
headers, or remove the repository should they not comply within a
reasonable timely manner. (Considering Christmas is coming up, we're
happy to give some time, though we would sincerely appreciate it if the
material can be brought in to compliance *before* the 30th of December
2013...)

The material is owned by:
Simple Machines
PMB #2562
2215 Renaissance Drive
Suite B
Las Vegas, NV 89119

I swear, under penalty of perjury, that the information in this
notification is accurate and that I am the copyright owner, or am
authorized to act on behalf of the owner, of an exclusive right that is
allegedly infringed.

Thank you in advance for your quick action.
On behalf of Simple Machines, I would like to wish you happy holidays
and a splendid 2014.

Kind regards,
/s/[private]
[private] Simple Machines
[private]
T: [private]
E: [private]
E2: [private]
