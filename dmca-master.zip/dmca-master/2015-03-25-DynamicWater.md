I am the owner of copyrighted work.

Contact information:
[REDACTED]

The copyrighted work is "Dynamic Water System" plugin for Unity game
development engine, which is only available commercially at this URL:

https://www.assetstore.unity3d.com/en/#!/content/10382

Materials allegedly infringing the copyrighted work are located at this URL:

https://github.com/caina/lhamaavista/tree/master/Assets/Third_part/DynamicWater

The whole plugin package is imported in lhamaavista repository.

I have a good faith belief that use of the copyrighted materials
described above on the infringing web pages is not authorized by the
copyright owner, or its agent, or the law.
I swear, under penalty of perjury, that the information in this
notification is accurate and that I am the copyright owner, or am
authorized to act on behalf of the owner, of an exclusive right that is
allegedly infringed.


[REDACTED]

Lost Polygon.

lostpolygon.com
