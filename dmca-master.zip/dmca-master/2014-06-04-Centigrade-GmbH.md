Dear Sir or Madam,

 
Yesterday, we stumbled upon a project hosted on your web space that contains our product which was not approved by us.

 
Therefore, with this mail we would like to file a copyright infringement.

 
The copyrighted work that has been infringed are two of our products namely BizLaf and Cezanne in form of downloadable bundles containing Java JAR files, documentation etc..
You can find information on those products on our website:

http://www.centigrade.de/en/products/bizlaf-stock-look-and-feel <http://www.centigrade.de/en/products/bizlaf-stock-look-and-feel>

http://www.centigrade.de/en/products/cezanne-look-and-feel-engine <http://www.centigrade.de/en/products/cezanne-look-and-feel-engine>

 
The copyright-infringing material includes the following locations and all its contents (inside each remote folder):

1.       https://github.com/dvargo/pm/tree/master/resources/BizLaf%202

2.       https://github.com/dvargo/pm/tree/master/resources/bizlaf-2.3.14

3.       https://github.com/dvargo/pm/tree/master/resources/bizlaf-cezanne-2.3.14.32

4.       https://github.com/dvargo/pm/tree/master/resources/bizlaf-netbeans-module-2.3.14.32

5.       https://github.com/dvargo/pm/tree/master/resources/cezanne-2.3.34

 
For further questions or comments GitHub may contact me directly under the information given in my mail signature.

 
The owner/administrator of the aforementioned GitHub project we believe to be [private]", whose mail address is [private] .

His project is hosted at this GitHub URL: https://github.com/dvargo/pm/

 
I have a good faith belief that use of the copyrighted materials described above on the infringing web pages is not authorized by the copyright owner, or its agent, or the law.

 
I swear, under penalty of perjury, that the information in this notification is accurate and that am authorized to act on behalf of the owner, of an exclusive right that is allegedly infringed.

 
Thanks

 
[private]

[private]

Centigrade GmbH
[private]

