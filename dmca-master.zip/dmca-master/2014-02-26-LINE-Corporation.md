Dear GitHub Team,

My name is [private] and I am writing on behalf of LINE Corporation, in regards to a copyright violation on the GitHub website.

I believe in good faith that "Deobfuscated Official LINE for Firefox OS" infringes LINE Corporation's copyrights and that the use of our source code is not authorized by the rights holder, its agent or the law.

The below posts on GitHub are infringing upon our copyrighted source code, without any prior consent or permission. We request that the files be removed from the GitHub website accordingly..

The information in this notification is accurate and I swear under penalty of perjury that I am authorized to act on behalf of the owner of an exclusive right that is alleged to be infringed. 

Infringing Content on GitHub:

https://github.com/d3m3vilurr/line-for-firefoxos

https://github.com/d3m3vilurr/line-for-firefoxos/tree/master/META-INF

https://github.com/d3m3vilurr/line-for-firefoxos/tree/master/res

https://github.com/d3m3vilurr/line-for-firefoxos/tree/master/src

https://github.com/d3m3vilurr/line-for-firefoxos/blob/master/index.html

https://github.com/d3m3vilurr/line-for-firefoxos/blob/master/manifest.webapp

Page name: Deobfuscated Official LINE for Firefox OS

Publisher
Name: d3m3vilurr

Copyright information:

Copyright owner: LINE Corporation

URL: http://line.me/en/
         https://marketplace.firefox.com/app/line/

Contact information:

[private]
 
Infringing Party:
[private]

Thank you for your attention to this matter and we look forward to hearing from you soon.

Best regards,

[private]
