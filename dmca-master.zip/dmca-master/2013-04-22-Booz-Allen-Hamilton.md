Dear GitHub,

On behalf of the copyright holder, I notify you of content you host that infringes upon one or more copyrighted works, as provided by 17 U.S.C. § 512(c)(3), in the format specified by you.

The copyrighted works infringed upon are some image files that were purchased by the US Govt, some source codes and related documentation, created within the framework of a project here at Booz Allen Hamilton.


Part of material available at the address https://github.com/sungang/LM-Embedding infringes copyrighted works. You will find enclosed the complete list of the files, which infringe copyrighted works.


GitHub Inc. may contact the copyright holder through me at the following address:

[private]

[private]

[private]


I have a good faith belief that the copyright owners, or their agent, or the law does not authorize use of the copyrighted materials described above on the infringing web pages.

I swear that the information in this notification is accurate, and under penalty of perjury that I am authorized to act on behalf of the owners of an exclusive right to the allegedly infringed works.

Sincerely,

[private]

