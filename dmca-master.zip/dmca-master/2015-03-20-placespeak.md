On March 7th, someone successfully compromised the security on our AWS
development server and subsequently cloned our private github repo 
(https://github.com/PlaceSpeak/place_3) to their own public repo 
(https://github.com/MFgit/Place). This is clearly our copyright producted
code and this amounts not a simple license violation (they have no license
from us and this is not open source code) but instead is clear cut theft of
IP. The address on the repo is bogus and we'd really appreciate having
our private code removed as soon as possible.

I have a good faith belief that use of the copyrighted materials
described above on the infringing web pages is not authorized by the
copyright owner, or its agent, or the law.

I swear, under penalty of perjury, that the information in this
notification is accurate and that I am the copyright owner, or am
authorized to act on behalf of the owner, of an exclusive right that is
allegedly infringed.

[REDACTED]

Thank you for your attention to this matter.

-- 
[REDACTED]
www.placespeak.com
