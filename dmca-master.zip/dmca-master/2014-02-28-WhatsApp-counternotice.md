With regard to the takedown notice:

https://github.com/github/dmca/blob/master/2014-02-12-WhatsApp.md

Access to the following repositories have been disabled:

https://github.com/davidgfnet/whatsapp-purple

https://github.com/davidgfnet/wireshark-whatsapp

This communication to you is a DMCA counter notification letter as defined in 17 USC 512(g)(3):

I declare, under penalty of perjury, that I have a good faith belief that the complaint of 
copyright violation is based on mistaken information, misidentification of the material in 
question, or deliberate misreading of the law.

I also declare that the repositories might have contained copyrighted material which was 
promptly removed after its notification.

My name, address, and telephone number are as follows:

[private]

I hereby consent to the jurisdiction of Federal District Court for the judicial district in which I
reside (or, if my address is outside the United States, any judicial district in which GitHub, 
may be found),

I agree to accept service of process from the complainant or an agent of such person.
My actual or electronic signature follows:

Having received this counter notification, you are now obligated under 17 USC 512(g)(2)
(B) to advise the complainant of this notice, and to restore the material in dispute (or not 
take the material down in the first place), unless the complainant files suit against me 
within 10 days.

Best Regards,

[private]
