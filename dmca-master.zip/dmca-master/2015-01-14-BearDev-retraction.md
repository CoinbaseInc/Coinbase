Dear [private],

Could you be so kind and remove the DCMA takedown for https://github.com/Gileba/Joomsport/
We have communicated with our client and agreed that they will distribute the modifications only and not the core product code and this is completely fine with us.

Thank you in advance and our apologies for such inconveniences caused!
Should you need any additional information provided please do not hesitate to contact me at any time.

Best Regards,

[private]
