Hello,

  Cartwheel Web, LLC is the owner of the Two Scoops Press brand which
publishes the book, Two Scoops of Django: Best Practices for Django 1.5.
This book is protected by U.S. copyright laws.

The following are GitHub repos that republish our book and have not agreed
to take down the content after repeated contact attempts:

  * https://github.com/watsy0007/two-scoops-django-best-practices1.5-chinese
  * https://github.com/compfaculty/2django

I have good faith belief that the use of the copyrighted materials
described above on the infringing web pages is not authorized by
Cartwheel Web, LLC, Inc, the copyright owner or the law. I swear under
penalty of perjury that the information is this notification is accurate
and that my company, Cartwheel Web, LLC, Inc. is the copyright owner of an
exclusive right that is infringed.

We request that you take down these pages.

Sincerely,

[private]

Principal at Cartwheel Web, LLC.

[private]
[private]
