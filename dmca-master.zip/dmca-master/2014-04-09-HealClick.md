Dear Github: 
I am the owner of HealClick’s repo https://bitbucket.org/healclick/ and 2 instances, including 
staging and production at www.healclick.com. https://github.com/anatolyGit/Heal_Click is an 
infringment of our private repo : 

My contact: 

[private]

[private] 

[private] 

[private] 

I have a good faith belief that use of the copyrighted materials described above on the infringing 
web pages is not authorized by the copyright owner, or its agent, or the law. I swear, under 
penalty of perjury, that the information in this notification is accurate and that I am the copyright 
owner, or am authorized to act on behalf of the owner, of an exclusive right that is allegedly 
infringed." 

Thank you for taking swift action on the takedown of the infringed copyright. 

[private]
