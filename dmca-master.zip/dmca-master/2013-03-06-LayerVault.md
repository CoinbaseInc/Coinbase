Attn: Copyright Agent, GitHub, Inc.

Pursuant to 17 USC 512(c)(3)(A), this communication serves as a statement
that:

I am the exclusive rights holder for the artwork contained within Flat UI,
Free Web User Interface Kit; These exclusive rights are being violated by
material available upon your site at the following URL:

http://designmodo.github.com/Flat-UI/;

I have a good faith belief that the use of this material in such a fashion
is not authorized by the copyright holder, the copyright holder's agent, or
the law;

Under penalty of perjury in a United States court of law, I state that the
information contained in this notification is accurate, and that I am
authorized to act on the behalf of the exclusive rights holder for the
material in question;

I may be contacted by the following methods (include all):
LayerVault, 154 Grand St., 3rd floor,
NY NY 10013,
[private];

I hereby request that you remove or disable access to this material as it
appears on your service in as expedient a fashion as possible. Thank you.

Regards,
[private]