Please remove the following post
https://gist.github.com/anonymous/6210126

Digital Millennium Copyright Act - Removal Request

This letter is official notification under the provisions of Section
512(c) of the Digital Millennium Copyright Act (“DMCA”) to effect removal
of the above-reported infringements.

It is requested that you immediately remove this post
https://gist.github.com/anonymous/6210126

User did not have my permission to
reproduce this content.

Copies of this page have been taken and you shall receive a formal letter
should this post not be removed within 24 hours from your blog. A DMCA has
also submitted with a copyright breach to your website company.

Please be advised that law requires you, to “expeditiously remove or
disable access to” the infringing photographs, images and blog text upon
receiving this notice. Non-compliance may result in a loss of immunity for
liability under the DMCA and will result in legal action for Copyright
Breach and possible defamation.

It is of good faith belief that use of the material in the manner
complained of here is not authorized by me, the copyright holder, or the
law. The information provided here is accurate to the best of my
knowledge. It is hereby sworn under penalty of perjury that the copyright
holder of the said text, article and image that are in the website post
and format.

Please send at the address noted below a prompt response indicating the
actions you have taken to resolve this matter.
