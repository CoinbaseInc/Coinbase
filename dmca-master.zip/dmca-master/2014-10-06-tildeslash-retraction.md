Dear Github

We wish to withdraw our [DMCA Notice](https://github.com/github/dmca/blob/master/2014-10-05-tildeslash.md) regarding this repository

https://github.com/mperham/inspeqtor

In retrospect we realise that the copyright violation is open for interpretation and it is not so clear-cut as we were first led to believe. It is therefor unfair to [private] and to Inspeqtor's users if our action cause the repository to be off-line any longer. We sincerely apologise for this. We will not take any further action in this matter.

Our position was to see the work in question as a whole, together with the history and from there we formed a causal narrative between Monit and Inspeqtor, but we are afraid we have been both naive and misguided in our use of DMCA. We do see the irony, unfortunately to late, that our own action might be considered unethical although our intentions were the opposite. The old saying, "The road to hell is paved with good intentions” never felt more true.

Best regards  
—  
For the Monit team  
[private]
