Hello,

  InterNiche Technologies is the developer and licensor of networking 
protocol libraries, all of which are protected by U.S. copyright laws. 
The posting on github are all under a software license from 
semiconductor manufactures that expressly prohibit redistribution of the 
copyrighted source code files. The files are NicheStack TCP/IP, RTP and 
Telnet and NicheLite TCP/IP.

  * https://github.com/befedo/uC-OSonNIOSII_SBT_BSP/tree/master/iniche
  * https://github.com/Scrts/FPGA-Projects/tree/master/software/webserver_pipelined_bsp/iniche
  * https://github.com/robdigital/ECE492/tree/master/niosII_microc_fp2/software/WebServer2_bsp/iniche
  * https://github.com/tew/Digibutler/tree/master/SW_Main_Board/src/projects/NicheLite



I have good faith belief that the use of the copyrighted materials 
described above on the infringing web pages is not authorized by 
InterNiche Technologies, Inc, the copyright owner or, any licenses, or 
the law. I swear under penaly of perjury that the information is this 
notification is accurate and that my company, InterNiche Technologies, 
Inc. is the copyright owner of an exclusive right that is infringed.

-- 
[private]

President
  
  InterNiche Technologies, Inc.

51 E. Campbell Ave, Suite 160, Campbell, CA 95008

[private] 
