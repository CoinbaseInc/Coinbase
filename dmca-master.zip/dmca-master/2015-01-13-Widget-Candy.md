A page that your company hosts is infringing on at least one copyright owned by my company.

A copy of our commercially distributed product, a LUA library named â€œWidget Candyâ€ was copied onto your servers without permission. The original product, to which we own the exclusive copyrights, can be found at:

http://x-pressive.com/WidgetCandy_Corona/

Widget Candy is a commercially distributed LUA code library that is available to our paying customers only. Therefore, its source code must not be published on publicly accessible pages.

The unauthorized and infringing copy can be found at:

https://github.com/marcusalexandre/Estatec/blob/master/sc/widget_candy.lua

Please note the attached files that also include a copy of our product (Widget Candy), along with an identity document of me, [private].

This letter is official notification under Section 512(c) of the Digital Millennium Copyright Act (â€DMCAâ€), and I seek the removal of the aforementioned infringing material from your servers. I request that you immediately notify the infringer of this notice and inform them of their duty to remove the infringing material immediately, and notify them to cease any further posting of infringing material to your server in the future.

Please also be advised that law requires you, as a service provider, to remove or disable access to the infringing materials upon receiving this notice. Under US law a service provider, such as yourself, enjoys immunity from a copyright lawsuit provided that you act with deliberate speed to investigate and rectify ongoing copyright infringement. If service providers do not investigate and remove or disable the infringing material this immunity is lost. Therefore, in order for you to remain immune from a copyright infringement action you will need to investigate and ultimately remove or otherwise disable the infringing material from your servers with all due speed should the direct infringer, your client, not comply immediately.

I am providing this notice in good faith and with the reasonable belief that rights my company owns are being infringed. Under penalty of perjury I certify that the information contained in the notification is both true and accurate, and I have the authority to act on behalf of the owner of the copyright(s) involved.

Should you wish to discuss this with me please contact me directly.

Thank you.

I have read and understand GitHub's Guide to Filing a DMCA Notice.

I have a good faith belief that use of the copyrighted materials described above on the infringing web pages is not authorized by the copyright owner, or its agent, or the law.

I swear, under penalty of perjury, that the information in this notification is accurate and that I am the copyright owner, or am authorized to act on behalf of the owner, of an exclusive right that is allegedly infringed.

X-PRESSIVE.COM

c/o [private] (CEO)

[private]
