To Whom It May Concern,

I am a representative of MCProHosting, the copyright holder of source
code and content that is currently being hosted without permission on
your servers.

The infringing content can be found at:

https://github.com/Bob-Grind/Website_Rule

https://github.com/Bob-Grind/Forums_MCProHosting

https://github.com/Bob-Grind/Multicraft_MCProHosting

https://github.com/Bob-Grind/Multicraft_SMProHosting

https://github.com/Bob-Grind/Static_ServerProHosting

https://github.com/Bob-Grind/Website_MCProHosting

https://github.com/Bob-Grind/Website_ArcadiaCon

https://github.com/Bob-Grind/Website_SMProHosting

https://github.com/Bob-Grind/WHMCS_MCProHosting

https://github.com/Bob-Grind/WHMCS_SMProHosting

This infringing content is being held by:

The user “Bob-Grind” on https://github.com/Bob-Grind

This content is a direct copy of our original work at:

https://github.com/MCProHosting/Website_Rule

https://github.com/MCProHosting/Forums_MCProHosting

https://github.com/MCProHosting/Multicraft_MCProHosting

https://github.com/MCProHosting/Multicraft_SMProHosting

https://github.com/MCProHosting/Static_ServerProHosting

https://github.com/MCProHosting/Website_MCProHosting

https://github.com/MCProHosting/Website_ArcadiaCon

https://github.com/MCProHosting/Website_SMProHosting

https://github.com/MCProHosting/WHMCS_MCProHosting

https://github.com/MCProHosting/WHMCS_SMProHosting

This letter is an official notification under the provisions of Section
512(c) of the Digital Millennium Copyright Act ("DMCA") to effect
removal of the above-reported infringement(s).

I have a good faith belief that use of the copyrighted materials
described above on the infringing web pages is not authorized by the
copyright owner, or its agent, or the law.

I swear, under penalty of perjury, that the information in this
notification is accurate and that I am the copyright owner, or am
authorized to act on behalf of the owner, of an exclusive right that is
allegedly infringed.

Thank you for your time.

Sincerely,

[private]

[private]

[private]
