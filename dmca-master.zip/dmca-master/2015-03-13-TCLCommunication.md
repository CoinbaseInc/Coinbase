Dear Sir or Madam:

I am [REDACTED], the software development team head at TCL Communication Technology Holdings Limited. I have read and understand GitHub’s Guide to Filing a DMCA Notice. On behalf of TCL Communication Technology Holdings Limited, I send you this official notification.

I can be contacted via
[REDACTED]

I have a good faith belief that the whole source code repository at

https://github.com/HiRolland/TestProjectForAlto5TF 

is unlawful under DMCA and copyright law in US and China, because it seriously infringed the copyrights of TCL Communication Technology Holdings Limited. Here I would like to have your support to immediately remove the whole software source code under the above URL, and immediate disable any access to code under this URL through your website.

TCL Communication Technology Holdings Limited holds the copyright of the source code posted under the URL above. Please refer to the attached file named as “TCL Proof.zip” which shows number of code comments demonstrating that many engineers from TCL Communication Technology Holdings Limited developed these source codes. These source codes are highly confidential and sensitive to TCL Communication Technology Holdings Limited.

These source code were uploaded to Github inadvertently by one of our employees([REDACTED]) to URL 

https://github.com/nbcool/TestProjectForAlto5TF 

then our employee removed the code from Github. However, before the removal, it was cloned by one Github user (account name: HiRolland) without the permission from TCL Communication Technology Holdings Limited, please refer to

https://github.com/HiRolland?tab=activity

which indicates clearly that Github user(HiRolland) cloned the code and published it via a new link.

We take this source code exposure issue very seriously, and may pursue legal action against the individuals and organizations who/which take part in unauthorized dissemination of any source code in the URL above.

I swear, under penalty of perjury, that the information in this notification is accurate and that I am authorized to act on behalf of the owner(TCL Communication Technology Holdings Limited), of an exclusive right that is allegedly infringed.

Thank you for your kind assistance.

Regards,
[REDACTED]

TCL Communication Technology Holdings Limited
