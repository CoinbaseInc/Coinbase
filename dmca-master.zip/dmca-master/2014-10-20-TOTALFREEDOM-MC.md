Dear GitHub Copyright Agent:

I, the undersigned, state UNDER PENALTY OF PERJURY that:

[1] I am, a person injured, or an agent authorized to act on behalf of a
person injured by a violation of the U.S. Copyright laws, in particular
section(s) 1201(a)(2) and/or 1201(b)(1) of Title 17 of the United States
Code, commonly referred to as the Digital Millennium Copyright Act, or
"DMCA";

[2] I May Be Contacted At: [private]

Name of Injured Party : TOTALFREEDOM MC (“TF”)

Name and Title: TOTALFREEDOMMOD

Original content available at:

https://github.com/TotalFreedom/TotalFreedomMod

Company: TOTALFREEDOM MC

Address: [private]

City, State, and Zip: [private]

Email address: [private]

Telephone: [private]

[3] I have a good faith belief that the file-downloads identified below (by
URL) are unlawful under these laws because, among other things, the files
circumvent effective access controls and/or copyright protection measures;

[4] Reason:

Content Type: "Custom Minecraft server modification”

Violation(s): Failing to comply to the provided License.

[5] Please act expeditiously to remove the file-downloads found at the
following URLs:

Repository:

https://github.com/Wilee999/Wileefreedom

Infringing content:

https://github.com/Wilee999/Wileefreedom/blob/master/src/me/Wilee999/Wileefreedom/Commands/WF_Command.java

https://github.com/Wilee999/Wileefreedom/blob/master/src/me/Wilee999/Wileefreedom/Commands/CantFindPlayerException.java

https://github.com/Wilee999/Wileefreedom/blob/master/src/me/Wilee999/Wileefreedom/Wileefreedom.java

[6] I have a good faith belief that the circumvention of effective access
controls and/or copyright protection measures identified above is not
authorized by law; and

[7] I have read and understand GitHub's Guide to Filing a DMCA Notice.

[8] The information in this notice is accurate.

Thank you for your kind assistance.

Truthfully,

[private]

[private]
