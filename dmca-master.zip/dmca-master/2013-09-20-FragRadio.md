20/09/2013  

**Sender Information:**  
FragRadio  
[private], Operational Manager  
[private]  

**Recipient Information:**  
github.com.  
C/O Copyright Agent for Notice of Claims of Copyright Infringement

Sent via: Email via PDF to support@github.com ref: NONE GIVEN - [private]  
**DMCA Notice of Copyright Infringement**  
**re: FragRadio github page t/a [private]**

Dear github.com

I, [private] of FragRadio, certify under penalty of perjury, that I am an authorized persons to act on behalf of the owner ( FragRadio ) of certain intellectual property rights.

I have a good faith belief that the items or materials listed below are not authorized by law for use by the above named domain name owner or their agents and or users and therefore infringes the copyright owner's rights. I hereby demand that you act expeditiously to remove or disable access to the material or items claimed to be infringing the users who have uploaded this material are NOT authorised by the above.

Allegedly Infringing items or materials:

FragRadio GitHub Page owned by ex member of staff [private] now fired managed on behalf of FragRadio.

Infringing material that I demand be disabled or removed in consideration of the above:

https://github.com/OfficialRC1/FragRadio-iOS-Radio
