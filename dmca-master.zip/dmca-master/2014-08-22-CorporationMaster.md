I would like to file a DMCA for the following repo
https://github.com/nquinn721/corporationmaster

[A] I May Be Contacted At: contact@corporationmaster.com

Name of Injured Party : CorporationMaster.com

[private]

[B] The information in this notice is accurate.
Also proof that it is my website. Godaddy domain registration
http://prntscr.com/4ewwzb, Hosting for the domain watchdocumentary.tv
but on that host i have all 3 domains and websites
http://prntscr.com/4ewxi9.
I attached my national ID card in this email as well.

I sent my project to a freelancer a while ago, and he put it on
github, and i can't get hold of him so he can delete it. The orginal
repo, and all it's content is owned by me at the domain
corporationmaster.com.

I hope this can be a minor issue as the other repo is clearly an old
copy of mine, but no longer maintained or used.

I have a good faith belief that use of the copyrighted materials
described above on the infringing web pages is not authorized by the
copyright owner, or its agent, or the law.

I swear, under penalty of perjury, that the information in this
notification is accurate and that I am the copyright owner, or am
authorized to act on behalf of the owner, of an exclusive right that
is allegedly infringed.

Best Regards, [private]
