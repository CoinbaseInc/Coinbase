Dear GitHub Copyright Agent:

An older version of our [private] proprietary source code had been publically published to GitHub by a former outsourced contractor (paycube/aurus). This code was previously published at [private]. We had filed a DMCA takedown request with GitHub for that issue, and have worked with Paycube/Aurus to successfully remove that repository.

This code was subsequently forked by another member of the GitHub community, https://github.com/hchtym/verifone. The entirety of this code was done as a "work for hire" by Paycube/Aurus on behalf of Merchant Warehouse, and we believe that the entire contents of the repository consists of infringing material. Both Merchant Warehouse and Aurus, whose employee had published the repository from which hchtym's repository was forked, will affirm this.

I have a good faith belief that use of the copyrighted materials described above on the infringing web pages is not authorized by the copyright owner, or its agent, or the law. I swear, under penalty of perjury, that the information in this notification is accurate and that I am the copyright owner, or am authorized to act on behalf of the owner, of an exclusive right that is allegedly infringed.

I have CC'd Merchant Warehouse's [private] on this correspondence.

Thank you,

[private]

Merchant Warehouse
One Federal Street, 2nd Floor
Boston, Massachusetts 02110

Direct: [private]
