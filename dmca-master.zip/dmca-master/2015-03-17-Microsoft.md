I have read and understand GitHub's Guide to Filing a DMCA Notice.

VIA EMAIL:

Demand for Immediate Take-Down: Notice of Infringing Activity

Date:

05/03/2015

Case #:

[REDACTED]

Url:

github.com - The whole directory

Host IP Address:

192.30.252.131


Dear Sir or Madam,

We have received information that the domain listed above, which appears to
be on servers under your control, is offering unlicensed copies of, or is
engaged in other unauthorized activities relating to, copyrighted works
published by Microsoft Corporation

1. Copyright work(s):
  
  Windows NT 4.0
  
  Copyright owner(s) or exclusive licensee:
  
  Microsoft Corporation

2. Copyright infringing material or activity found at the following
  location(s):
  
  https://github.com/njdragonfly/WinNT4/ - The whole directory
  
  The above copyright work(s) is being made available for copying, through
downloading, at the above location without authorization from the copyright
owner or exclusive licensee.

3. Statement of authority:
  
  The information in this notice is accurate, and I hereby certify under
  penalty of perjury that I am authorized to act on behalf of Microsoft
  Corporation, the owner or exclusive licensee of the copyright(s) in the
  work(s) identified above. I have a good faith belief that none of the
  materials or activities listed above have been authorized by Microsoft
  Corporation, its agents, or the law.
  
  We hereby give notice of these activities to you and request that you take
  expeditious action to remove or disable access to the material described
  above, and thereby prevent the illegal reproduction and distribution of this
  copyrighted work(s) via your company's services.
  
We appreciate your cooperation in this matter. Please advise us regarding
  what actions you take.

1. Included. "I have a good faith belief that use of the copyrighted
  materials described above on the infringing web pages is not authorized by
  the copyright owner, or its agent, or the law."
  
2.  
  
3. Included. "I swear, under penalty of perjury, that the information
  in this notification is accurate and that I am the copyright owner, or am
  authorized to act on behalf of the owner, of an exclusive right that is
  allegedly infringed."

Yours sincerely,

[REDACTED]


Internet Investigator

On behalf of:

Microsoft Corporation

One Microsoft Way, Redmond, WA 98052, United States of America

E-mail: [REDACTED]
