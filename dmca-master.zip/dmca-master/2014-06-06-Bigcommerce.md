Dear Sir/Madam,

I am writing to you to avail myself of my rights under the Digital
Millennium Copyright Act (DMCA). This letter is a Notice of Infringement as
authorized in § 512(c) of the U.S. Copyright Law.

I am an authorized agent to act on behalf of Bigcommerce Holdings Inc., the
sole developer of the Bigcommerce application, delivered as software as a
service at http://www.bigcommerce.com/.

It has come to the attention of Bigcommerce Holdings Inc. that the private
source code for the above mentioned application is hosted in a publicly
available location on your website. This content has been published without
the authorization of Bigcommerce Holdings Inc.

Please remove the referenced material below from your service at once, and
take appropriate action against the account holder to prevent future
infringement.

Offending URLs:
https://github.com/architek360/blankathon

I may be contacted at:
[private]

I have a good faith belief that use of the copyrighted materials described
above on the infringing web pages is not authorized by the copyright owner,
or its agent, or the law.

Pursuant to the Digital Millennium Copyright Act (DMCA), this letter serves
as actual notice of infringement in the event of legal proceedings. I swear
the penalty of perjury, that the information in this notice is accurate and
that I am authorized to act on behalf of the owner, Bigcommerce Holdings
Inc.

s/ [private] 
Bigcommerce

Email: [private]

Web: http://www.bigcommerce.com/
