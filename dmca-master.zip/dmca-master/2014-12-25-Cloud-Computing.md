To Whom It May Concern:

I am the owner of Github account: binfeng and author of the all the codes
in the infringed repository, together with [private], professor of
Computer Science Department, School of Computer Science in CMU send this
DCMA complaint.

We have recently learned that the content at the following URL is hosted by
GitHub, and this link is distributing material, including but not limited
to proprietary code with my Git log information, that violate copyright
laws and/or contributes to and induces copyright infringement:

https://github.com/WENDY0517/15619-Cloud-Computing

https://github.com/yuzhangcmu/15619-Cloud-Computing

I have read and understand GitHub's Guide to Filing a DMCA Notice.

We believe that *all* of the material contained in those URL was obtained
in violation of other federal and state laws, including at minimum the DMCA
and California trade secret law, and therefore constitutes a violation of
Section 8(A) of GitHub's Terms of Service which prohibits individuals from
using GitHub "for any illegal or unauthorized purpose."

I have a good faith belief that use of the copyrighted materials described
above on the infringing web pages is not authorized by the copyright owner,
or its agent, or the law.

I swear, under penalty of perjury, that the information in this
notification is accurate and that I am the copyright owner, or am
authorized to act on behalf of the owner, of an exclusive right that is
allegedly infringed.

*We requests that you immediately take down the web content located at the
listed URL, and promptly disclose to us the identities and contact
information corresponding to the account owners and/or users of your
hosting services who posted the content identified herein.*

*Please remove the repositories as soon as possible, and please let us know
when the repositories are removed.* If you have any questions, please
contact me at the following address or phone number: [private]

Best regards,

[private]

[private] 

Pittsburgh, PA (EST)
