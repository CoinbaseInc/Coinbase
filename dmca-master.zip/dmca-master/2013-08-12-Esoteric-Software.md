1) Copyrighted work is the full Spine installers which have been committed
to a github repository here:

https://github.com/NosicLin/Faeris-Tool/tree/master/Spine%20Skeleton

This has enabled people to crack Spine, my software:

[private]

2) This is my website:

http://esotericsoftware.com/

This is the license the user is violating by posting the full setup of my
software:

http://esotericsoftware.com/spine/files/license.txt

3) You can reach me at:
[private]
I'm currently traveling abroad and my cell is disabled, but my number is
normally [private].

4) It seems the user who uploaded the setup files is:
https://github.com/NosicLin
[private]

5) I have a good faith belief that use of the copyrighted materials
described above on the infringing web pages is not authorized by the
copyright owner, or its agent, or the law.

6) I swear, under penalty of perjury, that the information in this
notification is accurate and that I am the copyright owner, or am
authorized to act on behalf of the owner, of an exclusive right that is
allegedly infringed.

Signed electronically: [private]
