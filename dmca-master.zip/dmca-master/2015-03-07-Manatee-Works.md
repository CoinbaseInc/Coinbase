*To Whom It May Concern:*

*I have read and understand GitHub's Guide to Filing a DMCA Notice.*

*The copyrighted work we believe to have been infringed is a reverse
engineering on our public Android app "Barcode Scanners". The user appears
to have reverse engineered the code in order to determine the license
keys.*

*The content can be found
here:

https://github.com/dataplug/DataPlug/blob/ce4a9813ce919f88bfc7b1c2002454b3201297e9/assets/android/godk_android/src/com/manateeworks/CNICScanner/ActivityCapture.java

*Specifically, lines 150 and 151:*

[REDACTED]

*The user needs to modify these two lines as follows:*

BarcodeScanner.MWBregisterCode(BarcodeScanner.MWB_CODE_MASK_PDF, "username",
"key");BarcodeScanner.MWBregisterCode(BarcodeScanner.MWB_CODE_MASK_QR, "
username", "key");

I have attempted to contact the developer. 

https://github.com/zahidiub?tab=repositories

*There has been no response.*

*I have a good faith belief that use of the copyrighted materials described
above on the infringing web pages is not authorized by the copyright owner,
or its agent, or the law.*

*I swear, under penalty of perjury, that the information in this
notification is accurate and that I am the copyright owner, or am
authorized to act on behalf of the owner, of an exclusive right that is
allegedly infringed.*

Regards, [private] CEO / Founder

Manatee Works, Inc.

[private]
