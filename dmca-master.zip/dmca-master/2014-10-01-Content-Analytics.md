Thanks for your message. Amazon notified us that someone compromised our
AWS account and took our access keys and the source code from one of our
AWS servers and posted it on github. Their message is below. The access
keys and the posted source code belongs to Content Analytics Inc., and we
request that it be removed immediately.

My contact info:

[private]

Location of infringing material:

*https://github.com/gexiangchun728/tmText

<https://github.com/gexiangchun728/tmText> --- source code copyright
Content Analytics, Inc.*

*https://github.com/gexiangchun728/tmText/blob/c91dff97d1ab707604bbc9ef76cfab114eb38f2a/aws_config/Vagrantfile

<https://github.com/gexiangchun728/tmText/blob/c91dff97d1ab707604bbc9ef76cfab114eb38f2a/aws_config/Vagrantfile>

-- access keys that belong to Content Analytics Inc.*

I have a good faith belief that use of the copyrighted materials described
above on the infringing web pages is not authorized by the copyright owner,
or its agent, or the law.

I swear, under penalty of perjury, that the information in this
notification is accurate and that I am the copyright owner, or am
authorized to act on behalf of the owner, of an exclusive right that is
allegedly infringed.

Thanks for your help.

/s/ [private]

Founder, Content Analytics, Inc.
