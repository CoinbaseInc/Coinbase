The following repositories violate copyright on intellectual property
that I own, namely Clockwork and Schemas:

The copyrighted work at issue is the ('gamemode', 'schema') 'Clockwork'
created by Cloud Sixteen ( Copyright Certificate:

http://cloudsixteen.com/copyright.pdf ) ( http://CloudSixteen.com )

The website/domain where our copyrighted material is hosted at the
following locations:

https://github.com/CakeZCanaaN/ClockworkDRMFix

https://github.com/CakeZCanaaN/ClockworkCiderTwo

https://github.com/CakeZCanaaN/ClockworkPhaseFour

https://github.com/CakeZCanaaN/ClockworkNewVegas

https://github.com/CakeZCanaaN/ClockworkHL2RP

You can reach me at [private]
for further information or clarification. My phone number is
[private] and my mailing address is [private].

I have a good faith belief that use of the copyrighted materials
described above as allegedly infringing is not authorized by the
copyright owner, its agent, or the law.

I swear, under penalty of perjury, that the information in the
notification is accurate and that I am the copyright owner or am
authorized to act on behalf of the owner of an exclusive right that is
allegedly infringed.

[private]
