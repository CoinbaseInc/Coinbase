Dear Sir or Madam:

I, the undersigned, state under penalty of perjury that: Onsist represents Learnable (hereinafter, "Our Client") in intellectual property and litigation matters. Our Client has recently learned that the content at the following URL(s) (hereinafter, "Listed URL(s)") is hosted on your service, and the URL(s) are distributing materials that violate copyright laws, and/or contributes to and induces copyright infringement:

https://github.com/drachimera/jspen/blob/master/books/Sitepoint.jQuery.Novice.to.Ninja.Feb.2010.pdf

https://github.com/boostup/Javascript-App-Dev/blob/master/html5-and-css3-for-the-real-world/html5-and-css3-for-the-real-world.pdf

The content that your hosting illegally are eBooks written and published by our client. You can view the original content here: https://learnable.com/

This unauthorized distribution constitutes copyright infringement under the U.S. Copyright Act. Pursuant to 17 U.S.C. 512(c), including other International Copyright Laws. This letter serves as actual notice of infringement. We hereby demand you to immediately and permanently cease and desist the unauthorized distribution of the copyrighted material located at the Listed URLs.

We will use all means possible including injunctions and recovery of attorney's fees, costs and any and all other damages which are incurred by Our Client as a result of any action that is commenced against you. Our Client prefers to resolve this matter without taking legal action, but it is prepared to file a lawsuit if necessary to protect its rights and business. You may avoid legal action by removing the infringing content from your service immediately.

We have a good faith basis that the content at the Listed URL(s) is an infringement of Our Client's rights under copyright law, including but not limited to the DMCA, and that the infringing content is authorized by neither Our Client nor the law.

Our Client requests that you immediately take down the web content located at the Listed URL(s).

Finally, the information in this notice is accurate. If you have any questions, please contact me at the email address or phone number listed below.

Sincerely,

[private]

Onsist Agent

International Anti-Piracy Operations

Onsist

Edisonstraat 23

2811 EM Reeuwijk

The Netherlands

Phone: [private]

Email: [private]
