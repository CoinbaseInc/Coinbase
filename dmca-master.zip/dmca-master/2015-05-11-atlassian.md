Atlassian Pty Ltd (“Atlassian”) hereby requests a DMCA takedown pursuant to
your policies provided at https://help.github.com/articles/dmca-takedown.

1. I have read and understand GitHub’s Guide to Filing a DMCA Notice.

2. The copyrighted work being infringed is our Bamboo product. We make
this product available on our website at
http://www.atlassian.com/software under
a commercial license agreement.

3. The material that is infringing upon the copyrighted work listed in
item 2 above is at
https://github.com/dzmitrykashlach/atlassian-bamboo-core-5.7.2.

4. This infringing material must be deleted in order to remedy the
infringement.

5. My contact information is:

[private]

6. The infringing webpage shows the name of the infringer as Dzmitry
Kashlach, the GitHub username as dzmitrykashlach, and email address
[private]. Atlassian has not found other contact
information of the infringer.

7. I have a good faith belief that use of the copyrighted materials
described above on the infringing web pages is not authorized by the
copyright owner, or its agent, or the law.

8. The information in this notification is accurate, and under penalty
of perjury, I am authorized to act on behalf of the owner of an exclusive
right that is allegedly infringed.

Please contact me if you need any further information to process our
takedown request. A signed letter containing the above information is also
attached to this email.

Very truly yours,

[private]

Legal Counsel
