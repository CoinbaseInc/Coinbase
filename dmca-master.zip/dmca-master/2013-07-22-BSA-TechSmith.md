*** Sent via Email - DMCA Notice of Copyright Infringement *** 

Dear Sir/Madam,

I certify under penalty of perjury, that I am an agent authorized to act on behalf of the owner of the intellectual property rights and that the information contained in this notice is accurate.

I have a good faith belief that the page or material listed below is not authorized by law for use by the individual(s) associated with the identified page listed below or their agents and therefore infringes the copyright owner's rights.

I HEREBY DEMAND THAT YOU ACT EXPEDITIOUSLY TO REMOVE OR DISABLE ACCESS TO THE PAGE OR MATERIAL CLAIMED TO BE INFRINGING.

This notice is sent pursuant to the Digital Millennium Copyright Act (DMCA), the European Union's Directive on the Harmonisation of Certain Aspects of Copyright and Related Rights in the Information Society (2001/29/EC), and/or other laws and regulations relevant in European Union member states or other jurisdictions.

My contact information is as follows:

Organization name: Attributor Corporation as agent for Rights Holders listed below

[private]

My electronic signature follows:

Sincerely,

[private]


*** INFRINGING PAGE OR MATERIAL ***

Infringing page/material that I demand be disabled or removed in consideration of the above:

Rights Holder: BSA - TechSmith

Original Work: Camtasia Studio

Infringing URL: https://gist.github.com/madeinheaven/5958708
