Dear Github,

1. We are the copyright owner of Monit [http://mmonit.com/monit/], an Open Source project released under the GNU Affero General Public License (AGPL). It has come to our understanding that user [private] [https://github.com/mperham] has created a derivate work of Monit called Inspeqtor which infringe upon Monit copyright work.

The work, Inspeqtor which is hosted at GitHub, is far from a “clean-room” implementation. This is basically a rewrite of Monit in Go, even using the same configuration language that is used in Monit, verbatim.

a. [private] himself admits that Inspeqtor is "heavily influenced“ by Monit https://github.com/mperham/inspeqtor/wiki/Other-Solutions.

b. This tweet by [private] demonstrate intent. https://twitter.com/mperham/status/452160352940064768 "OSS nerds: redesign and build monit in Go. Sell it commercially. Make $$$$. I will be your first customer.” - [private] (@mperham)

2. The unauthorized and infringing material is located at:

https://github.com/mperham/inspeqtor

We ask that this material is removed.

We will withdraw this takedown notice if and only if [private] and Inspeqtor adhere to the GNU Affero General Public License which Monit is licensed under. This means;

Our copyright notice is retained in the derivate work, and ALL the derivate work is licensed and provided to users as “open source” under the AGPL. This include the so called pro features of Inspeqtor which are closed source and licensed under a proprietary license.

[private]'s dishonest exploitation of Open Source work by others for his own gain is despicable. We believe Open Source should be used to make the world better for most people, not only for some. At minimum, we need to respect the copyright and the license Open Source work are governed by.

3) You can reach us at:

Email: info@tildeslash.com

Address:
Tildeslash Ltd
Disen, 0587 Oslo,
Norway

Web: http://tildeslash.com/

Phone: [private]

4) The owner of this account: https://github.com/mperham. Can be reached at [private]

5) I have a good faith belief that use of the copyrighted materials described above on the infringing web pages is not authorized by the copyright owner, or its agent, or the law.

6) I swear, under penalty of perjury, that the information in this notification is accurate and that I am the copyright owner, or am authorized to act on behalf of the owner, of an exclusive right that is allegedly infringed.

7)

Best regards
—
For the Monit team
[private]
