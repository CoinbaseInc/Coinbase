June 10, 2014

Re: DMCA notice

Dear GitHub Copyright Agent:

We represent Spritz Technology, Inc. ("Spritz"). A repository on your
website Github.com is infringing at least one copyright owned by Spritz.

This letter is official notification under Section 512(c) of the Digital
Millennium Copyright Act ("DMCA"), and we seek the immediate removal of
infringing material from Github.com.

Spritz is the owner of copyrights in various aspects of Spritz technology,
including Spritz source code, located at
<http://www.spritzinc.com/wp-content/themes/spritz/js>
http://www.spritzinc.com/ and its related pages. Spritz source code files
were copied onto your servers without permission.

The unauthorized and infringing material is located at:

https://github.com/CoincoinNico/Children_Reading_Method

https://github.com/CoincoinNico/Children_Reading_Method/tree/master/app/assets/javascripts

https://github.com/CoincoinNico/Children_Reading_Method/blob/master/app/assets/javascripts/EduDisplay.js

https://github.com/CoincoinNico/Children_Reading_Method/blob/master/app/assets/javascripts/EduModel.js

https://github.com/CoincoinNico/Children_Reading_Method/blob/master/app/assets/javascripts/Edutils.js

These URLs contain source code created and owned by Spritz. We ask that you
immediately remove the above referenced content from Github.com.

I may be contacted at:

[private]

I have a good faith belief that use of the copyrighted materials described
above on the infringing web pages is not authorized by the copyright owner,
or its agent, or the law.

I swear, under penalty of perjury, that the information in this notification
is accurate and that I am the copyright owner, or am authorized to act on
behalf of the owner, of an exclusive right that is allegedly infringed.

Sincerely,

/S/

[private]

Mauriel Kapouytian Woods LLP

27 W. 24th Street, Suite 302

New York, NY 10010

