June 26 2013 - via email

Dear Sir / Dear Madam,

This is a notice in accordance with the Digital Millennium Copyright Act 
of 1998 requesting that you immediately cease to provide access to 
copyrighted material.

I'm the author and owner of computer software "LivIcons - truly animated 
icon pack" on behalf of DeeThemes.

The original material is located at the following URLs:
http://codecanyon.net/item/livicons-303-truly-animated-vector-icons/4618985
http://livicons.com

Please remove the infringing materials containing DeeThemes’ copyrighted 
material found at the following URLs:

https://github.com/vincent-li/smarticon
user: bashao / vincent-li

This user has repeated this again. His previous repo 
(https://github.com/vincent-li/svgicon) with DeeThemes’ work had been 
already locked by [private] on May 26.

I have a good faith belief that use of the copyrighted materials 
described above on the infringing web pages is not authorized by the 
copyright owner, or its agent, or the law.

I swear, under penalty of perjury, that the information in this 
notification is accurate and that I am the copyright owner, or am 
authorized to act on behalf of the owner, of an exclusive right that is 
allegedly infringed.

If you have any further questions or concerns, do not hesitate to 
contact me at the postal address, telephone number, or email address 
indicated below. Thank you.

Sincerely,

deethemes@gmail.com
dee@livicons.com

+7 921 851 76 90

ul. Klinicheskaya, 83
gorod Kaliningrad,
Russian Federation,
236016

[private]
(DeeThemes)