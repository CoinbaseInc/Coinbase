Dear Sir/Madam,

I have read and understand GitHub's Guide to Filing a DMCA Notice.

One of the former employee submitted copyrighted source code of iOS app of our project closefriends to a public repository 

https://github.com/CloseFriends/iOS <https://github.com/CloseFriends/iOS>. 

Entire source code listed there is not authorized by law for use by the individual associated with the identified page listed above or their agents and therefore infringes the copyright owner's rights.

https://github.com/CloseFriends/iOS <https://github.com/CloseFriends/iOS>

I HEREBY DEMAND THAT YOU ACT EXPEDITIOUSLY TO REMOVE OR DISABLE ACCESS TO THE PAGE.

I have a good faith belief that use of the copyrighted materials described above on the infringing web pages is not authorized by the copyright owner, or its agent, or the law.

I swear, under penalty of perjury, that the information in this notification is accurate and that I am the copyright owner, or am authorized to act on behalf of the owner, of an exclusive right that is allegedly infringed.

My contact information is as follows:

[REDACTED]

My electronic signature follows:

[REDACTED]


Sincerely,

[REDACTED]
