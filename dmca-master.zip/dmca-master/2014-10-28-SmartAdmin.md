Identify the copyrighted work you believe has been infringed. The specificity of your identification
may depend on the nature of the work you believe has been infringed, but may include things like
a link to a web page or a specific post (as opposed to a link to a general site URL).

Original Material URL:

https://wrapbootstrap.com/theme/smartadmin­responsive­webapp­WB0573SK0

Demo:

http://192.241.236.31/themes/preview/smartadmin/1.4.1/ajaxversion/#ajax/dashboard.html

Time Stam URL (shows the first version ever made of SmartAdmin with timestamp):

http://192.241.236.31/test2.smartadmin/#ajax/

Author linkedin profile: [private]

Identify the material that you allege is infringing upon the copyrighted work listed in Item #1
above. This identification needs to be reasonably sufficient to permit GitHub to locate the
material. In other words, please include the URL to the material allegedly infringing your
copyright (URL of a website or URL to a post, with title, date, name of the emitter), or link to an
initial post with sufficient data to find it.

I am the original owner of SmartAdmin WebApp. I have built this webapp from scratch to be sold
exclusively on wrapbootstrap.com. It has been selling for over 10 months. If anyone is giving
them out for free (which is not allowed under any of the licenses) then it is affecting my sales
and business. I have found full copies of SmartAdmin sitting on public a repository, this is strictly
not allowed under any circumstances. Each day these assets sits on a public repository I am
having business loss.

Provide information on which GitHub may contact you, including your email address, name,
telephone number and physical address.

[private]

MYORANGE INC.

[private]

Provide the address, if available, to allow GitHub to notify the owner/administrator of the
allegedly infringing webpage or other content, including email address.

I found 3 github repositories that are violating my theme’s copyright. Please find the following
below:

GitHub Username: mcascardi

Full name (as displayed on github): [private]

Email: [private]

GitHub URL: https://github.com/mcascardi/SmartAdmin

The entire repository “SmartAdmin” is infringing copyright, therefore should be
removed.

GitHub Username: [unknown]

Full name (as displayed on github): [unknown]

Email: [unknown]

GitHub URL: https://github.com/RightPlace/SmartAdminTheme

The entire repository “SmartAdminTheme” is infringing copyright, therefore should be
removed.

GitHub Username: virtuecai

Full name (as displayed on github): unknown

Email: [private]

GitHub URL: https://github.com/virtuecai/sa-1.4-angular-version-playframework

The entire repository “sa­1.4­angular­version­playframework” is infringing copyright,
therefore should be removed.

"I have a good faith belief that use of the copyrighted materials described above on the infringing
web pages is not authorized by the copyright owner, or its agent, or the law."

"I swear, under penalty of perjury, that the information in this notification is accurate and that I am
the copyright owner, or am authorized to act on behalf of the owner, of an exclusive right that is
allegedly infringed."

[private]
