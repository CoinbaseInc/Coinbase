

Dear GitHub,

I am [private], copyright holder of the works indicated below.

I believe that there is certain material available at GitHub website that
infringes at least one of copyrights held by the above mentioned party. The
URLs making the infringing materials available are as follows:

1. https://github.com/sambulosenda/Onlineprofilefinder, an exact duplicate
of my copyrighted work SocialKit - Social Networking Platform, description
of which may be found here:
http://codecanyon.net/item/socialkit-social-networking-platform/8493571?WT.ac=category_item&WT.z_author=MarvelKit
;

My name as an author and my copyrighted work is written in the index.php
file. Please take a look for verification purposes.

It is hereby requested that you remove or disable access to this materials
as it appears on your service in as expedient fashion as possible.

[REDACTED] 

I have a good faith belief that use of the material in the manner
complained of is not authorized by the copyright holder, its agent, or the
law and therefore I hereby request removal of the indicated copies.

Under penalty of per jury I certify that information in the notification is
both true and accurate, and I am authorized to act as the holder of the
right that is infringed.

I may be contacted using the details below: [REDACTED]

Thank you for consideration,

[REDACTED]

Regards
