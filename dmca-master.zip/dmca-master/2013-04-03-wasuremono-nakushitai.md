I would like to delete the web page, https://gist.github.com/soto-yamauchi.

my name: 		[private]
       [private]
telephone number: 	[private]
physical address: 	[private]
email address:	[private]

　 the web page:		http://www.mitaka.ne.jp/ruby/ruby2012/work.html
      (the third work from the top)

■タイトル：		忘れ物なくし隊
 Title of the work:	“wasuremono nakushitai”
■テーマ：C　		なんでもOK！ 自由プログラム
 Theme:	 C		free style
■制作者名：		山内 奏人
 Name of developer:	[private]
■地区：		[private]
 District:		Tokyo
■作品概要：		メールやSNSとも連動した、
忘れ物防止支援ソフトです。
   Outline:		the software to help students not to forget what to do
using email and SNS
   [private] won the first prize in the International Ruby Programming Contest (http://www.mitaka.ne.jp/ruby/ruby2012/index.html).  The chinese character of his name is 山内奏人.  The web site is available to identify his work

   I have a good faith belief that use of the copyrighted materials described above on the infringing web pages is not authorized by the copyright owner, or its agent, or the law.

  I swear, under penalty of perjury, that the information in this notification is accurate and that I am the copyright owner, or am authorized to act on behalf of the owner, of an exclusive right that is allegedly infringed.


[private]
[private]
