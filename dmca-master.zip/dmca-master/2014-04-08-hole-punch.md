To Whom It May Concern:

The Github user jensonwu has removed the copyright notice for the project hole-punch.  The infringing work is located at: 
  https://github.com/jensonwu/hole-punch

The copyright notices were removed by this user in: 
  https://github.com/jensonwu/hole-punch/commit/a89e6d34caed089992e6ee23c7bb63655b1456a8

The license itself was removed by this user in: 
  https://github.com/jensonwu/hole-punch/commit/48073c6a2cf0d3b9cebe63b575fb5c0f9ba32220

The copyrighted work is available at:
  https//github.com/ckennelly/hole-punch

Display of this copyright notice and distribution of the license statement is required by the Boost Software License, under which the copyrighted work is licensed.

The Github user jensonwu publicly lists [private] as an email address (https://github.com/jensonwu).  I can be contacted at [private].

I have a good faith belief that use of the copyrighted materials described above on the infringing web pages is not authorized by the copyright owner, or its agent, or the law.

I swear, under penalty of perjury, that the information in this notification is accurate and that I am the copyright owner, or am authorized to act on behalf of the owner, of an exclusive right that is allegedly infringed.

Regards, 
[private]
