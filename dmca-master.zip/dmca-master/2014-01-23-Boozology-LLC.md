Hello, we are a startup creating an on-line magazine with a
blend of information about drinks, cocktails, as well as night-life &
lifestyle. Our site is under construction, but you could check a version under development here: 

boozology.herokuapp.com or boozology.co

Our main domain is boozology.com but we haven’t launched yet, and
our twitter account is @BoozologyDotCom.

Apparently an ex employee from India posted our source code and AWS
security keys on Github after terminating our business relationship.  He
placed the code here and made it available for public use: 

https://github.com/mntlogin/boozolozy3/

This is a breach in our NDA/IP contract agreement, and also
created conflicts with our Amazon Web services agreement. In addition, our AWS
account was abused charging us multiple unauthorized EC2 Instances, and AS3
Buckets (due to the AWS keys exposure). 

We are contacting Github asking  you to please close the user account and take down our source code. We would appreciate if you could provide the user IPs to pursue the user legally.

The person who committed this crime is identified as [private]

I have a good faith belief that use of
the copyrighted materials described above on the infringing web pages is not
authorized by the copyright owner, or its agent, or the law.

I swear, under penalty of perjury, that
the information in this notification is accurate and that I am the copyright
owner, or am authorized to act on behalf of the owner, of an exclusive right
that is allegedly infringed.

We would appreciate any help, we have been greatly affected by
his acts and we will use every possible legal means in our hands to protect our
company. Please let me know if there is anything else I could do for you.

thanks,



[private]

Co-Founder Boozology LLC

[private]
