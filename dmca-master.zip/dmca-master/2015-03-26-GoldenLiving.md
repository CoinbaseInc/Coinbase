I have read and understand GitHub's Guide to Filing a DMCA Notice.

In violation of company policy, a former employee of Golden Living has posted proprietary company code to Github.

The Github account presenting this information publically is sunnyc7 (link <https://github.com/sunnyc7>).

The two folders (Github refers to folders as repositories) containing Golden Living proprietary code are as followed.

Production-Scripts-for-Golden-Living

https://github.com/sunnyc7/Production-Scripts-for-Golden-Living

Ad-Hoc-Scripts-for-Golden-Living

https://github.com/sunnyc7/Ad-Hoc-Scripts-for-Golden-Living

I have a good faith belief that use of the company owned materials described above on the infringing web pages is not authorized by the owner, or its agent, or the law.

I swear, under penalty of perjury, that the information in this notification is accurate and that I am authorized to act on behalf of the owner, of an exclusive right that is allegedly infringed.

Thank you,

[REDACTED]
