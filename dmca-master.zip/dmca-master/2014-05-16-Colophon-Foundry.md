We are contacting you in reference to copyrighted material that is hosted on one of your users github repositories.

Offending file – https://github.com/noelianlirio/cripakt/blob/master/fonts/Apercu.otf

User – https://github.com/noeliaquilaolirio

This file is a piece of Font software that we sell commercially via http://www.colophon-foundry.org/fonts/apercu

We request that this file be taken down effective immediately as this breaches our EULA.

You may contact us via:

[private]

or alternatively, our postal address (below in the signature).

I have a good faith belief that use of the copyrighted materials described above on the infringing web pages is not authorised by the copyright owner, or its agent, or the law.

I swear, under penalty of perjury, that the information in this notification is accurate and that I am the copyright owner, or am authorised to act on behalf of the owner, of an exclusive right that is allegedly infringed.

Thank you,
[private]

[private]
