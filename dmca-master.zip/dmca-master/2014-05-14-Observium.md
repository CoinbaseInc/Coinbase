1) This file on our SVN repository :
http://fisheye.observium.org/browse/Observium/includes/discovery/vlans.inc.php?hb=true
(Line 54 down)
This version of common.php :
http://fisheye.observium.org/browse/Observium/includes/common.php?r1=5082&r2=5082&u=3

2) This commit :
https://github.com/laf/librenms/commit/dc2503a2ff1c16807ccfa0d5227bb25232282f7e

This issue : https://github.com/laf/librenms/compare/issue-laf-32

3) [private]

4) He's one of your users, I assume you know to contact him!
(https://github.com/laf) :)

5) I have a good faith belief that use of the copyrighted materials
described above on the infringing web pages is not authorized by the
copyright owner, or its agent, or the law.

6) I swear, under penalty of perjury, that the information in this
notification is accurate and that I am the copyright owner, or am
authorized to act on behalf of the owner, of an exclusive right that is
allegedly infringed.

7) : [private]
