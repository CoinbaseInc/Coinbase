Sir or madam,

We have identified that copyrighted software owned by our company has been
improperly posted on GitHub here:

https://github.com/AlvinBert/android-ibeacon-Pro-source-code

Our copy of the copyrighted material  is hosted on GitHub in a private
repository located here:

https://github.com/RadiusNetworks/proximity-library-android

The copyrighted material is available to the public only in binary form
here: 

http://developer.radiusnetworks.com/ibeacon/android/pro/download.html

It appears that the source code has been decompiled from the binary,
superficially modified, and posted.  The only contact info I have for the
person who posted the material is from the README.md file in the
repository, where he
lists his email address as [private].   The same README.md
file indicates that he has copied our software, but says it is open source.
 That is incorrect.  The software he copied is not open source. I have
contacted him to request that he take down the material, but I have not
received a response.

I have a good faith belief that use of the copyrighted materials described
above on the infringing web pages is not authorized by the copyright owner,
or its agent, or the law.

I swear, under penalty of perjury, that the information in this
notification is accurate and that I am the copyright owner, or am
authorized to act on behalf of the owner, of an exclusive right that is
allegedly infringed.

My electronic signature is attached to this email.

Sincerely,

[image: Inline image 1]

[private]

Chief Engineer
Radius Networks, Inc.
1228 31st St NW, Suite 2
Washington, DC 20007
U.S.A.

[private]
