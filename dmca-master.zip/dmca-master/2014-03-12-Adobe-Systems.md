Via Electronic Mail

Re: Infringement of the Adobe Systems Incorporated Trademarks and Copyrights

To Whom It May Concern:

1. I am the legal representative authorized to act on behalf of the owner, of certain intellectual property rights ("IP Owner");

2. I have a good faith belief that the website http://illallangi.com/2012/12/19/packaging-lightroom/ offer items and contains materials that are not authorized by the IP Owner, or the law, and therefore infringes the IP Owner's rights; and

3. The information in this notice is accurate.

4. I May Be Contacted At:

            Name of IP Owner:   Adobe Systems Incorporated
           
            Name and Title:     [private], Global Director, Piracy Conversion
           
            Company:            Adobe Systems Incorporated
           
            Address:                    345 Park Avenue, San Jose, CA 95110-2704
           
            Email:                      [private]
           
            Telephone:          [private]
           
            Fax:                        [private]

5. The reasons that the URL website must be suspended are as follows:
     a. Offers information on the circumvention of the technological protection measure implemented by Adobe Systems Inc. to protect its copyrighted works from infringement, as defined by the Digital Millennium Copyright Act, 17 U.S. C. 1201, et seq. or otherwise unauthorized item that violates the IP Owner's trademarks and copyright.
     b. Misuses the IP Owner's brand name, trademarks and copyright.

Please remove this content immediately so that our rights are no longer violated and that the proprietor of this site discontinues its criminal activities.

By submitting this form, Adobe Systems Incorporated agrees to indemnify Rackspace Hosting against all claims or damages related to the suspension of http://illallangi.com/2012/12/19/packaging-lightroom/.

Very truly yours,

[private]
