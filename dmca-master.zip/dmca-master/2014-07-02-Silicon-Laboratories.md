Dear GitHub Copyright Agent:

I, the undersigned, state UNDER PENALTY OF PERJURY that:

[1] I am, a person injured, or an agent authorized to act on behalf of a person injured by a violation of the U.S. Copyright laws, in particular section(s) 1201(a)(2) and/or 1201(b)(1) of Title 17 of the United States Code, commonly referred to as the Digital Millennium Copyright Act, or "DMCA"; 

[2] I May Be Contacted At:
Name of Injured Party: SILICON LABORATORIES INC. ("Silicon Labs")
Name and Title: [private] 
Company: SILICON LABORATORIES INC.
Address: 400 West Cesar Chavez
City, State, and Zip: Austin, Texas 78701 Email address: [private] 
Telephone: [private]
Fax: [private] 

[3] I have a good faith belief that the file-downloads identified below (by URL) are unlawful under these laws because, among other things, the files are unauthorized copies of Silicon Labs' copyrighted code;
[4] Reason: Content Type: "Custom Firmware" files
Violation(s): Trafficking software code that is in violation of copyright protection.
[5] Please act expeditiously to remove the file-downloads found at the following URLs:

https://github.com/j1nx/Openlinux.Amlogic.M6/tree/master/drivers/amlogic/dvb/si2168/include

Entire Code listing.

https://github.com/j1nx/Openlinux.Amlogic.M6/blob/master/drivers/amlogic/dvb/si2168/include/Si2168_0B_ROM1_Firmware_0_Cb20.h

Entire Code listing.

https://github.com/j1nx/Openlinux.Amlogic.M6/blob/master/drivers/amlogic/dvb/si2168/include/Si2168_10_ROM1_Patch_0_Cb20.h

Entire Code listing.

https://github.com/j1nx/Openlinux.Amlogic.M6/blob/master/drivers/amlogic/dvb/si2168/include/Si2168_20_ROM2_Patch_2_0b11.h

Entire Code listing.

https://github.com/j1nx/Openlinux.Amlogic.M6/blob/master/drivers/amlogic/dvb/si2168/include/Si2168_20_ROM2_Patch_2_0b28.h

Entire Code listing.

https://github.com/j1nx/Openlinux.Amlogic.M6/blob/master/drivers/amlogic/dvb/si2168/include/Si2168_20_ROM2_Patch_2_0b30.h

Entire Code listing.

https://github.com/j1nx/Openlinux.Amlogic.M6/blob/master/drivers/amlogic/dvb/si2168/include/Si2168_30_ROM3_Patch_3_0b10.h

Entire Code listing.

https://github.com/j1nx/Openlinux.Amlogic.M6/blob/master/drivers/amlogic/dvb/si2168/include/Si2168_30_ROM3_Patch_3_0b11.h

Entire Code listing.

https://github.com/j1nx/Openlinux.Amlogic.M6/blob/master/drivers/amlogic/dvb/si2168/include/Si2168_30_ROM3_Patch_3_0b2.h

Entire Code listing.

https://github.com/j1nx/Openlinux.Amlogic.M6/blob/master/drivers/amlogic/dvb/si2168/include/Si2168_CUSTOMTER.h

Entire Code listing.

https://github.com/j1nx/Openlinux.Amlogic.M6/blob/master/drivers/amlogic/dvb/si2168/include/Si2168_Commands.h

Entire Code listing.

https://github.com/j1nx/Openlinux.Amlogic.M6/blob/master/drivers/amlogic/dvb/si2168/include/Si2168_Commands_Prototypes.h

Entire Code listing.

https://github.com/j1nx/Openlinux.Amlogic.M6/blob/master/drivers/amlogic/dvb/si2168/include/Si2168_L1_API.h

Entire Code listing.

https://github.com/j1nx/Openlinux.Amlogic.M6/blob/master/drivers/amlogic/dvb/si2168/include/Si2168_L2_API.h

Entire Code listing.

https://github.com/j1nx/Openlinux.Amlogic.M6/blob/master/drivers/amlogic/dvb/si2168/include/Si2168_L2_API.h

Entire Code listing.

https://github.com/j1nx/Openlinux.Amlogic.M6/blob/master/drivers/amlogic/dvb/si2168/include/Si2168_NO_TER.h

Entire Code listing.

https://github.com/j1nx/Openlinux.Amlogic.M6/blob/master/drivers/amlogic/dvb/si2168/include/Si2168_NXP20142.h

Entire Code listing.

https://github.com/j1nx/Openlinux.Amlogic.M6/blob/master/drivers/amlogic/dvb/si2168/include/Si2168_Platform_Definition.h

Entire Code listing.

https://github.com/j1nx/Openlinux.Amlogic.M6/blob/master/drivers/amlogic/dvb/si2168/include/Si2168_Properties.h

Entire Code listing.

https://github.com/j1nx/Openlinux.Amlogic.M6/blob/master/drivers/amlogic/dvb/si2168/include/Si2168_Properties_Strings.h

Entire Code listing.

https://github.com/j1nx/Openlinux.Amlogic.M6/blob/master/drivers/amlogic/dvb/si2168/include/Si2168_Si2146.h

Entire Code listing.

https://github.com/j1nx/Openlinux.Amlogic.M6/blob/master/drivers/amlogic/dvb/si2168/include/Si2168_Si2148.h

Entire Code listing.

https://github.com/j1nx/Openlinux.Amlogic.M6/blob/master/drivers/amlogic/dvb/si2168/include/Si2168_Si2156.h

Entire Code listing.

https://github.com/j1nx/Openlinux.Amlogic.M6/blob/master/drivers/amlogic/dvb/si2168/include/Si2168_Si2158.h

Entire Code listing.

https://github.com/j1nx/Openlinux.Amlogic.M6/blob/master/drivers/amlogic/dvb/si2168/include/Si2168_Si2173.h

Entire Code listing.

https://github.com/j1nx/Openlinux.Amlogic.M6/blob/master/drivers/amlogic/dvb/si2168/include/Si2168_Si2176.h

Entire Code listing.

https://github.com/j1nx/Openlinux.Amlogic.M6/blob/master/drivers/amlogic/dvb/si2168/include/Si2168_Si2178.h

Entire Code listing.

https://github.com/j1nx/Openlinux.Amlogic.M6/blob/master/drivers/amlogic/dvb/si2168/include/Si2168_Si2190.h

Entire Code listing.

https://github.com/j1nx/Openlinux.Amlogic.M6/blob/master/drivers/amlogic/dvb/si2168/include/Si2168_Si2196.h

Entire Code listing.

https://github.com/j1nx/Openlinux.Amlogic.M6/blob/master/drivers/amlogic/dvb/si2168/include/Si2168_typedefs.h

Entire Code listing.

https://github.com/j1nx/Openlinux.Amlogic.M6/blob/master/drivers/amlogic/dvb/si2168/include/SiLabs_API_L3_Console.h

Entire Code listing.

https://github.com/j1nx/Openlinux.Amlogic.M6/blob/master/drivers/amlogic/dvb/si2168/include/SiLabs_API_L3_Wrapper.h

Entire Code listing.

https://github.com/j1nx/Openlinux.Amlogic.M6/blob/master/drivers/amlogic/dvb/si2168/include/Silabs_L0_API.h

Entire Code listing.

https://github.com/j1nx/Openlinux.Amlogic.M6/blob/master/drivers/amlogic/dvb/si2168/include/sifrontend.h

Entire Code listing.

[6] I have a good faith belief that copyright protection measures identified above are not authorized by law; and

[7] The information in this notice is accurate.

Thank you for your kind assistance.

Truthfully,

[private]

Silicon Laboratories Inc.
