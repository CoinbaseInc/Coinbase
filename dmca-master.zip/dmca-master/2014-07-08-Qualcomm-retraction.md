Recently Qualcomm issued a number of DMCA take-down requests for files posted to GitHub containing Qualcomm Confidential markings. Those requests were identified on the GitHub website at [https://github.com/github/dmca/blob/master/2014-07-02-Qualcomm.md](https://github.com/github/dmca/blob/master/2014-07-02-Qualcomm.md).

Since issuing these requests, we have been advised that at least one of these files may, in fact, not be Qualcomm Confidential. At this time, Qualcomm is retracting all of those DMCA take-down requests, and will be either reviewing such files further for possible approval for posting, or reaching out collaboratively to the project maintainers for assistance in addressing any remaining concerns. To those project maintainers who received these DMCA notices, we apologize for the approach taken.

Best regards,

[private]
