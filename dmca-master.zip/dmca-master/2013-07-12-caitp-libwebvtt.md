My intellectual property and copyright regarding repository

https://github.com/caitp/libwebvtt 

have been infringed.

The organization Mozilla have merged this code, re-branded it, claimed
ownership, and have relicensed it under terms which I do not agree with, at 

https://github.com/mozilla/webvtt. 

This work was done as part of a university program, and under school policy and, (to my understanding) provincial law, the intellectual property and copyright belong to me. Any licensing arrangements have been coerced and not within my power to stop.

There are several forks of this on GitHub, and I would ask that each of
these repositories containing code derived from my own work be removed
from GitHub. We have discussed these matters privately, but unfortunately have not been able to come to an agreement which fullfils my needs.

Forks of the repository incorporating unlicensed code:

https://github.com/humphd/webvtt

https://github.com/rillian/webvtt

https://github.com/mozilla/webvtt

https://github.com/RickEyre/webvtt

https://github.com/jraff/webvtt

https://github.com/daleee/webvtt

https://github.com/ShayanZafar/webvtt

https://github.com/KyleBarnhart/webvtt

https://github.com/mafidchao/webvtt

https://github.com/limed3/webvtt

https://github.com/Lynart/webvtt

https://github.com/dperit/webvtt

https://github.com/datorman/webvtt

among others

It is my understanding of my college's student policy, as well as canadian
law, lead me to believe that I am entirely within my rights to demand that
these are each removed.

I have a good faith belief that use of the copyrighted materials described above on the infringing web pages is not authorized by the copyright owner, or its agent, or the law.

I swear, under penalty of perjury, that the information in this
notification is accurate and that I am the copyright owner, or am
authorized to act on behalf of the owner, of an exclusive right that is
allegedly infringed.

Sincerely,

[private]

[private]
