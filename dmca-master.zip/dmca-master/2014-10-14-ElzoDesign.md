[private]

Elzo Design
[private]

E: [private]
E: [private]

*I am the copyright owner of the source code that is being infringed at:*
https://github.com/Wild1145/LinkMe

*The original content you can find at *
https://bitbucket.org/kyled1986/link-me
http://dev.bukkit.org/bukkit-plugins/link-me/ ( The date on this project does not tie with the sate of the spigot page this is due to disagreements with the Bukkit staff and the project was removed and has since been re uploaded.)

Copies of the source code and or any reference being infringed are included to assist with their removal from the infringing Web sites.

If you would like to contact the person who I have filed this DMCA take down request you can do so by emailing them at either [private] or [private].

This letter is official notification under the provisions of Section 512(c) of the Digital Millennium Copyright Act (“DMCA”) to effect removal of the above-reported infringements. I request that you immediately issue a cancellation message as specified in RFC 1036 for the specified postings and prevent the infringer, who is identified by its Web address, from posting the infringing photographs to your servers in the future. Please be advised that law requires you, as a service provider, to “expeditiously remove or disable access to” the infringing photographs upon receiving this notice. Noncompliance may result in a loss of immunity for liability under the DMCA.

I have a good faith belief that use of the material in the manner complained of here is not authorized by me, the copyright holder, or the law. The information provided here is accurate to the best of my knowledge. I swear under penalty of perjury that I am the copyright holder.

I swear, under penalty of perjury, that the information in this notification is accurate and that I am the copyright owner, or am authorized to act on behalf of the owner, of an exclusive right that is allegedly infringed.

If you would like to contact me regarding this matter then please email me at [private] and i will cohere to respond to your emails as soon as possible.

Sincerely,

[private]
