Hi this is [private].

I am the Abuse Specialist of Link-Busters.com.
I am authorized to act on behalf of The MIT Press:

Contact Information:

[private]/Abuse Specialist

Link-Busters.com
Buisweg 36
the Netherlands

[private]

email: [private]

We have found the following link(s) on your server which contain copies of the following record/product and are not authorized by us:

Product: Cormen - Introduction to algorithms

Company: The MIT Press

Links:

https://github.com/amujika/SWERC-UPV-EHU/blob/master/Cormen,%20%20Leiserson,%20Rivest,%20Stein%20-%20Introduction%20to%20Algorithms%203rd.pdf

I have good faith belief that use of the aforementioned material is not authorized by the copyright owner, its agents, or the law.

I swear, under penalty of perjury, that the information in this notification is accurate and that I am the copyright owner, or am authorized to act on behalf of the owner, of an exclusive right that is allegedly infringed.

Please take down these links as soon as possible,

Regards,

[private]

Link-Busters.com
