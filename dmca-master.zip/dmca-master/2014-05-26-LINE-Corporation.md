Dear GitHub Team,

My name is [private] and I am writing on behalf of LINE Corporation, in
regards to a copyright violation on the GitHub website.

I had previously submitted a claim but was told that I need to include
more specific information about the copyrighted work thus am
re-submitting this letter.
Please kindly note that because our source code is confidential information, we are unable to disclose such information.

I believe in good faith that "LINE 非公式 API を使ってログイン (English translation: Log-in using LINE Unofficial API)" infringes
LINE Corporation's copyrights and that the use of our source code is not authorized
by the rights holder, its agent or the law.

The reported pages contained protocol documentation that is based on our mobile message application, LINE.

Please see below for all the different platforms for which LINE is available:

http://line.me/en-US/download

The below posts on GitHub are infringing upon our copyrighted source code, without any prior consent or
permission. We request that the files be removed from the GitHub website accordingly..

The information in this notification is accurate and I swear under penalty of
perjury that I am authorized to act on behalf of the owner of an exclusive
right that is alleged to be infringed.

Infringing Content on GitHub:

https://gist.github.com/wakuworks/2144164

Page name:　LINE 非公式 API を使ってログイン (English translation: Log-in using LINE Unofficial API)

Publisher

Name: wakuworks

https://gist.github.com/wakuworks

Infringing Party:

[private]

Copyright information:

Copyright owner: LINE Corporation

URL: http://line.me/en/

https://marketplace.firefox.com/app/line/

Contact information:
Name: [private]
Position: IP Strategy Team, Legal Department
Company: LINE Corporation
E-mail: [private]
Telephone: [private]

Thank you for your attention to this matter and we look forward to hearing from you soon.

Best regards,

[private]
