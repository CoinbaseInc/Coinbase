- I have read and understand GitHub's Guide to Filing a DMCA Notice.

- Portions of our code base have been reproduced and posted on GitHub
without our authority. They can be found here:  
https://github.com/in6kPythonDev/sample_django_code/tree/master/eventbrite_sample

- The Code should be removed by GitHub expeditiously.

- Contact Information: [private]

- Provide contact information, if you know it, for the alleged
infringer. [private]

- I have a good faith belief that use of the copyrighted materials
described above on the infringing web pages is not authorized by the
copyright owner, or its agent, or the law.

- I swear, under penalty of perjury, that the information in this
notification is accurate and that I am the copyright owner, or am
authorized to act on behalf of the owner, of an exclusive right that is
allegedly infringed.

[private]

--

[private]
