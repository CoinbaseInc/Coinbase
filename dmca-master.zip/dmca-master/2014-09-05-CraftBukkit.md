My name is [private]. Multiple repositories are infringing on my
software copyright by the distribution of a software known as CraftBukkit
and some other aliases, including Spigot.

Original content can be found at

https://github.com/Wolvereness/Bukkit-Bleeding/commits?author=Wolvereness

https://github.com/Wolvereness/Bukkit-Bleeding/commit/0a0fee8be25bf8a732abff2d66a89a64614b6327

and the appropriate license for previously mentioned content can be found at

https://github.com/Wolvereness/Bukkit-Bleeding/blob/f210234e59275330f83b994e199c76f6abd41ee7/LICENCE.txt

The provided license requires the use of included or linking code to
provide the original source under the GNU GPL license version 3, or any
later version. An official notice has been sent to Mojang AB, whereas the
Chief Operating Officer, [private], responded with the clear text:
Mojang has not authorized the inclusion of any of its proprietary

Minecraft software (including its Minecraft Server software) within the
Bukkit project to be included in or made subject to any GPL or LGPL
license, or indeed any other open source license

As the Minecraft Server software is included in CraftBukkit, and the
original code has not been provided or its use authorized, this is a
violation of my copyright. I have a good faith belief the distribution of
CraftBukkit includes content of which the distribution is not authorized by
the copyright owner, it's agent, or the law.

Pages including infringing content:

https://github.com/Bukkit/CraftBukkit/ - infringing as of commit

https://github.com/Bukkit/CraftBukkit/commit/3b28b44df4ff89afa39c302a19826d19e2ea3368

and every subsequent commit, including all forks that contain this commit

https://github.com/SpigotMC/Spigot-Server - a fork of CraftBukkit not
marked as such, but includes the aforementioned commit

https://github.com/SpigotMC/Spigot - as of the repository's creation

https://github.com/SpigotMC/Spigot/commit/622229778428e822be7c97d9c5f08ddb6281d97f
it
uses infringing commit

https://github.com/Bukkit/CraftBukkit/commit/c056293b38cb9a1296937d91746b175252be044a

and all forks that share a common first commit

https://github.com/MinecraftPortCentral/Cauldron - infringing as of

https://github.com/MinecraftPortCentral/Cauldron/commit/e74f5ca7d40f26f4ed5455568c2002d725672a70

and every subsequent commit, including all forks that contain this commit

https://github.com/MinecraftPortCentral/MCPC-Plus-Legacy/ - infringing as
of the repository's creation

https://github.com/MinecraftPortCentral/MCPC-Plus-Legacy/commit/f30b4ded3ba994affc7595ed7ab50c344b14a532

I swear, under penalty of purjury, that the information in this
notification is accurate and that I am the copyright owner, or am
authorized to act on behalf of the owner, of an exclusive right that is
allegedly infringed.

Pursuant to the Digital Millennium Copyright Act (17 U.S.C. § 512(c)), the
above mentioned pages need to be expeditiously removed or access-of
disabled.

Electronically Signed:

[private]

[private]
