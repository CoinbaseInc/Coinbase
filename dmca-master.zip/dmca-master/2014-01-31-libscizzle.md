A private code regarding the detection of x86 shellcode is being
infringed upon by the repository hosted at

<https://github.com/wheezey/libscizzle/>

More specifically, the entire
repository consists soly of this copyrighted work; a binary library
build and required headers to link against.

The infringement is easily identifiable by the copyright headers in the
header file, mentioning this very email address.

My contact information is:

[private]

I have a good faith belief that use of the copyrighted materials
described above on the infringing web pages is not authorized by the
copyright owner, or its agent, or the law.

I swear, under penalty of perjury, that the information in this
notification is accurate and that I am the copyright owner, or am
authorized to act on behalf of the owner, of an exclusive right that is
allegedly infringed.


Thanks
[private]