Dear Sir or Madam:

I, [private], of the physical address below, swear under penalty of perjury that I have detected infringements of my copyright interests as detailed in the report below. 
 
I have reasonable good faith belief that use of the material in the manner complained of in the report below is not authorized by myself, my agents, or the law. The information provided herein is accurate to the best of my knowledge. Therefore, this letter is an official notification to effect removal of the detected infringement listed in the report below. The report below specifies the exact location of the infringement.
 
I hereby request that you immediately remove or block access to the infringing material, as specified in the copyright laws, and insure the user refrains from using or sharing with others the unauthorized materials in the future (see, 17 U.S.C. 512). Please send a prompt response indicating the actions you have taken to resolve this matter, making sure to reference DMCA-CASE#29474 in your response.

Nothing in this letter shall serve as a waiver of any rights or remedies of [private] with respect to the alleged infringement, all of which are expressly reserved. If you need to contact me, my contact information is located at the bottom of this letter.
 
Evidentiary Information:
Infringing IP Address(es): [private]
Infringed Work(s): http://infiSTAR.de/
Infringing URL(s): https://github.com/DrWhatNoName/InfiSTAR_AC
 
Explanation:
"Public posting of my code/software/tool with the knowledge that this is breaking my terms!"
The github user uploaded my code on here:

https://github.com/DrWhatNoName/InfiSTAR_AC

and linked it on a 'hacker' board:

http://www.unknowncheats.me/forum/arma-2/106571-infistar-anti-cheat-admin-backdoor-2-a-5.html

This is against my terms and I need this to get removed as soon as possible.

Regards,

[private]