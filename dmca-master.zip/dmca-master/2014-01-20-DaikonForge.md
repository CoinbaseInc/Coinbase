The repository at 

https://github.com/modesttree/DaikonForge 

is in violation of the Digital Millenium Copyright Act.

If you look in the majority of the source code files, you will see that
they are copyrighted. Additionally, the product
(link<http://www.daikonforge.com/dfgui>)
was purchased on the Unity Asset Store (link <http://u3d.as/5dQ>), which
has an End-User License Agreement that specifically forbids distribution of
the source code (link <http://unity3d.com/company/legal/as_terms>).

As the copyright holder I am requesting that this content be removed or
made private. Publicly posting the source code for everyone to access is
clearly against the license agreement under which the software was
purchased, and is a clear violation of copyright law.

This repository appears to belong to ModestTree, which lists
info@modesttree.com as their contact email.

I swear, under penalty of perjury, that the information in this
notification is accurate and that I am the copyright owner, or am
authorized to act on behalf of the owner, of an exclusive right that is
allegedly infringed.


[private]

Signed,

[private]
