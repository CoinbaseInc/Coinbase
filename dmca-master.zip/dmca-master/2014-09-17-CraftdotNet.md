This is my repository: https://github.com/SirCmpwn/Craft.Net

You can consider this a DMCA takedown notice. I state under penalty of
perjury that I am the lawful copyright holder and that I believe my
content is being used in bad faith by "TeamInferno". The material is
published at this URL:

https://github.com/TeamInferno/Server

And more specifically, here:

https://github.com/TeamInferno/Server/tree/master/externals/Inferno

I have a good faith belief that the use of the material in the manner
complained of is not authorized by the copyright owner, its agent, or
the law.

I require that not only the current revision be corrected, but that the
improperly licensed content be purged from the history of the repository.

[private]
