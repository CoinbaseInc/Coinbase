Thank you for your speedy response.

Since the locking of the offending repositories, the owner of them has
apologized and become more amenable to negotiations. We have come to an
agreement and thus I would like to retract my previous DMCA takedown
request ( https://github.com/github/dmca/blob/master/2014-07-15-notcake.md
). On behalf of the owner of the infringing repositories, I would like to
request for the following two repositories mentioned to be restored until
further notice:

https://github.com/Capster/GPad

https://github.com/Capster/Metro

Regards,

[private]
