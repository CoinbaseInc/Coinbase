To Whom It May Concern: 

The following information is presented for the purposes of removing web content that infringes on our copyright per the Digital Millennium Copyright Act. We appreciate your enforcement of copyright law and support of our rights in this matter.

Identification of Copyrighted Work 

The copyrighted work at issue is the Android Developer Icon Set that appears on 

http://www.androidicons.com/. 

Identification of Infringed Material 

It has become evident that GitHub user [private] a.k.a. “Thetutlage” 

(https://github.com/thetutlage) 

has violated our copyright by uploading our Android Developer Icon Set for free download: 

https://github.com/thetutlage/Free-Android-Icons

We require that all alleged copyright violations be removed from the repository in question and the onus is on the infringer to locate and remove all alleged copyright violations of the complainant’s property. The alleged offending materials (or repository) must be wholly removed.

The URL of the infringing content is as follows: 

https://github.com/thetutlage/Free-Android-Icons 


Copyright Owner Contact Information 

[private]  

CTO

Opoloo GbR

+49 6131-4955539

Copyright Infringers Information 
[
private]

[private]

Copyright Owners Statement 

I have a good faith belief that use of the copyrighted materials described above on the allegedly infringing web pages is not authorized by the copyright owner, its agent, or the law.
I swear, under penalty of perjury, that the information in the notification is accurate and that I am the copyright owner or am authorized to act on behalf of the owner of an 
exclusive right that is allegedly infringed.

Signed on this day, the 24th of June, 2013, in Mainz, Germany

[private]