Please remove https://github.com/cisdev383/socialwork

This is a copy of the source code of https://socialhood.com maintained at https://github.com/socialhood/ - private copyrighted data that an outside contractor copied and did not keep private. The contractor has not responded to our request to remove the repo or modify the repo to be private. This is a major security concern for our company because details about our site's source code have been leaked to the internet.

I can be reached at:

[private]
[private], SocialHood, Inc.
1608 N Milwaukee Ave, Suite 707
Chicago, IL 60647

[private]

[private]

I have a good faith belief that use of the copyrighted materials described above on the infringing web pages is not authorized by the copyright owner, or its agent, or the law.

I swear, under penalty of perjury, that the information in this notification is accurate and that I am the copyright owner, or am authorized to act on behalf of the owner, of an exclusive right that is allegedly infringed.

[private]
President, SocialHood, Inc.
