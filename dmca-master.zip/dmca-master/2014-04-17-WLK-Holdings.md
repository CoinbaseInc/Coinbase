Dear GitHub Inc,

This email is to notify you that some copyrighted material that we own has been posted on your website by a particular user, that we need removed ASAP.

The copyrighted work that has infringed is

https://github.com/enpiiweb/SIMB-1305-Fan2cash
https://github.com/enpiiweb/SIMB-1306-Mobilelikez

We own the sites www.mobilelikez.com<http://www.mobilelikez.com> and www.fans2cash.com<http://www.fans2cash.com>, This is a complete copy of our site, taken by a hacker, and posted online to the public.

Everything listed in the github URLs above must be removed, in fact this user should be penalized because all of the content he uploads is copyrighted material, hacked and stolen from other websites like mine, but that is up to your discretion. We only care that our content is removed.

You can contact me ([private]) on [private]. My physical address is [private].

Please email or call me directly to notify me when this has been removed.

I have a good faith belief that use of the copyrighted materials described above on the infringing web pages is not authorized by the copyright owner, or its agent, or the law.

"I swear, under penalty of perjury, that the information in this notification is accurate and that I am the copyright owner, or am authorized to act on behalf of the owner, of an exclusive right that is allegedly infringed.

Signed by myself, Director of the company WLK HOLDINGS PTY LTD, [private]
