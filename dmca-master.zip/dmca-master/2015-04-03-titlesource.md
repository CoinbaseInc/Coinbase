1) I have read and understand GitHub's Guide to Filing a DMCA Notice.

2) The subject published copyrighted work whose source code currently resides on https://github.com/wonkim00/Area51Web can be viewed at www.titlesource.com. Note: that the code that is currently on GitHub's site is the server side source code that generates the Title Source site on the client side.

3) The code that is located in the wonkim00/Area51Web repository is the property of Title Source. This is source code that was developed for Title Source in 2011.

4) Currently we would like the code removed from the GitHub site.

5) This code is the property of Title Source. We are currently trying to contact [private] but have been unsuccessful so far.

6) I have a good faith belief that use of the copyrighted materials described above on the infringing web pages is not authorized by the copyright owner, or its agent, or the law.

7) I swear, under penalty of perjury, that the information in this notification is accurate and that I am the copyright owner, or am authorized to act on behalf of the owner, of an exclusive right that is allegedly infringed.

[private]

First National Building  
9th Floor, West 662 Woodward Ave  
Detroit, MI 48226  
[private]  
titlesource.com
