We are the publisher of the eBooks listed below and represent the copyright
owners of the eBooks being infringed at:

https://github.com/uttamlavhate/jquery/blob/master/Zend%20Certification/PHP%20Architect%2C%20Zend%20PHP%205%20Certification%20Study%20Guide.pdf

I have read and understand GitHub's Guide to Filing a DMCA Notice. The PDF
file is a copy of the book “Zend PHP 5 Certification Study Guide”,
copyright 2006.

In order to remedy the infringement, the PDF file must not be in a public
repository. The username associated is “uttamlavhate”.

This letter is official notification under the provisions of Section 512(c)
of the Digital Millennium Copyright Act ("DMCA") to effect removal of the
above-reported infringements. I request that you immediately issue a
cancellation message as specified in RFC 1036 for the specified postings
and prevent the infringer, who is identified by its Web address, from
posting the infringing material to your servers in the future. Please be
advised that law requires you, as a service provider, to "expeditiously
remove or disable access to" the infringing material upon receiving this
notice. Noncompliance may result in a loss of immunity for liability under
the DMCA.

I have a good faith belief that use of the copyrighted materials described
above on the infringing web pages is not authorized by the copyright owner,
or its agent, or the law.

I swear, under penalty of perjury, that the information in this
notification is accurate and that I am the copyright owner, or am
authorized to act on behalf of the owner, of an exclusive right that is
allegedly infringed.

Please send me at the address noted below a prompt response indicating the
actions you have taken to resolve this matter.

Sincerely,

[REDACTED]

musketeers.me LLC

[REDACTED]
