On January 9th, someone successfully compromised the security of our server and copied our private github repo, which is hosted on github at [private]

On April 6th that repo was published publicly under a third-party github account: https://github.com/sucks0000/Python_Django_Angular

This is clearly our copyright protected code and this amounts to not a simple license violation (they have no license from us and this is not open source code) but instead is clear cut theft of IP. The entirety of the repo is infringing and it should be deleted from github as soon as possible.

My contact information is: 

[private]  
PlaceSpeak Inc  
1682 West 7th Ave, Suite 205, Vancouver BC V6J 4S6
[private]

We do not know the identify of or have contact information for the infringer.

I have a good faith belief that use of the copyrighted materials described above on the infringing web pages is not authorized by the copyright owner, or its agent, or the law.

I swear, under penalty of perjury, that the information in this notification is accurate and that I am the copyright owner, or am authorized to act on behalf of the owner, of an exclusive right that is allegedly infringed.

I have read and understand GitHub's Guide to Filing a DMCA Notice

Regards, [private] 
