Dear GitHub Copyright Agent:

My name is [private], I have found that two of my works which are not intended to be shared with public are distributed via your service.

As the author of the items, I am the copyright owner of the files.

https://github.com/mdqyy/EyeTracker_V2

https://github.com/mdqyy/EyeTracker_V3

I have a good faith belief that use of the materials in the manner complained of here is not authorized by me.

I swear, under penalty of perjury, that the information in this notification is accurate and that I am the copyright owner.

I would like you to take down the files.

Thank you for your kind assistance.

Regards,

[private]

Postal Address:

[private]

Phone: [private]

Email [private]
