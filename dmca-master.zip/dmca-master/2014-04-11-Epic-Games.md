I, [private], am authorized to act on behalf of the owner of an exclusive right that is being infringed.

I am writing to complain about the unauthorized display of restricted trademarked and copyrighted content from Epic Games, Inc.'s Unreal Engine 4.  Unreal Engine 4 (or UE4) contains registered trademarks in the US and elsewhere and is copyrighted by Epic in the US.  The content of this GitHub repository contains unauthorized use of these trademarks and copyrighted content from UE4.

The following URLs identify the infringing content:

https://github.com/xxxdarklegolasdu92/UnrealEngine

https://github.com/Fitzgerald777/UnrealEngine4

I may be contacted as follows:  [private], [private], [private], Epic Games, Inc., 620 Crossroads Blvd., Cary, NC, 27518.

I have a good faith belief that use of the material in the manner complained of is not authorized by the copyright owner, its agent, or the law.

The information in this notification is accurate, and under penalty of perjury, I am authorized to act on behalf of Epic Games, Inc., the owner of an exclusive right that is being infringed.

Thanks,

[private]