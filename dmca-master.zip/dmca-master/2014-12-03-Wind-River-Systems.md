To Whom It May Concern:
The GitHub web site is posting Wind River Systems, Inc.'s ("Wind River") proprietary copyrighted information in violation of Wind River's intellectual property rights at the following url:
https://github.com/jannson/vxworks-like-kernel/tree/master/src/os

Pursuant to the Digital Millennium Copyright Act, below please find a Notification of Claimed Copyright Infringement on behalf of Wind River. Wind River requests that you please review the notification below, let us know if you require additional information and take immediate action to remove, or disable access to, the infringing information.
Thank you in advance for your assistance in this matter.
Sincerely,

[Private]

Corporate Counsel
Wind River Systems, Inc.

[private]

Work: [private]

Notification of Claimed Copyright Infringement

(Digital Millennium Copyright Act, 17 U.S.C. § 512)

To: GitHub

1. Name of copyright holder: Wind River Systems, Inc.

2. Name of person authorized to act on behalf of copyright holder: Shikha Donde

3. Identify the copyrighted work claimed to have been infringed: Proprietary source code VxWorks. The source code for VxWorks Kernel has directly been copied by the user, with the copyright notifications removed.

4. Identification of the material that is claimed to be infringing or to be the subject of infringing activity that is to be removed or access to which is to be disabled:
The website provides unauthorized access to proprietary source code VxWorks Kernel

   https://github.com/jannson/vxworks-like-kernel/tree/master/src/os

5. GitHub user: Jannson: http://jannson.github.io/

6. Name of complaining party: Wind River Systems, Inc.

7. Address: 500 Wind River Way, Alameda, CA 94501

8. Phone: [private]

9. E- mail: [private]

I hereby affirm I have read and understand GitHub's Guide to Filing a DMCA Notice.

I hereby affirm, I have a good faith belief that use of the copyrighted materials described above on the infringing web pages is not authorized by the copyright owner, or its agent, or the law.

I hereby swear, under penalty of perjury, that the information in this notification is accurate and that I am the copyright owner, or am authorized to act on behalf of the owner, of an exclusive right that is allegedly infringed.
Best,

/s/ [private] Esq.

Signature of person authorized to act
