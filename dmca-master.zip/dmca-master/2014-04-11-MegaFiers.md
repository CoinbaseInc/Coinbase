DMCA Takedown notice:

https://github.com/KRechowicz/PE_Simulator

I am the author and copyright holder of a piece of software called MegaFiers which is paid for plugin to the Unity3D game engine http://u3d.as/content/chris-west/mega-fiers/1Qa

Your site is hosting a copy of my software in breach of my copyright and I request its immediate removal. The file is located at https://github.com/KRechowicz/PE_Simulator/tree/master/PE%20Simulator/Assets/Mega-Fiers

My contact details are:

[private]

I state that upon a good faith belief the disputed use of the material or activity is not authorized by the copyright or intellectual property owner, its agent or the law; and

I state made under penalty of perjury, that the Complainant is the copyright or intellectual property owner or is authorized to act on behalf of the copyright or intellectual property owner and that the information provided in the notice is accurate.

Signature: [private]
