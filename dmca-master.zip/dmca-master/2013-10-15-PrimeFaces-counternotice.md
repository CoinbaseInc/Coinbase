Dear GitHub,


The access to the following material has been disabled:

1. http://primefaces.github.io/ (GitHub Page)
2. http://primefaces.github.io/repository (GitHub Page)
3. https://github.com/primefaces.github.com (GitHub Repository)

I have a good faith belief that this material was removed or disabled in
error as a result of mistake or misidentification of the material. I
declare that this is true and accurate under penalty of perjury under the
laws of the United States of America.

I have no access to PrimeFaces Elite Releases. The distributed releases
published at GitHub Pages are the result of an integration effort of each
change published at the public repository -  to which anyone can have
access - from this Google Code project licensed under Apache License 2.0:
https://code.google.com/p/primefaces/.

I consent to the jurisdiction of any judicial district in which GitHub may
be found, and I will accept service of process from the person who provided
notification or an agent of such person.

By this letter, I do not waive any other rights, including the ability to
pursue an action for the removal or disabling of access to this material,
if wrongful.

Having complied with the requirements of Section 512(g)(3), I remind you
that you must now replace the blocked or removed material and cease
disabling access to it within fourteen business days of your receipt of
this notice. Please notify me when this has been done.

I appreciate your prompt attention to this matter. If you have any
questions about this notice, please do not hesitate to contact me.


Sincerely,


[private]
