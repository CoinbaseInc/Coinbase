I, the undersigned, state UNDER PENALTY OF PERJURY that:

[1] I have read and understand Github''s Guide to Filing a DMCA Notice.

[2] I am a person injured, or an agent authorized to act on behalf of a
person injured by a violation of the U.S. Copyright laws, in particular
section 501 of Title 17 of the United States Code, commonly referred to as
the Digital Millennium Copyright Act, or "DMCA";

[3] I May Be Contacted At:

[REDACTED]

[4] I have a good faith belief that the files identified below (by URL) are
unlawful under these laws because, among other things, the links offer to
distribute copies of David Michael Pennington''s copyrighted works;

[5] The entire content of
https://github.com/markyjackson5/Cisco/blob/master/cisco_parse_test.py
infringes on this commit in a public repository:
https://bitbucket.org/mpenning/ciscoconfparse/src/af11ed1a9a7fa33ed01839965e0562d8ab6589eb/ciscoconfparse/ciscoconfparse.py.
To be specific, the subject of this complaint changed David Michael
Pennington''s name in the original copyright notice to Marky Jackson with
no references, or credit to the original author.

Violation(s): Copyright Infringement, GPLv3 license violation (due to
copyright violation)

[6] Please act expeditiously to remove the file-downloads found at the
following URL:
https://github.com/markyjackson5/Cisco/blob/master/cisco_parse_test.py

Marky Jackson may subsequently fork
https://github.com/mpenning/ciscoconfparse/ as long as he complies with
copyright and GPLv3 licensing terms.

[7] Pursuant to Github''s guide to filing a DMCA notice, I am providing
additional information about the identity of Marky Jackson. I believe with
good reason that the account known as https://github.com/markyjackson5/,
used to be known as https://github.com/markyjackson/ before it was deleted.
http://github.com/markyjackson/ was deleted after notification of the same
copyright violation in May 2014.

[8] I have a good faith belief that use of the copyrighted materials
described above on the infringing web pages is not authorized by the
copyright owner, or its agent, or the law.

[9] The information in this notice is accurate.

[10] I swear, under penalty of perjury, that the information in this
notification is accurate and that I am the copyright owner, or am
authorized to act on behalf of the owner, of an exclusive right that is
allegedly infringed.

Thank you for your kind assistance.

Truthfully,

//Signed//

[REDACTED]
