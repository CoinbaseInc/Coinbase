PSPDFKit GmbH is the copyright owner of source code that is being infringed
at:

https://github.com/LiuLiu001/PDFMaster/tree/master/PSPDFKit

(All of the files in the PSPPDFKit folder are infringing, and also some
have been copied and renamed and the header removed in the parent directory
- we haven't identified all of them yet)

The product that they infringe on is PSPDFKit, which is an iOS framework
for displaying and editing PDF files. See pspdfkit.com for details.

This letter is official notification under the provisions of Section 512(c)
of the Digital Millennium Copyright Act ("DMCA") to effect removal of the
above-reported infringements. I request that you immediately issue a
cancellation message as specified in RFC 1036 for the specified postings
and prevent the infringer, who is identified by its Web address, from
posting the infringing material to your servers in the future. Please be
advised that law requires you, as a service provider, to "expeditiously
remove or disable access to" the infringing material upon receiving this
notice. Noncompliance may result in a loss of immunity for liability under
the DMCA.

The person who appears to be responsible for the infringing repository
is [private] who’s email address is [private], [private]. However we were
unable to reach anyone via email, telephone or Skype.

I have a good faith belief that use of the material in the manner
complained of here is not authorized by me, the copyright holder, or the
law. I swear, under penalty of perjury, that the information in this
notification is accurate and that I am the copyright owner, or am
authorized to act on behalf of the owner, of an exclusive right that is
allegedly infringed.

Please contact us at the address below with a prompt response indicating
the actions you have taken to resolve this matter.

Sincerely,

/s/ [private]

Email: [private]

[private]

http://pspdfkit.com/privacy-legal/
