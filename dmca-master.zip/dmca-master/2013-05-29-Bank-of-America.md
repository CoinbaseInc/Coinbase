Re: Copyright Infringement - DMCA Takedown Notice

Hello,

The URL https://github.com/adamdonahue/nodes (the "Website") contains Bank of America's copyrighted source code. We kindly ask the content be removed from the site immediately, as it violates Bank of America's copyright and is in violation of GitHub's Terms of Service, specifically section A.8 located at 

https://help.github.com/articles/github-terms-of-service:

> You may not use the Service for any illegal or unauthorized purpose. You must not, in the use of the Service, violate any laws in your jurisdiction (including but not limited to copyright or trademark laws).

I hereby state that Bank of America is the owner of the copyright and that to the best of my knowledge and belief, the infringing use was not authorized by it, its agents or the law. I further declare, under penalty of perjury, that this notice is accurate and that I am authorized to act on behalf of Bank of America in this matter. Pursuant to the Digital Millenium Copyright Act, 17 U.S.C 512, and your Terms of Service, Bank of America hereby requests that you remove and/or limit access to the infringing material on the Website as soon as is practicable.

You may reach me by email at [private] if you have any questions about this matter. The foregoing is not intended as a complete statement of our rights and remedies, all of which are hereby expressly reserved.

Regards,  
[private]  
Threat Reduction Team  
Bank of America  
[private]  