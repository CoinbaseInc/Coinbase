Hi there, I'm with Amazon Web Services IT Security, and we'd like to
request that the source code at 

https://github.com/nsudan/ShopSocial 

and all subdirectories be removed from github. As you'll note at, say,

https://github.com/nsudan/ShopSocial/blob/master/src/com/amazon/appworks/ha
ckday/util/UiUtils.java 

this code was developed at Amazon as part of an
internal project, contains an Amazon.com copyright notice and management
did not authorize its release onto public code repositories.

You may contact me at [private], [private], or at

[Private] 
Amazon Web Services 
12900 Worldgate Drive 
Suite 800 
Herndon, VA 20170 

I do not have a current email address for the developer, he was employed
at Amazon a couple of years ago, but is no longer with us. (Otherwise we'd
just ask him to pull it directly).

I have a good faith belief that use of the copyrighted materials described
above on the infringing web pages is not authorized by the copyright
owner, or its agent, or the law,
and I swear, under penalty of perjury, that the information in this
notification is accurate and that I am the copyright owner, or am
authorized to act on behalf of the owner, of an exclusive right that is
allegedly infringed.

Sincerely,
[Private] 
AWS IT Security
