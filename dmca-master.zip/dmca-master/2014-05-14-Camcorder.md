Please remove all versions of my typeface CAMCORDER from this GitHub account.

https://github.com/caasi/caasigd.org/tree/master/source/font/CAMCORDER%20FONT%20FAMILY

It’s my work and whoever owns that GiHub account is distributing it against my will.
As you can see in the about.txt file, my personal name, company name and email are all listed in there.

I have a good faith belief that use of the copyrighted materials described above on the infringing web pages is not authorized by the copyright owner, or its agent, or the law.

I swear, under penalty of perjury, that the information in this notification is accurate and that I am the copyright owner, or am authorized to act on behalf of the owner, of an exclusive right that is allegedly infringed.

[private]

[private]
