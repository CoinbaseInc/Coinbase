Hello.

So it turns out that the code I uploaded, originally, to DDR0/Candy-Crunch
was actually not mine to upload in the first place, and the company whose
code it was wants it back. We've found the following repositories in
violation of our copyright:

1)
Candy-Crunch <https://github.com/BaeSangRyol/Candy-Crunch

Candy-Crunch <https://github.com/ggdagcheng/Candy-Crunch

Candy-Crunch <https://github.com/jonesgithub/Candy-Crunch

Candy-Crunch <https://github.com/ejjoo/Candy-Crunch

Candy-Crunch <https://github.com/kurai021/Candy-Crunch

Candy-Crunch <https://github.com/clarkewd/Candy-Crunch

2)
Again, this was a all misunderstanding, and none of these developers have
done anything wrong, but as all these repositories are in violation of a
copyright owned by Ayogo Health we should remove them posthaste.

The proper owner of the work is https://github.com/prescod/match_three/.
For similarities, note the resemblance of public/match_three/main.js to any
of the above repositories' main.js file. The listed Candy-Crunch
repositories are probably also an infringement against King.com's

http://www.king.com/games/puzzle-games/candy-crush/?language=en_US&action=play
.

3)
You may contact me via this email address, via [private], or
by phone in Canada at [private].

4)
No contact information above and beyond the existing profile pages is known
to me at this time.

5)
I have a good faith belief that use of the copyrighted materials described
above on the infringing web pages is not authorized by the copyright owner,
or its agent, or the law. To quote the email I received earlier today from
[private] (who I made the game for in the first place): "Project 1 is
cleaning up Candy Crunch code. One aspect of that is that we need you to
take down from your github repository. Sorry about that, but legally we own
it and plus you are in trademark violation. (we don't call it "candy
anything" when we use it)"

6)
I swear, under penalty of perjury, that the information in this
notification is accurate and that I am the copyright owner, or am
authorized to act on behalf of the owner, of an exclusive right that is
allegedly infringed.

7)
Thank you,
[private]
