I have read and understood GitHub’s guide to filling a DMCA notice. 

The copyright work infringed:
https://github.com/chhingchhing/CIMS

They copied the entire source code from version 14.1 (tag) and removed the license folder. So they clearly know what they are doing is wrong.

My repository
[private]

My site is: (Commercial product)
http://phppointofsale.com

To remedy the solution they most delete it and contact me to discuss who they have sold it to and given it to reach a settlement

My Contact INFO:
[private ]
I have a good faith belief that use of the copyrighted materials described above on the infringing web pages is not authorized by the copyright owner, or its agent, or the law.

I swear, under penalty of perjury, that the information in this notification is accurate and that I am the copyright owner, or am authorized to act on behalf of the owner, of an exclusive right that is allegedly infringed

Signature attached:
[private]
