Dear GitHub Copyright Agent:

I, the undersigned, represent the staff and players of TotalFreedom
L.L.C., EpicFreedom L.L.C., and AlexFreedom L.L.C. It has come to our
attention that the following repositories have broke our
"TotalFreedomMod" license and have removed our "README.md" contents
and credit to most of our staff members. In addition to doing this,
most of the content in this "Minecraft" mod is copyrighted from
TotalFreedom L.L.C. Therefore, the repositories identified below
constitute a violation of U.S. Copyright laws, in particular
section(s) 1201(a)(2) and/or 1201(b)(1) of Title 17 of the United
States Code, commonly referred to as the Digital Millennium Copyright
Act, or "DMCA". We request that the following repositories be taken
down from GitHub:
-https://github.com/RFreedomContents/RFreedomModv2.0-DONT-REMOVE-THIS
(Entire Repository)

I have read and understand GitHub's Guide to Filing a DMCA Notice. I
have a good faith belief that use of the copyrighted materials
described above on the infringing web pages is not authorized by the
copyright owner, or its agent, or the law. I swear, under penalty of
perjury, that the information in this notification is accurate and
that I am the copyright owner, or am authorized to act on behalf of
the owner, of an exclusive right that is allegedly infringed.

Contact Info
[private]
