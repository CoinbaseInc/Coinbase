VIA EMAIL:

Demand for Immediate Take-Down: Notice of Infringing Activity

Date:

01/04/2015

Case #:

[private]

Url:

github.com

Host IP Address:

192.30.252.131


Dear Sir or Madam,
We have received information that the domain listed above, which appears to be on servers under your control, is offering unlicensed copies of, or is engaged in other unauthorized activities relating to, copyrighted works published by Microsoft - OSG

1. Copyright work(s):  
  
  Halo Online
  
  Copyright owner(s) or exclusive licensee:

  Microsoft - OSG

2. Copyright infringing material or activity found at the following location(s):  
  
  https://github.com/DEElekgolo/ElDorito
  
  The above copyright work(s) is being made available for copying, through downloading, at the above location without authorization from the copyright owner or exclusive licensee.
  
3. Statement of authority:  
  
  The information in this notice is accurate, and I hereby certify under penalty of perjury that I am authorized to act on behalf of Microsoft - OSG, the owner or exclusive licensee of the copyright(s) in the work(s) identified above. I have a good faith belief that none of the materials or activities listed above have been authorized by Microsoft - OSG, its agents, or the law.
  
  We hereby give notice of these activities to you and request that you take expeditious action to remove or disable access to the material described above, and thereby prevent the illegal reproduction and distribution of this copyrighted work(s) via your company's services.

We appreciate your cooperation in this matter. Please advise us regarding what actions you take.

Yours sincerely,

[private]

Internet Investigator

On behalf of:

Microsoft - OSG

One Microsoft Way, Redmond, WA 98052, United States of America

E-mail: [private]
