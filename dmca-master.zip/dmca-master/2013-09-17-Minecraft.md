GitHub Inc
Attn: DMCA takedown
88 Colin P Kelly Jr St
San Francisco, CA. 94107

17 September 2013

SHERIDANS

[private]

Email
[private]

Telephone
[private]

By email oniy: copyright@github.com

Dear Sirs

COPYRIGHT INFRINGEMENT

We are solicitors acting for Molang AB and Notch Developments AB. More particularly we are advising our client in connection with the worldwide protection of their intellectual property rights subsisting in the game known as "MINECRAFT" (the “Game“) including without limitation all copyright in the Game, its "MINECRAFT" brand (the "Brand"), and the “MINECRAFT” trade dress including but not limited to the distinctive visual elements of the Game (the “Get-Up").

Our client is the developer and publisher of and is the owner of all copyright and other intellectual property rights subsisting in the Game, the Brand and the GetUp.

Our client informed us that you brought it to the attention of several Minecraft source codes:

https://github.com/solacemc/Minecraft-Source

(the 'Infringing Source Codes’)

which are available through the GitHub Site. Thank you for bringing this to our client's attention.

The Infringing Source Codes reproduce and use the whole or a substantial part of our client's copyright subsisting in the source code of the Game and such use is without our client's consent. Such use amounts to an infringement of our client's copyright.

Whilst our client’s principal claim lies against the creators of the Infringing Source Codes you will appreciate that by reason of GitHub making the Infringing Source Codes available to the public and communicating the infringing content to the public it is also liable for the acts of infringement complained of.

The Game and its content including the underlying software, source code and art assets (the “Content") are original works in which copyright subsists under national and international law, including under the Berne Convention for the Protection of Literary and Artistic Works.

Our client is the owner of all and any copyright subsisting in the Game and its content.

The Infringing Source Codes reproduce and use the whole or a substantial part of our client's copyright subsisting in the Game and Content (and/or individual copyright works which forms part thereof) and such use is without our ciient’s consent. Such use amounts to an infringement of our client's copyright and, by reason of GitHub making the Infringing Source Codes available to the public, GitHub is also liable for the acts of infringement complained of.

ACTION REQUIRED
On behalf of our client, we request that the infringing Source Codes are removed from the GitHub site/ service as soon as practicable.

We confirm that the information contained in this letter is, as far as we are aware, accurate and that we are authorised by our client to act on their behalf in respect of this matter.

We also repeat that we have a good belief that use of the copyrighted materials described above (the "infringing Source Codes") is not authorized by our client (the copyright owner), or its agent, or the law.

We swear, under penalty of perjury, that the information in this notification is accurate and that we are authorized to act on behalf of owner, of an exclusive
right that is allegedly infringed.

If you require any fUrther information in respect of this matter please contact us at the emaH address provided above.

We reserve all our client's rights.

Yours faithfully

[private]
