To Whom It May Concern:

On behalf of Frozen Sand / 0870760 B.C. Ltd (the “Owner”), I am authorized
to send this notice of copyright infringement. As required under the
Digital Millennium Copyright Act [17 USC 512(c)(3)], I am instructed to
place you on notice that:

1.

The owner is the exclusive owner of the Urban Terror software, source
code and related assets.
2.

The Owner is injured by a violation of the U.S. Copyright laws, in
particular section(s) 1201(a)(2) and/or 1201(b)(1) of Title 17 of the
United States Code, commonly referred to as the Digital Millennium
Copyright Act, or "DMCA", as well as Articles 29a (2) of the Dutch Copy
Right Act (Dutch: "Auteurswet").
3.

The following web page (the “Infringing Material”) contains the
copyrighted source code of the software which infringe the exclusive rights
of the Owner :

https://github.com/y0l0swaggings/Urban-Terror-Open-Source
4.

Please immediately remove or disable all access to the source code found
at the Infringing Material.
5.

I have a good faith belief that the use of the Infringing Material is
not authorized by the Owner, its agents or the law.
6.

The information in this Notice of Copyright Infringement is accurate and
is provided under penalty of perjury. I am authorized to act on behalf of
the Owner.

For any questions or additional information, my contact details are:

[private]

Sincerely,

[private]
