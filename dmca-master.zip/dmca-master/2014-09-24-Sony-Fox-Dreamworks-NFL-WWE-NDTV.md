TAKEDOWN NOTICE PURSUANT TO THE DIGITAL MILLENNIUM COPYRIGHT ACT OF
1998 Dear Sir or Madam,

This is a notice in accordance with the Digital Millennium Copyright
Act of 1998 requesting that you immediately cease to provide access
to copyrighted material.
The original material is located at the following URLs:

http://www.sonypictures.ca/english/movies/22JumpStreet/

http://www.sonypictures.ca/english/movies/sextape/

http://www.sonypictures.ca/english/movies/whenthegamestandstall/

http://www.sonypictures.ca/english/movies/Ghostbusters30thAnniversary/

http://www.sonypictures.ca/english/movies/nogooddeed/

http://www.foxmovies.com/movies/x-men-days-of-future-past

http://www.foxmovies.com/movies/the-other-woman

http://www.foxmovies.com/movies/rio-2

http://www.foxmovies.com/movies/the-wolverine

http://www.foxmovies.com/movies/the-heat

http://www.foxmovies.com/movies/life-of-pi

http://www.dreamworksanimation.com/movies/shrek/

http://www.dreamworksanimation.com/movies/mva/

http://www.dreamworksanimation.com/movies/pib/

http://www.dreamworksanimation.com/movies/turbo/

https://www.howtotrainyourdragon.com/

http://www.nfl.com/

http://www.wwe.com/

http://www.ndtv.com/

The infringing material is located at the following URLs:

Please note that the repositories which contain the pirated content
described below are clearly and blatently solely existant for the
purpose of distributing access to pirated content through your
network. It takes the untrained eye less than a minute when browsing
the file structure of any repository listed under any of the user's
accounts below to notice that they are not existant for any legitimate
purpose. The range of piracy is much more widespread than what is
linked below, however the following should be enough for your company
to take immediate action.

Pirated Movie Links:
https://github.com/Coolwavexunitytalk/movieplaylist/blob/master/xunitytalk_movies.xml

SolarMovies is Clearly a Piracy Hub:
https://github.com/cocawe/My-xbmc-repo/blob/master/script.icechannel.extn.cocawe/addon.xml

1080P Pirated Movie Streaming:
https://github.com/mash2k3/Staael1982/blob/master/1080p%20movies.xml

Pirated Content Stream Index:
https://github.com/metalkettle/MetalKettles-Addon-Repository/blob/master/CliqDirectory/BOXSETS.XML

Pirated BBC Streams: https://github.com/mikey1234/plugin.video.itv

Pirated Sports Streams:
https://github.com/OffsideStreams/addon/blob/master/addon.xml

Pirated Movie Streams:
https://github.com/xunitytalkplaylist/xunitytalk_playlist/blob/master/XMLs/xunitytalk_movies.xml

Further comments:

Each of the "repositories" listed directly above contain files that
are used to access and provide updated links to copywrited works
including but not limited to live sports streams, pirated film and
television downloads, along with pirated cable television networks.
The array of infringement is not limited to that listed above, it is
much more comprehensive.

My contact information is:

Name: [private]

Company: DMCA SECURE

Mailing address: Empire State Building, 350 5th Avenue, 59th Floor,

New York, New York, United States of America, 10018

E-mail address: [private]

I have a good faith belief that the use of the described material in
the manner complained of is not authorized by the copyright owner,
its agent, or the law.

I swear that the information in the notification is accurate and,
under penalty of perjury, that I am the copyright owner or am
authorized to act on behalf of the owner of an exclusive right that
is allegedly infringed.

Electronic Signature: [private]

Date: September 23, 2014
