https://github.com/FTGCyborg/perp

Be aware we have told them they do not have our permission to run such and
are very aware they are leaked/stolen

This letter is an official notification under Section 512(c) of the
Digital Millennium Copyright Act (”DMCA”), and I seek the removal of the
aforementioned leaked Pulsar Effect Roleplay / PERP scripts from your
servers. I request that you immediately notify anyone directly involved
with this scandal, and inform them of their duty to remove the infringing
material from your server immediately, and notify them to cease any
further posting of leaked material to your server in the future.

Please also be advised that law requires you, as a service provider, to
remove or disable access to the infringing materials upon receiving this
notice. Under US law a service provider, such as yourself, enjoys immunity
from a copyright lawsuit provided that you act with deliberate speed to
investigate and rectify ongoing copyright infringement. If service
providers do not investigate and remove or disable the infringing material
this immunity is lost. Therefore, in order for you to remain immune from a
copyright infringement action you will need to investigate and ultimately
remove or otherwise disable the infringing material from your servers with
all due speed.

I am providing this notice in good faith and with the reasonable belief
that rights my company owns are being infringed. Under penalty of perjury
I certify that the information contained in the notification is both true
and accurate, and I have the authority to act on behalf of the owner of
the copyright(s) involved.
We will provide affidavit of all that is needed of the copyright files in
question.

The scripts are copyright with the pulsareffect.com name which we know
they have deleted the copyrights on the lua files and plan on reverse
engineering the scripts to rewrite own. which is still against the
copyright law.

Your site even says you do not allow leaked gamemods as PERP is leaked /
stolen
We have told a few to remove they have not they did claim they would
recode which they cant recode our base source code and call it what they
want.
The scripts are being sold and passed around on hackforums &
http://dramaunlimited.org/
If you want more proof just let me know. also read all over facepunch.

I bought the whole pulsareffect.com and PERP copyrights since we have a
server up for almost 4 years coded by the original coder hunts.

Should you wish to discuss this with me please contact me directly.

[private]

