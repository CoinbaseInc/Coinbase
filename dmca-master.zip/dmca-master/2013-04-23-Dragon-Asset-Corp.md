To DMCA Agent:

This office has been retained by [private], owner of Dragon Asset Corp and Coinex (collectively “Company”), regarding copyright infringement on or about May, 2012. As such, please direct all future correspondence to this office regarding same.

Portions of proprietary software code owned by the Company was copied onto your website without my client’s permission or authorization. The unauthorized and infringing copy can be found here:

https://github.com/gbstack/charts

The offending user is [private] with an email address of [private]. His or her profile may be viewed here: 

https//github.com/gbstack

This letter is official notification under Section 512(c) of the Digital Millennium Copyright Act (”DMCA”), and my client seeks the removal of the aforementioned infringing material from your servers. I request that you immediately notify the infringer of this notice and inform them of their duty to remove the infringing material immediately, and notify them to cease any further posting of infringing material to your server in the future.

Please also be advised that law requires you, as a service provider, to remove or disable access to the infringing materials upon receiving this notice. Under US law a service provider, such as yourself, enjoys immunity from a copyright lawsuit provided that you act with deliberate speed to investigate and rectify ongoing copyright infringement. If service providers do not investigate and remove or disable the infringing material this immunity is lost. Therefore, in order for you to remain immune from a copyright infringement 2 action you will need to investigate and ultimately remove or otherwise disable the infringing material from your servers with all due speed should the direct infringer, your client, not comply immediately.

I have a good faith belief that use of the copyrighted materials described above on the infringing web pages is 
not authorizedby the copyright owner, or its agent, or the law.

I swear, under penalty of perjury, that the information in this notification is accurate and that I am the copyright owner, or am authorized to act on behalf of the owner, of an exclusive right that is allegedly infringed.

Please contact my office if you have any questions or require any additional information. Thank you in advance for your anticipated professional courtesy and cooperation.

Regards,
Law Office of [private]
[private]