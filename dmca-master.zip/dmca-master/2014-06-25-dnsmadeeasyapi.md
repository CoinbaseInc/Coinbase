To Whom It May Concern:

Please act expeditiously to remove the copyrighted content found at the
following URLs: https://github.com/wanelo/dnsmadeeasyapi

This is the pull request they submitted, with my comments on it:

https://github.com/funzoneq/dnsmadeeasyapi/pull/1/files

The problem being that they (re)used my code but:
- Removed me as an author
- Changed the license from GPLv2 to Apache without permission.

And after I've communicated those problems, they never responded. Not even
to my lawyers requests.

[1] The original owned by me: https://github.com/funzoneq/dnsmadeeasyapi
https://github.com/funzoneq/dnsmadeeasyapi/blob/master/LICENSE
https://github.com/funzoneq/dnsmadeeasyapi/blob/master/dnsmadeeasyapi.gemspec

[2] The infringed work:
https://github.com/wanelo/dnsmadeeasyapi
https://github.com/wanelo/dnsmadeeasyapi/blob/master/dnsmadeeasy-rest-api.gemspec

[3] I may be contacted at:

[private] 

[4] I have tried to contact, [private], [private],
[private] multiple times, but received no response.

[5] I have a good faith belief that use of the copyrighted materials
described above on the infringing web pages is not authorized by the
copyright owner, or its agent, or the law.

[6] I swear, under penalty of perjury, that the information in this
notification is accurate and that I am the copyright owner, or am
authorized to act on behalf of the owner, of an exclusive right that is
allegedly infringed.

Thank you for your kind assistance.

Truthfully,

[private] 
