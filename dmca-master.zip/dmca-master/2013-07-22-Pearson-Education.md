*** Sent via Email - DMCA Notice of Copyright Infringement *** 

Dear Sir/Madam,

I certify under penalty of perjury, that I am an agent authorized to act on behalf of the owner of the intellectual property rights and that the information contained in this notice is accurate.

I have a good faith belief that the page or material listed below is not authorized by law for use by the individual(s) associated with the identified page listed below or their agents and therefore infringes the copyright owner's rights.

I HEREBY DEMAND THAT YOU ACT EXPEDITIOUSLY TO REMOVE OR DISABLE ACCESS TO THE PAGE OR MATERIAL CLAIMED TO BE INFRINGING.

This notice is sent pursuant to the Digital Millennium Copyright Act (DMCA), the European Union's Directive on the Harmonisation of Certain Aspects of Copyright and Related Rights in the Information Society (2001/29/EC), and/or other laws and regulations relevant in European Union member states or other jurisdictions.

My contact information is as follows:

Organization name: Attributor Corporation as agent for Rights Holders listed below

[private]

My electronic signature follows:
Sincerely,
[private]


*** INFRINGING PAGE OR MATERIAL ***

Infringing page/material that I demand be disabled or removed in consideration of the above:

Rights Holder: Pearson Education, Inc. 1

Original Work: Cocoa Design Patterns 1st edition
Infringing URL: https://github.com/tuchangwei/iOS-EBook/blob/master/Cocoa%20Design%20Patterns.pdf

Original Work: Effective Java 2nd edition
Infringing URL: https://github.com/wfwei/storage/raw/master/books/tech/Effective%20Java%202nd%20Edition.pdf

Original Work: Cocoa Recipes for Mac OS X 2nd edition
Infringing URL: https://github.com/hadv/ebook/raw/master/cocoa-recipes-for-mac-os-x-2nd-edition.9780321670410.52533.pdf