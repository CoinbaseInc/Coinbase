Dear Sirs,

I am writing you as the company Scavix Ltd. has unrightfully published code which is copyright of our company, PamConsult GmbH. There is no agreement between the two companies or [private] re. usage or ownership transfer of the published code. As such we request you take down this publication immediately.

Our lawyers ([private], Schüppen & Partner, Stuttgart) are already in contact with Scavix Ltd. and its sole shareholder and general manager, [private]. PamConsult GmbH has in addition terminated the Lesser GNU license on the files containing our copyright with a removal deadline of April 8, 2013.

URL infringing our copyright: https://github.com/ScavixSoftware/WebFramework

Infringing data: The attached list of files contained in the above “WebFramework”. These files are the sole copyright of PamConsult GmbH.

You may contact [private] at [private] or via www.scavix.com <http://www.scavix.com> .

Our lawyer in this matter: [private], Schüppen & Partner. Upon request, we can provide you with the correspondence from by our lawyer to Scavix Ltd. and [private] re. this matter (in German).

Notice re. this message:

I have a good faith belief that use of the copyrighted materials described above on the infringing web pages is not authorized by the copyright owner, or its agent, or the law.

I swear, under penalty of perjury, that the information in this notification is accurate and that I am the copyright owner, or am authorized to act on behalf of the owner, of an exclusive right that is allegedly infringed.

Should you have any further questions, please let me know.

Best Regards / Mit freundlichen Grüßen / Saludos
Cordiali saluti / Cordialement / ?? / ????

[private]