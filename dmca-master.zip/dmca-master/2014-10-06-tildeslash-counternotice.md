This is my DMCA Counter-Notification in response to the notification below.

1. I am [private], copyright holder for the identified material.

2. The material is located at https://github.com/mperham/inspeqtor

3. I state under penalty of perjury that I have a good faith belief that
the material was removed or disabled as a result of a mistake or
misidentification of the material to be removed or disabled.

4. My contact info:

[private]

I consent to the jurisdiction of Federal District Court for the judicial
district of California and that I will accept service of process from the
person who provided notification or an agent of such person.
