1) The contents of our svn repository
http://www.observium.org/svn/observer/trunk/

2) The contents of the github repository
https://github.com/jcollie/observium, which is a modified mirror of our
svn repository, distributing modified copies is prohibited by our
license, which is in the infringing repository
(https://github.com/jcollie/observium/blob/master/LICENSE) note section #2 and #3.

3) [private]

4) He's one of your users, I assume you know to contact him!
(https://github.com/jcollie) :)

5) I have a good faith belief that use of the copyrighted materials
described above on the infringing web pages is not authorized by the
copyright owner, or its agent, or the law.

6) I swear, under penalty of perjury, that the information in this
notification is accurate and that I am the copyright owner, or am
authorized to act on behalf of the owner, of an exclusive right that is
allegedly infringed.

7) :

[private]

Lead Developer

Observium

[private]
