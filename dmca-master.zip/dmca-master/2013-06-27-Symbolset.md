Hi,

It’s come to our attention that a number of repos contain a few of our Symbolset fonts, SS Pika, Social Regular and Social Circle, and redistribution is against our License agreement.

Here’s the list of offending repos and the folders containing our fonts. We've already reached out to hello@modernassemb.ly and alerted them of the issue, but the 200+ combined forked repos our out of their control.

https://github.com/modernassembly/threesixtyjs/tree/master/assets/css/webfonts
https://github.com/modernassembly/imageloader/tree/master/css/webfonts
https://github.com/modernassembly/windows/tree/master/css/webfonts
https://github.com/nick-jonas/SliderJS/tree/master/example/assets/fonts
https://github.com/nick-jonas/nick-jonas.github.com (a collection of the above repos)


As per the DMCA Takedown request:

I have a good faith belief that use of the copyrighted materials described above on the infringing web pages is not authorized by the copyright owner, or its agent, or the law.

I swear, under penalty of perjury, that the information in this notification is accurate and that I am the copyright owner, or am authorized to act on behalf of the owner, of an exclusive right that is allegedly infringed.



I'm also curious if you have a way to prevent fonts from being uploaded? A quick search for some of our css files returns a number of other results unfortunately.

[Private]
[private]
Symbolset
10 Jay St., #606
Brooklyn, NY 11201
help@symbolset.com