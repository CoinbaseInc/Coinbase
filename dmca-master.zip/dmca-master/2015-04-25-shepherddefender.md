Notice of Copyright Infringement

My name is [private], and I am the author and owner of copyrighted
work that is hosted and can freely be downloaded through your source
code hosting services.

The original work is a collection of archived files in a special format
usable with the Unity software (http://www.unity3d.com) that contains
special effects designed to be used with the aforementioned Unity software.
The original work can be found at:

https://www.assetstore.unity3d.com/en/#!/content/4010

https://www.assetstore.unity3d.com/en/#!/content/4274

https://www.assetstore.unity3d.com/en/#!/content/5669

And can then be purchased through the Unity software's built-in "Asset
Store".

The infringing files provided free of charge without permission and
hosted through github.com can be found on these repositories:

https://github.com/stotskii/The-Shepherd-Defender/tree/master/unity_assets/Cartoon%20FX%20Pack%202

https://github.com/stotskii/The-Shepherd-Defender/tree/master/unity_assets/Cartoon%20FX%20Pack

https://github.com/stotskii/The-Shepherd-Defender/tree/master/unity_assets/War%20FX

You can reach me at [private] for further information
or clarification.
My mailing address is:  
[private]

I have a good faith belief that use of the copyrighted materials
described above as allegedly infringing is not authorized by the
copyright owner, its agent, or the law.
I swear, under penalty of perjury, that the information in the
notification is accurate and that I am the copyright owner.

Thanks for your cooperation.

[private]  
April 17, 2015
09:40 GMT+1

