Dear GitHub Copyright Agent:

I, the undersigned, state UNDER PENALTY OF PERJURY that:

[1] I am a person injured, or an agent authorized to act on behalf of a person injured by a violation of the U.S. Copyright laws, in particular section 501 of Title 17 of the United States Code, commonly referred to as the Digital Millennium Copyright Act, or "DMCA";

[2] I May Be Contacted At:

Name of Injured Party : APPLE INC.

Name and Title: [private]

Company: KILPATRICK TOWNSEND AND STOCKTON LLP

Address: 1114 AVENUE OF THE AMERICAS, 21st Fl.

City, State, and Zip: NEW YORK, NEW YORK 10036

Email address [private]

Telephone: [private]

Fax: [private]

[3] I have a good faith belief that the files identified below (by URL) are unlawful under these laws because, among other things, the link offers to distribute copies of Apple's copyrighted works;

[4] Content Type: Apple ResearchKit Source Code
Violation(s): Copyright Infringement

[5] Please act expeditiously to remove the file-downloads found at the following URL:

https://github.com/lyonanderson/ResearchKit

[6] I have a good faith belief that the distribution of the copyrighted work identified above is not authorized by law; and

[7] The information in this notice is accurate.

Thank you for your kind assistance.

Truthfully,

[private]

Kilpatrick Townsend & Stockton LLP

