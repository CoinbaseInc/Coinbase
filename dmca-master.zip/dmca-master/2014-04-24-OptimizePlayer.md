1. https://github.com/asplteam/pixelserve 

  This is our project that they stole and set live. We have renamed the project to OptimizePlayer since then but it is the same code base: 

  https://github.com/bizlaunchequity/optimizeplayer

  You can see clearly here that they were a contributor on this project and took it and set it public against our permission: 

  https://github.com/bizlaunchequity/optimizeplayer/graphs/contributors
  
  You can check the whois for pixelserve.com to see we own that domain. The project has been renamed to OptimizePlayer though and it was pixelserve while they were working on it.

2. https://github.com/asplteam/pixelserve - the entire github repository

3. May name is [private], [private]

4. [private], [private], [private], [private]

5. I have a good faith belief that use of the copyrighted materials described above on the infringing web pages is not authorized by the copyright owner, or its agent, or the law.

6. I swear, under the penalty of perjury, that the information in this notification is accurate and that I am the copyright owner, or am authorized to act on behalf of the owner, of an exclusve right that is allegedly infringed.

7. [private]
