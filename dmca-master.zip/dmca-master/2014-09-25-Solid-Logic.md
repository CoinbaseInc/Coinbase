I have a good faith belief that use of the copyrighted materials described
above on the infringing web pages is not authorized by the copyright owner,
or its agent, or the law. I swear, under penalty of perjury, that the
information in this notification is accurate and that I am the copyright
owner, or am authorized to act on behalf of the owner, of an exclusive
right that is allegedly infringed.

1) Identify the copyrighted work you believe has been infringed. The
specificity of your identification may depend on the nature of the work you
believe has been infringed, but may include things like a link to a web
page or a specific post (as opposed to a link to a general site URL).

In 2013, I hired [private] (on GitHub as username pedrokarvinen), a
freelance software developer operating on oDesk to work on a private
software application for my company. I required that he keep all materials
for this project private and not release them to anyone else without my
written consent. I have never spoken to or allowed GitHub users
alexseypopov or antonfilippov118 access to this source code or allowed them
to publicly post this source code.

Further, the following articles contain account credentials which should
have been kept confidential.

2) Identify the material that you allege is infringing upon the copyrighted
work listed in Item #1 above. This identification needs to be reasonably
sufficient to permit GitHub to locate the material. In other words, please
include the URL to the material allegedly infringing your copyright (URL of
a website or URL to a post, with title, date, name of the emitter), or link
to an initial post with sufficient data to find it.

I would like to request the take down of some materials as I strongly
believe these articles contain infringing information.
As mentioned in your DMCA Takedown Policy, here are the links to the
articles we believe should be taken down:

1.
https://github.com/pedrokarvinen/solidlogic/blob/c27ed5071175b1740b59bace90e537bf5063f676/ifx_stt/settings.py

2.
https://github.com/alexseypopov/solidlogic/blob/c27ed5071175b1740b59bace90e537bf5063f676/ifx_stt/settings.py

3.
https://github.com/antonfilippov118/solidlogic/blob/c27ed5071175b1740b59bace90e537bf5063f676/ifx_stt/settings.py

4.
https://github.com/pedrokarvinen/solidlogic/blob/c27ed5071175b1740b59bace90e537bf5063f676/deploy/settings.py

5.
https://github.com/alexseypopov/solidlogic/blob/c27ed5071175b1740b59bace90e537bf5063f676/deploy/settings.py

6.
https://github.com/antonfilippov118/solidlogic/blob/c27ed5071175b1740b59bace90e537bf5063f676/deploy/settings.py

7.
https://github.com/pedrokarvinen/solidlogic/blob/c27ed5071175b1740b59bace90e537bf5063f676/deploy/config/dev/local_settings.py

8.
https://github.com/alexseypopov/solidlogic/blob/c27ed5071175b1740b59bace90e537bf5063f676/deploy/config/dev/local_settings.py

9.
https://github.com/antonfilippov118/solidlogic/blob/c27ed5071175b1740b59bace90e537bf5063f676/deploy/config/dev/local_settings.py

3) Provide information on which GitHub may contact you, including your
email address, name, telephone number and physical address.
Feel free to contact me at:

[private]

CEO, Solid Logic Technology Inc.

3371 Woodward Ave. #231
Birmingham, MI 48009

Email: [private]

Phone: [private]

4) Provide the address, if available, to allow GitHub to notify the
owner/administrator of the allegedly infringing webpage or other content,
including email address.

THe offending users may be reached through GitHub and operate under the
following usernames: pedrokarvinen, alexseypopov and antonfilippov118.

Regards,

[private]
