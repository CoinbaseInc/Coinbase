Hello,

This is [private] from piracysolution.com I am the authorized agent for Pluralsight.com. It has come to our knowledge that https://gist.github.com is linking, external linking or distributing our content illegally. The infringing material, content or link to be removed is located at the following URLs:

Pluralsight tutorials

https://gist.github.com/k1-hedayati/8110131

We are requesting that your website not put up or link this copyrighted content in the future. It must not continue to go back up on your site. Please remove it as soon as possible and cease allowing our copyrighted content to be released or linked on your site. Notify me as soon as the removal is complete so that I may verify our content is no longer being linked or distributed by your site. Please forward any and all information you have on the person or persons that uploaded or linked our content, so that we may send a cease and desist order to them. I have a good faith belief that use of the copyrighted materials described above as allegedly infringing is not authorized by the copyright owner, its agent, or the law. I swear, under penalty of perjury, that the information in the notification is accurate and that I am the copyright owner or am authorized to act on behalf of the owner of an exclusive right that is allegedly infringed.

If you wish to contact me or pluralsight.com to confirm the legitimacy of this request, please use the contact information listed below:

[private]

VP of Content

Pluralsight LLC.

pluralsight.com

182 North Union Ave.
Farmington, UT. 84025
USA

Email: pluralsight@piracysolution.com

Evidence of copyright and original material can be found at the listed URL:

www.pluralsight.com

www.digitaltutors.com

[private] Authorized agent

Anti-Piracy

Pluralsight.com

CEO

http://piracysolution.com/

[private]

Please contact me if you have any questions. I will look forward to hearing from you.
