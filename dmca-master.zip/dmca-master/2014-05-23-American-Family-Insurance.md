1. These link was found to have Permanent General corporate confidential information. The specific thegeneral.com contact information is owned by American Family, which is what is listed within the information found. (Please note American Family acquired Permanent General in 2012. Please see the following press release for additional details: http://www.insurancejournal.com/news/midwest/2012/09/27/264631.htm

* The original data is found on the website (thegeneral.com).

1. Thegeneral.com information is found within the links below.
https://gist.github.com/blafrance/5079951

2. [private]

3. American Family Insurance; 6000 American Parkway; Madison WI 53783

4. I have a good faith belief that use of the copyrighted materials described above on the infringing web pages is not authorized by the copyright owner, or its agent, or the law.

5. I swear, under penalty of perjury, that the information in this notification is accurate and that I am authorized to act on behalf of the owner, of an exclusive right that is allegedly infringed.

6. [private]
