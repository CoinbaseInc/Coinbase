Hi,

I have read and understand GitHub's Guide to Filing a DMCA Notice.

The infringed copyrighted work is our application, activeCollab (www.activeCollab.com) While we do allow our customers to download and self-host our app, our license agreement clearly prohibits sharing: https://activecollab.com/help/books/licensing/self-hosted-license-agreement.html

The following two links of the hosted content are a direct, literal copy of our work:

https://github.com/benabhi/ActiveCollab

https://github.com/dbachmann/activeCollab/tree/master/activecollab.dev

I confirm that I have investigated each individual case and that my statements apply to each identified fork. In order to avoid having the rest of their content disabled, please ask the user to remove the offending material - everything on the links provided above.

Our Contact Information:

[private]

I have a good faith belief that use of the copyrighted materials described above on the infringing web pages is not authorized by the copyright owner, or its agent, or the law.

I swear, under penalty of perjury, that the information in this notification is accurate and that I am the copyright owner, or am authorized to act on behalf of the owner, of an exclusive right that is allegedly infringed.

Thank you,

[private]
