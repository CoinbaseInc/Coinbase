Dear GitHub Copyright Agent:

I, the undersigned, state UNDER PENALTY OF PERJURY that:

[1] I am, the original author and the copyright owner of the files in the repository identified below (by URL) in 
section [4] of this document.

[2] I may be contacted at:

[private]

[3] I have a good faith belief that the files in the repository identified below (by URL) are unlawful because it 
distributes sensitive assignment solutions of an academic institute (University of Washington).

[4] The URL to the unlawful files is: https://github.com/sara22/frshStuff Please act expeditiously to take down the file 
repository identified by this URL.

[5] I have a good faith belief that use of the copyrighted materials described above on the infringing web pages is not 
authorized by the copyright owner, or its agent, or the law.

[6] I swear, under penalty of perjury, that the information in this notification is accurate and that I am the copyright 
owner, or am authorized to act on behalf of the owner, of an exclusive right that is allegedly infringed.

[7] [private]
