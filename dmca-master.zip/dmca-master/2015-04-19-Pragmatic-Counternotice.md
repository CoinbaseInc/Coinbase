Good Afternoon,

We are agents of pragmatic programming and issued a DMCA claim against an open repository by mistake. I apologize for the inconvenience.

Please see below:

I have read and understand GitHub's Guide to Filing a DMCA Counter Notice.

URL of removed content:
https://github.com/github/dmca/blob/master/2015-04-22-Pragmatic.md

Claim and Counterclaim issued by:
[private]

I swear, under penalty of perjury, that I have a good-faith belief that the material was removed or disabled as a result of a mistake or misidentification of the material to be removed or disabled.

I consent to the jurisdiction of Federal District Court for the judicial district in which my address is located (if in the United States, otherwise the Northern District of California where GitHub is located), and I will accept service of process from the person who provided the DMCA notification or an agent of such person."

Physical or electronic signature:

[private]
