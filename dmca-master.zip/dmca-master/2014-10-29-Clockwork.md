GitHub Staff,

I have read and understand GitHub's Guide to Filing a DMCA Notice.

The following repositories violate copyright on intellectual property
that I own, namely Clockwork and Schemas:

The copyrighted work at issue is the ('gamemode', 'schema') 'Clockwork'
created by Cloud Sixteen ( Copyright Certificate:
http://cloudsixteen.com/copyright.pdf ) ( http://CloudSixteen.com

The purpose of this fork, from our original repository at
http://github.com/CloudSixteen/Clockwork, is to bypass digital rights
management systems in place to prevent the loading and use of the
software without a license.

They must take down the repositories completely as Clockwork is
intellectual property of Cloud Sixteen, and they have not been given
permission to distribute this version that contains methods to bypass
our digital rights management.

The repositories where our copyrighted material is hosted (and contains
method to illegally bypass 'crack' the software) at the following locations:

(These repositories are in addition to those in our previous notice to
you. In response to a previous notice yesterday, all they had done is
removed our copyright header from the files when we had instead
requested they remove every file, this in itself is an infringement.)

/https://github.com/alexgrist/Clockwork

https://github.com/Connall/Clockwork

https://github.com/Exiguous-Productions/Clockwork/

/https://github.com/johnnyguitarFP/Clockwork

https://github.com/Macbacon/Clockwork

https://github.com/dramaunlimited/Clockwork

https://github.com/ryan-kingstone/Clockwork

https://github.com/SpencerSharkey/Clockwork

https://github.com/Fatmuffins/Clockwork

https://github.com/starlox/Clockwork

https://github.com/Viomi/Clockwork/

/https://github.com/StefanMajonez/Clockwork

https://github.com/Bizerco/Clockwork

//https://github.com/Devul/Clockwork

https://github.com/czmate10/Clockwork

https://github.com/gmodcoders/Cockwork

https://github.com/PaladinT/Clockwork

https://github.com/Slidefuse/Clockwork

https://github.com/xRJx/Clockwork

/// You can reach me at [private]
for further information or clarification.
My phone number is [private] and my mailing
address is [private].

I have a good faith belief that use of the copyrighted materials
described above as allegedly infringing is not authorized by the
copyright owner, its agent, or the law.

I swear, under penalty of perjury, that the information in the
notification is accurate and that I am the copyright owner or am
authorized to act on behalf of the owner of an exclusive right that is
allegedly infringed.

[private]

October 29, 2014 [10:25]
