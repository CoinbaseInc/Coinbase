Dear GitHub DMCA Agent:

Thank you for your attention. I write on behalf of Facebook, Inc. and its affiliated company Instagram, LLC. I have read and understand GitHub's Guide to Filing a DMCA Notice. The links below resolve to repositories of code that have been copied from the Instagram mobile app and published without permission. These pages include copies of code originally posted here (https://github.com/diwu/InstaFilters/), but that GitHub has since removed under the DMCA notice and takedown process.

https://github.com/tigger-tian/InstaFilters

https://github.com/Myuzu/InstaFilters/

https://github.com/tigger-tian/InstaFilters

https://github.com/lbsweek/Instagram-Filters/

https://github.com/DrivingInfiniti/GHFilters

https://github.com/anbinh/Instagram-Filters

All of the code on the pages above is unauthorized by the copyright owner. Please remove the code from those pages. I have a good faith belief that use of the copyrighted materials described above on the infringing web pages is not authorized by the copyright owner, or its agent, or the law.

I swear, under penalty of perjury, that the information in this notification is accurate and that I am the copyright owner, or am authorized to act on behalf of the owner, of an exclusive right that is allegedly infringed.

If you have any questions, please do not hesitate to contact me.

Sincerely,

[private

---

[private] | Trademark Counsel | Facebook, Inc.

[private] [private]
