Sir or madam,
We have identified that copyrighted software owned by our company has been improperly posted on GitHub here and request it's removal:

https://github.com/ak1196/Beauchapp

The copyrighted material is available to the public only in binary form here:

https://play.google.com/store/apps/details?id=com.Beauchamp.BeauchApp

It appears that the source code has been decompiled from the binary, and posted. The software that has been posted is not open source, and beacause there is no contact details for the user I cannot contact them to request a takedown.

I have a good faith belief that use of the copyrighted materials described above on the infringing web pages is not authorized by the copyright owner, or its agent, or the law.

I swear, under penalty of perjury, that the information in this notification is accurate and that I am the copyright owner, or am authorized to act on behalf of the owner, of an exclusive right that is allegedly infringed.

Sincerely,

[private]

Director
Beauchamp College
Ridgeway, Oadby
Leicestershire, 
LE2 5TP
[private]
