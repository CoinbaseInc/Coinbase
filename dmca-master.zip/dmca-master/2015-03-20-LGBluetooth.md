Dear GitHub Copyright Agent,

*1)* I have read and understand GitHub's Guide to Filing a DMCA Notice.

*2)* As you can see the copyright in LICENSE
https://github.com/SocialObjects-Software/LGBluetooth/blob/master/LICENSE
file belongs to me (DavidSahakyan). Moreover, you may notice in the
README.md https://github.com/SocialObjects-Software/LGBluetooth/blob/master/README.md
file (which is being shown in main page of the repository) there is an
additional reference to the LICENSE file.

Furthermore, all commits
https://github.com/SocialObjects-Software/LGBluetooth/commits/master to
the repository belong to me and another contributors
https://github.com/SocialObjects-Software/LGBluetooth/graphs/contributors
(from outside Social Objects Software company), and all releases
https://github.com/SocialObjects-Software/LGBluetooth/releases were
performed by me.

Originally the repository was on my account (https://github.com/davidsahakyan/LGBluetooth), and the prefix LG means
"l0gg3r" which is my nickname (their projects are starting with prefix SO).
After a period of active development I have transferred the repository to
"SocialObjects-Software" account (at that time I was working for that
company), mainly for promotional purposes, by the CEO's request. After
leaving my job the access to my repository has been locked for me. This led
to a situation, where the development of the product stopped immediately.
There are many issues
<https://github.com/SocialObjects-Software/LGBluetooth/issues> for the
repository, but I am not able to resolve them and continue the development,
because of a lack of access.
Thus, a project that I have initiated, developed and invested a lot of time
in, is completely stalled.

*3)* This is the URL of the repository:
https://github.com/SocialObjects-Software/LGBluetooth/

*4)* I require the repository to be transferred back to my - l0gg3r
https://github.com/l0gg3r account (the former DavidSahakyan account).

*5)* Hereby I provide my contact information:  
REDACTED

*6)* And by this email, you may contact the party I blame in infringing my
rights:

REDACTED

*7)* I have a good faith belief that use of the copyrighted materials
described above on the infringing web pages is not authorized by the
copyright owner, or its agent, or the law.

*8)* I swear, under penalty of perjury, that the information in this
notification is accurate and that I am the copyright owner, or am
authorized to act on behalf of the owner, of an exclusive right that is
allegedly infringed.

Thanks in advance,
REDACTED
