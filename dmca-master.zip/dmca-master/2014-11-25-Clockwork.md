GitHub Staff,

I have read and understand GitHub's Guide to Filing a DMCA Notice.

The following repositories violate copyright on intellectual property
that I own, namely Clockwork and Schemas:

The copyrighted work at issue is the ('gamemode', 'schema') 'Clockwork'
created by Cloud Sixteen ( Copyright Certificate:
http://cloudsixteen.com/copyright.pdf ) ( http://CloudSixteen.com

The purpose of this fork is to bypass digital rights management systems
in place to prevent the loading and use of the software without a license.

They must take down the repository completely as Clockwork is
intellectual property of Cloud Sixteen, and they have not been given
permission to distribute this version that contains methods to bypass
our digital rights management.

The repositories where our copyrighted material is hosted (and contains
method to illegally bypass 'crack' the software) at the following locations:

/https://github.com/ExtReMLapin/Clockwork/
/
/// You can reach me at [private] for further information or clarification.
My phone number is [private] and my mailing
address is [private].

I have a good faith belief that use of the copyrighted materials
described above as allegedly infringing is not authorized by the
copyright owner, its agent, or the law.

I swear, under penalty of perjury, that the information in the
notification is accurate and that I am the copyright owner or am
authorized to act on behalf of the owner of an exclusive right that is
allegedly infringed.

[private]

November 24, 2014 [12:54]
