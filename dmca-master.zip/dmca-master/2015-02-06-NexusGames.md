I have read and understand GitHub's Guide to Filing a DMCA Notice.

I'm writing you because of my project NexusGames whose decompiled source code was illegaly published on github. The user FrickX got my bukkit plugin from one of my customers who published the obfuscated jar file and put the source here, so it's a literal copy of it. Since he published the complete source code, the project contains a plugin.yml where you can find information about me - the owner (Kocacola97, reallife: [private]).

The project I'm reporting as a complete copy is located under this link:

https://github.com/Infected-Network/NexusGames

Because the project is a literal copy of my project I request a complete deletion of the project.

My contact information are as follows:

[private]

Contact information of the alleged infringer from a whois of his webpage

[private]

I have a good faith belief that use of the copyrighted materials described above on the infringing web pages is not authorized by the copyright owner, or its agent, or the law.

I swear, under penalty of perjury, that the information in this notification is accurate and that I am the copyright owner, or am authorized to act on behalf of the owner, of an exclusive right that is allegedly infringed.

Best regards, [private]
