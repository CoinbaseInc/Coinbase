To whom it may concern:

ZeroTurnaround is hereby filing a copyright claim against one GitHub
account account according to the format provided at
https://help.github.com/articles/dmca-takedown .

1. (Infringed copyrighted work.) The infringed work is ZeroTurnaround's
main product called JRebel ( http://zeroturnaround.com/software/jrebel/ ).
The version corresponding to the cracked JRebel in the GitHub repository is
JRebel 5.3.1. It can be downloaded from

  http://zeroturnaround.com/software/jrebel/download/thank-you/?file=jrebel-5.3.1-nosetup.zip.

2. (Infringing material.) The infringing material is located at
https://github.com/ddatsh/jrebel . It contains two items: a cracked version
of JRebel 5.3.1 binary (jrebel.jar) and a cracked license specially
designed to work with the above-mentioned cracked JRebel. This effectively
circumvents JRebel's internal copyright protection mechanisn that unlocks
the product only to users that provide a valid license. This violates
ZeroTurnaround's copyright and other rights in various ways - most obvious
of them being the illegal/unauthorized modification and redistribution of a
copyrighted work.

3. (Contact information.) For copyright-related matters, ZeroTurnaround can
be contacted via e-mail address ip@zeroturnaround.com . The general contact
address for any matters is support@zeroturnaround.com . Physical address :
Roosikrantsi 11, 3rd fl / 10119 Tallinn / ESTONIA. All information
available via http://zeroturnaround.com/ .

4. ZeroTurnaround is currently unaware of the contact address of the
infringer.

I have a good faith belief that use of the copyrighted materials described
above on the infringing web pages is not authorized by the copyright owner,
or its agent, or the law.

I swear, under penalty of perjury, that the information in this
notification is accurate and that I am the copyright owner, or am
authorized to act on behalf of the owner, of an exclusive right that is
allegedly infringed.

[private]
