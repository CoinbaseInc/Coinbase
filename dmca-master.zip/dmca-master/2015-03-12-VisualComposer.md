TAKEDOWN NOTICE PURSUANT TO THE DIGITAL MILLENNIUM COPYRIGHT ACT OF 1998

Dear Sir or Madam,

This is a notice in accordance with the Digital Millennium Copyright Act of
1998 requesting that you immediately cease to provide access to copyrighted
material.

The original material is located at the following URLs:

https://github.com/mmihey/js_composer

The infringing material is located at the following URLs:

https://github.com/dauidus/js_composer-extended

https://github.com/russellgreen/wordpress-themes/tree/master/powermag/inc/js_composer

https://github.com/gq-dev/gq-smart/tree/master/plugins/js_composer

https://github.com/russellgreen/wordpress-themes/tree/master/powermag/inc/js_composer

https://github.com/gq-dev/gq-smart/tree/master/plugins/js_composer

https://github.com/MacFlay/publiczni/tree/master/plugins/js_composer.zip

https://github.com/nt46/salient/tree/master/wpbakery/js_composer

https://github.com/BeardandFedora/spawncamping-archer/tree/master/wp-content/plugins/js_composer

https://github.com/kinesisinc/kns/tree/master/wp-content/plugins/visual-composer

https://github.com/alnafiea/dates/tree/master/wp-content/plugins/js_composer

https://github.com/ksingh812/tkthub/tree/master/plugins/js_composer

https://github.com/junxiondelhi/alianceindia/tree/master/wp-content/plugins/twoot-toolkit/js_compose.
..

https://github.com/GrayRum/fiberclaw.com/tree/master/wp-content/plugins/js_composer

https://github.com/MacFlay/wordpress/tree/master/wp-content/plugins/js_composer

https://github.com/maccgizzle/maccg-wp-content/tree/master/themes/paragon/framework/page-composer

https://github.com/jeremiesaintgeorge/invitelepape/tree/master/ken/page-composer

https://github.com/junxiondelhi/svnindia/tree/master/wp-content/plugins/twoot-toolkit/js_composer

https://github.com/narikenabilli/Elite-Economics/tree/master/wp-content/plugins/twoot-toolkit/js_composer

https://github.com/junxiondelhi/alianceindia/tree/master/wp-content/plugins/twoot-toolkit/js_composer

https://github.com/navkakate/collabo/tree/master/wp-content/themes/Durus/framework/page-builder/js_composer

https://github.com/e4c4/stark/tree/master/content/wp-content/themes/FolioGridPro/functions/js_composer

https://github.com/skitle/HuebnerPeterson/tree/master/plugins/js_composer

https://github.com/ecanha/wp-content/tree/master/plugins/js_composer

https://github.com/nizaranand/pascaldesign/tree/master/chameleon-pro/functions/js_composer

https://github.com/kidkameleon/kidkameleon.com/tree/master/wp-content/themes/salient/wpbakery/js_composer

https://github.com/ksingh812/tkthub/tree/master/plugins/js_composer

https://github.com/colinkeany/MediaTree/tree/master/wp-content/themes/Astra/wpbakery/js_composer

https://github.com/crimsonronin/amanualforcreatingatheists/tree/master/wp-content/themes/salient/wpbakery/js_composer

https://github.com/ovidio43/mosmsmagazine/tree/master/momsmagazine/wpbakery/js_composer

https://github.com/WorkPress123/VN1234/tree/master/wp-content/themes/Newspaper/wpbakery/js_composer

https://github.com/alnafiea/dates/tree/master/wp-content/plugins/js_composer

https://github.com/disisid/nimtx1/tree/master/wp-content/themes/salient/wpbakery/js_composer

https://github.com/Prox3/DecoraKits/tree/master/wp-content/themes/shoppica/library/js_composer

https://github.com/Prox3/DecoraKits/tree/master/wp-content/themes/shoppica/library/js_composer

https://github.com/fernandhacosta/8984673892/tree/master/giant/framework/md-page-builder/lib/js_composer

https://github.com/mrkhoa99/wordpresstheme/tree/master/wp-content/plugins/js_composer

https://github.com/webbio/nul25/tree/master/wp-content/themes/salient/wpbakery/js_composer

https://github.com/kazvorpal/fu/tree/master/wp-content/themes/fu/inc/js_composer

https://github.com/BeardandFedora/spawncamping-archer/tree/master/wp-content/plugins/js_composer

https://github.com/Ellyosmark/mmmoda/tree/master/content/wp-content/plugins/js_composer

https://github.com/stratosvetsos/fardi/tree/master/wp-content/plugins/js_composer

https://github.com/tmforum/perspectives/tree/master/wp-content/plugins/js_composer

https://github.com/MacFlay/wordpress/tree/master/wp-content/plugins/js_composer

https://github.com/buildbuyer/wp-content/tree/master/plugins/js_composer

https://github.com/sallf/tag_tours/tree/master/wp-content/themes/salient/wpbakery/js_composer

https://github.com/mindswithoutfear/Test-Repo/tree/master/wp-content/plugins/js_composer

https://github.com/GrayRum/fiberclaw.com/tree/master/wp-content/plugins/js_composer

https://github.com/yerdne/pagina_scan/tree/master/wp-content/plugins/js_composer

https://github.com/jikoyster/LBF/tree/master/wp-content/themes/salient/wpbakery/js_composer

https://github.com/Webfactoo-repo/efg/tree/master/wp-content/plugins/js_composer

https://github.com/AlexanderZon/ecobed/tree/master/wp-content/themes/jupiter_3.9.3/page-composer

https://github.com/rjjb3427/salient/tree/master/wpbakery/js_composer

https://github.com/iabarcamesa/apirce/tree/master/wp-content/plugins/js_composer

https://github.com/webbio/polar-special/tree/master/wp-content/plugins/js_composer

https://github.com/cavergox/sliopress/tree/master/content/plugins/js_composer

https://github.com/andreictin/CWDCorporateSimplu/tree/master/lkjh/plugins/js_composer

https://github.com/nt46/salient/tree/master/wpbakery/js_composer

https://github.com/Calamity-Co/Yurei/tree/BugFixing/wp-content/plugins/js_composer

https://github.com/W3G/zonza/tree/master/wp-content/plugins/md-page-builder/js_composer

https://github.com/okimangelo/advansus/tree/master/wp-content/plugins/js_composer

https://github.com/sairem/forsalebyinventor/tree/master/httpdocs/wp-content/plugins/js_composer

https://github.com/gianniGG/exliam/tree/master/wordpress/wp-content/plugins/js_composer

https://github.com/technical/fidelis/tree/master/wp-content/themes/salient/wpbakery/js_composer

https://github.com/technical/fidelis/tree/master/wp-content/themes/salient/wpbakery/js_composer

https://github.com/nnhansg/langtre_wp/tree/master/wp-content/plugins/js_composer

https://github.com/ernandesferreira/elfamateriais/tree/master/wp-content/plugins/js_composer

https://github.com/prabhat-algoworks/algo/tree/master/algo/mobility-services/wp-content/plugins/js_composer

https://github.com/ilyaulyanov/owl/tree/master/wp-content/plugins/js_composer

https://github.com/visualzach/belfastguitarfest.com/tree/master/wp-content/plugins/js_composer

https://github.com/haiht24/6789/tree/master/couponX/inc/plugins/wpbakery/js_composer

https://github.com/AndreySlashman/yesnew/tree/master/wp-content/themes/dt-the7/wpbakery/js_composer

https://github.com/cyberwani/ChehFW/tree/master/framework/builder

https://github.com/GingerGear/plugins/tree/master/js_composer

https://github.com/Intensive/angelrose/tree/master/lkjh/plugins/js_composer

https://github.com/konggeyuan/u2ask/tree/master/wp-content/plugins/js_composer

https://github.com/watsonneil/wordpress/tree/master/wp-content/plugins/js_composer

https://github.com/JefVH/vinylbelgium/tree/master/wp-content/plugins/js_composer

https://github.com/tinhbuon1102/wp-content/tree/master/plugins/js_composer

https://github.com/casejamesc/wedoglutenfree/tree/master/dt-the7/wpbakery/js_composer

https://github.com/luanli22/reach/tree/master/config/public/wp-content/themes/salient/wpbakery/js_composer

https://github.com/ajayarjunan/dc/blob/master/wp-content/themes/dc_onepage/inc/plugins/wpbakery/js_composer/js_compo
ser.php

https://github.com/Technology-Hatchery/initi8tor/tree/master/wordpress/wp-content/plugins/js_composer

https://github.com/zebular13/theme2/tree/master/wpbakery/js_composer

https://github.com/manishpatel1986/manish_test/tree/master/wp-content/plugins/js_composer

https://github.com/Tobboo/testblog/tree/master/wp-content/plugins/js_composer

https://github.com/warmwhisky/ngwenyaglass/tree/master/wp-content/themes/salient0/wpbakery/js_composer

https://github.com/katharina1/stripedzebra/tree/master/wp-content/plugins/js_composer

https://github.com/jaytord/ecoforce-solutions_site/tree/master/wp-content/themes/salient/wpbakery/js_composer

https://github.com/vmorelli/tantic-inn/tree/master/wp-content/plugins/js_composer

https://github.com/linhcatcat/freelance/tree/master/wp-content/themes/saltwaterseafood/wpbakery/js_composer

https://github.com/neonsys/nexteonsite/tree/master/wp-content/plugins/js_composer

https://github.com/goodbayscott/goodbay/tree/master/dev/elisabetta/wp-content/themes/salient/wpbakery/js_composer

https://github.com/theimaginelab/sunset-gates/tree/3daa8a61bf5fe36654d2719a62659c1c0ac72c01/wp-content/themes/dt-the7/wpbakery/js_composer

https://github.com/aberrio/gs-wordpress/tree/master/wp-content/themes/flati/wpbakery/js_composer

https://github.com/gmakkinga/PenningsDiesel.nl/tree/master/wp-content/themes/salient/wpbakery/js_composer

https://github.com/Drashti-Patel/wordpress-repository/tree/mysql/wordpress/wp-content/plugins/js_composer

https://github.com/LouizEchi/Powerlink/tree/master/wp-content/plugins/js_composer

https://github.com/ogreco/TafiOscar/tree/master/wp-content/themes/liofolio/page_builder/js_composer

https://github.com/Acens/lotus/tree/master/_/public_html/wp-content/themes/jupiter/framework/wpbakery/js_composer

https://github.com/Isotex/grupoisotex/tree/alejandro/wp-content/themes/isotex_vzla_wp/admin/plugins/js_composerd

https://github.com/rootlevel/wpcom/tree/master/wp-content/themes/flexform/includes/page-builder

https://github.com/kpa6/scrolx/tree/master/www/wp-content/plugins/js_composer

https://github.com/gq-dev/gq-smart/tree/master/plugins/js_composer

https://github.com/trub/portfolio-wordpress-heroku/tree/master/wp-content/plugins/js_composer

https://github.com/MagentaRu/maxoptracom/tree/master/wp-content/themes/jupiter/page-composer

https://github.com/dannynamnum/sweetimescupcakes/tree/master/wp-content/themes/salient/wpbakery/js_composer

https://github.com/fernandoguirao/nutria/tree/master/wp-content/themes/salient/wpbakery/js_composer

https://github.com/lucilio/arquiteturas-tema-wp/tree/master/wpbakery/js_composer

https://github.com/Intensive/epoxy/tree/master/lkjh/plugins/js_composer

https://github.com/TheHealthCareConnection/healthcareconnection/tree/master/wp-content/themes/medicenter/wpbakery/js_composer

https://github.com/dylanenright/rightsideshirts/tree/master/wp-content/plugins/js_composer

https://github.com/npbtrac/NP---QLKDN/tree/master/wp-content/themes/dt-the7/wpbakery/js_composer

https://github.com/ivagueba/ParajeDiria/tree/master/IDO/paraje-diria/wp-content/plugins/js_composer_amy

https://github.com/dennisperremans/wordpress/tree/master/wp-content/plugins/js_composer

https://github.com/ericzhou1982/tadashishoji.com.cn/tree/master/wp-content/plugins/js_composer

https://github.com/selicker/LHR-Multisite-Install/tree/master/wp-content/themes/salient/wpbakery/js_composer

https://github.com/mccork91/glenbio/tree/master/wp-content/themes/giant/framework/md-page-builder/lib/js_composer

https://github.com/calvintwr/BellyWellyJelly/tree/calvin/wp-content/themes/salient/wpbakery/js_composer

https://github.com/ralphhaynes/healthqpons_blog/tree/master/wp-content/plugins/js_composer

https://github.com/shickenterprise/fourteeng_local/tree/master/wp-content/themes/silicon/inc/js_composer

https://github.com/Lynup-Agency/lynup.com/tree/master/new-wp-template/wp-content/plugins/js_composer

https://github.com/russellgreen/wordpress-themes/tree/master/powermag/inc/js_composer

https://github.com/HanxiongShi/nc-finpipe/tree/master/wp-content/plugins/js_composer

https://github.com/iexodus/mpages/tree/master/wp-content/themes/jupiter/framework/wpbakery/js_composer

https://github.com/vadia007/bigplanet/tree/master/wp-content/themes/no/river/wpbakery/js_composer

https://github.com/vadia007/bigplanet/tree/master/wp-content/themes/no/salient/wpbakery/js_composer

https://github.com/filipesilvadev/inbasket/tree/master/wp-content/themes/salient/wpbakery/js_composer

https://github.com/npbtrac/NP---ENPII/tree/master/wp-content/themes/dt-the7/wpbakery/js_composer

https://github.com/rivanov/learnit/tree/master/wp-content/plugins/js_composer

https://github.com/ifollow/pdd/tree/master/wp-content/plugins/js_composer

https://github.com/daemon2010/crossblog/tree/master/wp-content/plugins/js_composer

https://github.com/mauroswiss/smgconectados/tree/master/wp-content/plugins/js_composer

https://github.com/repo-edel/multimatics/tree/master/wp-content/themes/subway/wpbakery/js_composer

https://github.com/iojha/gbsite/tree/master/wordpress/wp-content/plugins/js_composer

https://github.com/saki1001/canaries/tree/master/wp-content/themes/flexform/includes/page-builder

https://github.com/cphillipp/bartonlawfirm/tree/master/wp-content/plugins/js_composer

https://github.com/yijinsei/thefashionstand/tree/master/wp-content/plugins/js_composer

https://github.com/Camrule/wordpress.v1/tree/master/wordpress/wp-content/themes/salient/salient/wpbakery/js_composer

https://github.com/linhcatcat/src/tree/develop/saltwaterseafood/wp-content/themes/saltwaterseafood/wpbakery/js_composer

https://github.com/lostady/incoaching/tree/master/wp-content/themes/flexform/includes/page-builder

https://github.com/kimbushik/INNO_SRC/tree/master/INNO_WEB2/siq/wp-content/themes/PressGrid/admin/composer

https://github.com/laszlofoldesi/sfweb-2013/tree/master/wp-content/themes/flexform/includes/page-builder

https://github.com/vaarmen/ArtMenia/tree/master/www/main/wp-content/themes/artland/includes/page-builder

https://github.com/aaronmarruk/ppc-website/tree/master/wp-content/plugins/js_composer

https://github.com/mfrancois/breakinggood/tree/master/app/themes/blazemag/wpbakery/js_composer

https://github.com/jruck/wp-boiler/tree/master/content/plugins/js_composer

https://github.com/gera3d/PitchTheory/tree/master/plugins/js_composer

https://github.com/connectivity-sa/connectivity-child-theme-1/tree/master/plugins-src/js_composer.zip

https://github.com/ajency/vitalwalls/tree/master/wp-content/plugins/js_composer

https://github.com/sam612/samtechpk/tree/master/wp-content/themes/samtechpk/wpbakery/js_composer

https://github.com/sunteam/microgen_the7/tree/master/wpbakery/js_composer

https://github.com/gera3d/PitchTheory/tree/master/plugins/js_composer

https://github.com/ajency/vitalwalls/tree/master/wp-content/plugins/js_composer

https://github.com/vqdesign/Responsive/tree/master/wp-content/themes/SuperTheme/inc/js_composer

https://github.com/adminbizcat/abria-full/tree/master/wp-content/themes/salient/wpbakery/js_composer

https://github.com/Ladvien/Carduino-1/tree/master/wordpress/wp-content/themes/jupiter/page-composer

https://github.com/addr/ssgt/tree/master/web/wp-content/plugins/js_composer

https://github.com/max41479/wordpress_whitewave/tree/master/wp-content/plugins/js_composer

https://github.com/vqdesign/SuperTheme/tree/master/inc/js_composer

https://github.com/dark-uk/imo_wp/tree/master/wp-content/themes/jupiter/page-composer

https://github.com/mlieberm/wordpress/tree/master/wp-content/themes/salient/wpbakery/js_composer

https://github.com/saysa/wordpress/tree/master/wp-content/plugins/js_composer

https://github.com/JebKenobi/Melannie/tree/master/plugins/js_composer

https://github.com/ajency/BenSmiley/tree/master/wp-content/themes/ben-smiley/wpbakery/js_composer

https://github.com/Bunkerboy/LeesenAfbouw.dev/tree/master/www.leesenafbouw.dev/wp-content/plugins/js_composer

https://github.com/classcompete/web_portal/tree/master/www.classcompete.com/web/content/wp-content/themes/Impreza/wpbakery/js_composer

https://github.com/balintgaspar/lupo/tree/master/web/wp-content/themes/minty/wpbakery/js_composer

https://github.com/ralphhaynes/HealthAdvantage/tree/master/wp-content/themes/medicenter/wpbakery/js_composer

https://github.com/SilvioMonnerat/Daniel-Marques/tree/master/wp-content/themes/powermag/inc/js_composer

https://github.com/addr/ssgt-wp/tree/master/wp-content/plugins/js_composer

https://github.com/henkvos/m24/tree/master/wp-content/plugins/gameplan-shortcodes/js_composer

https://github.com/growlybear/noisybeast/tree/master/themes/affix/includes/js_composer

https://github.com/awviraj/synergo-wp/tree/master/wp-content/themes/architectos/wpbakery/js_composer

https://github.com/mfrancois/breakinggood/tree/master/app/themes/blazemag/wpbakery/js_composer

https://github.com/CertusDelivery/Woo-Commerce/tree/master/wp-content/themes/salient/wpbakery/js_composer

https://github.com/izmayoub/wp-content/tree/master/plugins/js_composer

https://github.com/AlexMinaev/yo/tree/master/wp-content/plugins/js_composer

https://github.com/rmcastil/ryancastillo/tree/master/wp-content/themes/bloggy-v2-0/wpbakery/js_composer

https://github.com/philsalesses/PhilSalesses.com/tree/master/mito/framework/md-page-builder/lib/js_composer

https://github.com/aaronmarruk/ppc-website/tree/master/wp-content/plugins/js_composer

https://github.com/yogiben/startupjobsbangkok/tree/master/wp-content/themes/flati/wpbakery/js_composer

https://github.com/tinytoolbox/Tiny-Toolbox-Website-Network/tree/master/wp-content/plugins/js_composer

https://github.com/rlunden/wp-content/tree/master/plugins/js_composer

https://github.com/emmancalabroso/cebudailydiscounts/tree/master/wp-content/themes/salient/wpbakery/js_composer

https://github.com/teybannerman/teybannerman.com/tree/master/theme/wpbakery/js_composer

https://github.com/vqdesign/PACE-2012/tree/master/silicon/inc/js_composer

https://github.com/foxcomm-a/danseballonrond/tree/master/wp-content/themes/salient/wpbakery/js_composer

https://github.com/syllogic/chumma/tree/master/wordpress/wp-content/plugins/js_composer

https://github.com/CatalystLaunch/catalystlaunch.com/tree/master/wp-content/themes/salient/wpbakery/js_composer

https://github.com/jpwannabi/celadores/tree/master/wp-content/plugins/js_composer

https://github.com/Mediakik/new_summit/tree/master/wp-content/plugins/js_composer

https://github.com/madeinspace/id_website/tree/master/wp-content/plugins/js_composer

https://github.com/emmancalabroso/wpsandbox/tree/master/wp-content/themes/salient/wpbakery/js_composer

https://github.com/Denton-Bible-Church/Website/tree/master/content/themes/builder/page_builder/js_composer

https://github.com/yogiben/gospeaklearn/tree/master/wp-content/themes/flati/wpbakery/js_composer

https://github.com/sxthomson/bridgend-services/tree/master/wp-content/plugins/js_composer

https://github.com/monkeythecoder/eurest/tree/master/wp-content/plugins/js_composer

https://github.com/ralphhaynes/DocsDietId/tree/master/wp-content/plugins/js_composer

https://github.com/sits302/trendingpub/tree/master/wp-content/themes/Newspaper/Newspaper/wpbakery/js_composer

https://github.com/ProjectLogin/web/tree/master/wp-content/plugins/js_composer

https://github.com/grunners/Fenton/tree/master/wp-content/themes/salient/wpbakery/js_composer

https://github.com/allurewebsolutions/allurewebsolutions.com/tree/master/wp-content/themes/salient/wpbakery/js_composer

https://github.com/bigfacestudio/com.bfs.wp.theme.pc/tree/master/wpbakery/js_composer

https://github.com/seeff/crossfit-website-clean/tree/master/page_builder/js_composer

https://github.com/fundar/JyGV2/tree/master/wp-content/themes/salient/wpbakery/js_composer

https://github.com/ccaplette/CCMHT/tree/master/wp-content/plugins/js_composer

https://github.com/elCalvoMike/testDottlers/tree/master/htdocs/wp-content/themes/salient/wpbakery/js_composer

https://github.com/cmcrew/vrcmasters/tree/master/wordpress/wp-content/plugins/js_composer

https://github.com/bnjkhr/rcomgruppe/tree/master/wp-content/themes/old_version_salient_old/wpbakery/js_composer

https://github.com/bnjkhr/rcomgruppe/tree/master/wp-content/themes/old_version_salient_old/wpbakery/js_composer

https://github.com/pixelkings/keais/tree/master/wp-content/themes/salient/salient/wpbakery/js_composer

https://github.com/pixelkings/keais/tree/master/wp-content/themes/salient/wpbakery/js_composer

https://github.com/pixelkings/keais/tree/master/wp-content/themes_old/salient/wpbakery/js_composer

https://github.com/edvinbrobeck/V3/tree/master/wp-content/plugins/js_composer

https://github.com/ralphhaynes/AudioAdvice/tree/master/wp-content/plugins/js_composer

https://github.com/Endlesshc/wp_marli/tree/master/wp-content/plugins/js_composer

https://github.com/HarryWang74/MyDocuments/tree/master/03-code-library/wp%20theme/salient-wp-v3.0.5-weidea.net/salient/wpbakery/js_composer

https://github.com/mateomtb/wp-media-theme/tree/master/plugins/js_composer

https://github.com/calvintwr/bwj2/tree/master/wp-content/themes/salient/wpbakery/js_composer

https://github.com/zohaibmir/FlexForm/tree/master/wp-content/themes/flexform/includes/page-builder

https://github.com/gateway-church/gatewaygroups_wp/tree/master/wp-content/themes/supreme/includes/page-builder


My contact information is:

[REDACTED]

I have read and understand GitHub's Guide to Filing a DMCA Notice.

I have a good faith belief that use of the copyrighted materials described
above on the infringing web pages is not authorized by the copyright owner,
or its agent, or the law.

I swear, under penalty of perjury, that the information in this
notification is accurate and that I am the copyright owner, or am
authorized to act on behalf of the owner, of an exclusive right that is
allegedly infringed.

Signature:

[REDACTED]

Date: March 11, 2015