Dear GitHub,
On behalf of the copyright holder, I notify you of content you host that infringes upon one or more
copyrighted works, as provided by 17 U.S.C. § 512(c)(3), in the format specified by you.
1. The copyrighted works infringed upon are the COSMO software, both source codes and
related documentation, created within the ftamework of a European project Morphex.
COSMO software is the co-ownership of Ecole Normale Supérieure de Lyon France (ENS
Lyon), Centre National de la Recherche Scientifique France (CNRS), and Universitat
Stuttgart Germany (HLRS). COSMO software has been registered by a bailiff you will find
enclosed the report ofregistration.
2. Part of material available at the address https://github.com/yannicktocquet/COSMO
infringes ENS Lyon, CNRS and HLRS copyrighted works. You will find enclosed the
complete list ofthe files which infringe copyrighted works.
3. GitHub Inc. may contact the copyright holder through me at the following address:
[private] Université de Lyon, Lyon Science Transfert, M.
[private], Quartier Sergent Blandan, 37 rue du Repos, F-69361 Lyon Cedex 07,
France.
4. The owner/administrator of the infringing works is probably known to ENS Lyon, CNRS
and HLRS, but we are not sure it is the person we think of. This person as also used the
name of [private] to open the account https://github.com/yannicktocquet without
[private] authorization.
5. I have a good faith belief that use of the copyrighted materials described above on the
infringing web pages is not authorized by the copyright owners, or their agent, or the law.
6. I swear that the information in this notification is accurate, and under penalty of perjury that I am authorized to act on behalf of the owners of an exclusive right to the allegedly infringed works.

Sincerely,

[private]
Director of Lyon Science Transfert
