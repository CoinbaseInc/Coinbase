To: GITHUB

From: [private], on behalf of RhodeCode, Inc.
Re: Copyright Infringement -- DMCA Takedown Notice

https://github.com/euank/rhodecode_keygen

https://github.com/duanhongyi/rhodecode

https://github.com/moparisthebest/unlimit-code

I am writing to request GITHUB to take down the projects at the above links. RhodeCode believes these projects are making available materials that infringe RhodeCode's intellectual property rights, including its copyrights. Specifically, RhodeCode believes that its rights in the RhodeCode Enterprise 2.x source code management software have been infringed. This notice is based on a good-faith belief that the uses in these links are not authorized by RhodeCode, and are unlawful. I swear, under penalty of perjury, that the information in this notification is accurate and that I am authorized to act on behalf of RhodeCode, Inc., relating to the exclusive rights that are infringed.

Please take down these projects, and confirm by return email when you have done so. If you have questions, please contact me.

Thank you,

[private]

I can be contacted at:

[private]
O'Melveny & Myers LLP
2765 Sand Hill Road
Menlo Park, CA 94025

[private] (tel)

[private] (cell)

[private]
