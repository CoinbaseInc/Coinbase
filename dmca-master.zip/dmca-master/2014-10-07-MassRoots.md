In compliance with GitHub's DMCA Takedown Policy, I'd like to request the
following repository be removed from GitHub: 

https://github.com/danishKaushal/MassRoots-Development-2.

I am the rightful owner of the code, as is indicated by the "Copyright (c)
2013 [private]. All rights reserved." disclaimer found at the header
of nearly every file.

*The file that is most sensitive and critical to remove immediately is
"AppDelegate.m"*, found here:

https://github.com/danishKaushal/MassRoots-Development-2/blob/master/MassRoots/AppDelegate.m

You will see my name in the copyright disclaimer at the top. Additionally,
I am requesting that all files with my name included in the copyright
disclaimer be removed. I can provide the links to these individually, but
it is most critical that AppDelegate.m be taken down.

My contact information is below:

[private]

I do not have the contact information of the account owner. We were unaware
that this repository existed and it is critical that it is removed. I
believe it was uploaded without authorization by an overseas developer that
had been working for the company early on.

I have a good faith belief that use of the copyrighted materials described
above on the infringing web pages is not authorized by the copyright owner,
or its agent, or the law. I swear, under penalty of perjury, that the
information in this notification is accurate and that I am the copyright
owner, or am authorized to act on behalf of the owner, of an exclusive
right that is allegedly infringed.

Thank you,

[private]

[private]

Chief Technology Officer

MassRoots, Inc.
