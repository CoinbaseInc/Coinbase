To whom it may concern:

1)  The entire codebase for the following technology has been posted to
GIT HUB without our authorization in violation of our copyrights:

http://www.wsddev3.com/dev/npatel/ and

http://www.wsddev3.com/dev/suzzae/index.php

2)  The material which is infringing on our copyright is active on GIT
at the following URLs:  

https://github.com/WSD-Source/visnu and

https://github.com/WSD-Source/suzzae

3)  You may reach me as follows:

admin@websitedesignz.com.

[private].  

[private]

4)  The individual who has committed this theft is as follows:

[private]

5)  I have a good faith belief that use of the copyrighted materials
described above on the infringing web pages is not authorized by the
copyright owner, or its agent, or the law.

6)  I swear, under penalty of perjury, that the information in this
notification is accurate and that I am the copyright owner, or am
authorized to act on behalf of the owner, of an exclusive right that is
allegedly infringed.

Please remove our property from your site immediately.

Regards,

[private]

CEO

WebsiteDesignz.com
