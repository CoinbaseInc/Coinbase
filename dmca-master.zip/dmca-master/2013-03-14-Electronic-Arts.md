I write on behalf of Electronic Arts Inc. (“EA”).  It has come to our attention that a website hosted by you, www.github.com (the “Site”), contains material that infringes copyrights owned or controlled by EA.

Specifically, an unauthorized copy of code from EA’s SimCity video game is displayed on the Site. Pursuant to the Digital Millennium Copyright Act (“DMCA”), 17 U.S.C. Section 512(c), we demand that you immediately and permanently disable and/or block access to the infringing material, specifically located at:

https://gist.github.com/anonymous/5133829



Under penalty of perjury, I hereby affirm that I have a good faith belief that the information in this notice is accurate and that I am authorized to act on behalf of EA whose exclusive copyright rights I believe to be infringed as described herein.

This letter is not intended to be a full statement of the facts, and it does not prejudice or waive any claim, whether in law or in equity, that EA may have with respect to this matter or any other matter.

If you have any questions concerning this matter, please contact our IP enforcement group at ipenforcement@ea.com.

Sincerely,



[private]

IP Enforcement

Electronic Arts Inc.

209 Redwood Shores Parkway

Redwood City, CA 94065

+1-650-628-1500

ipenforcement@ea.com