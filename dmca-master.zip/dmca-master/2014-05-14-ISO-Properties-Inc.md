I am legal counsel for ISO Properties, Inc. ("ISO"), and am authorized to act on behalf of ISO with regard to intellectual property infringement matters.

I am writing to complain about GitHub's unauthorized display of ISO copyrighted content, namely "COMMERCIAL GENERAL LIABILITY COVERAGE FORM, COMMERCIAL GENERAL LIABILITY CG 00 01 10 01." As you will note from the copyright notice on the bottom of each page of this document, ISO owns the rights of copyright in this form.

The following URLs identifies the infringing content:

https://gist.github.com/sdpalley/8bdbeb17f7ce96dacaa6

I may be contacted at the mailing address, telephone number, and e-mail address identified in the signature block below.

I have a good faith belief that use of the copyrighted material in the manner complained of is not authorized by the copyright owner, its agent, or the law.

The information in this notification is accurate, and under penalty of perjury, I am authorized to act on behalf of ISO, the owner of an exclusive right that is being infringed.

Thank you,

[private]
