Hello,

Upon further reflection I have decided to retract these DMCA requests:

https://github.com/AdonisSaveYourLife/CS225-MP6

https://github.com/AdonisSaveYourLife/CS225-MP7

https://github.com/AdonisSaveYourLife/cs225

https://github.com/CharlieMartell/Data-Structures

https://github.com/DeathByTape/UofI_undergrad/tree/master/cs225

https://github.com/NathanTheGr8/cs225

https://github.com/arvinds94/Data-Structures

https://github.com/bpliang3/CS-225

https://github.com/cfillak/CS_225

https://github.com/dimyr7/CS225

https://github.com/hempywh/cs225

https://github.com/iamnomsyy/CS-Projects/tree/master/cs225/chen320

https://github.com/kevmaster/cs225

https://github.com/mukichou/cs225

https://github.com/rtfreedman/CourseWork/tree/master/CS225

https://github.com/sanchitgupta05/Data-Structures_MPs

https://github.com/shanecarey17/UIUC-CS/tree/master/University%20Work/CS225%20(Data%20Structures)

https://github.com/shawnwalton/CS225

https://github.com/shubhamagarwal1993/Data-Structures

https://github.com/sutravea/UIUC-CS225

https://github.com/tushdante/cs225

https://github.com/yjing7/cs225-1

https://github.com/zhuxh529/cloudDocs/tree/master/cs225

Best regards,

[private]
