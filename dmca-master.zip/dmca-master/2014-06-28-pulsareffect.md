https://github.com/baseball435/PERP
https://github.com/MagicCarpet/perp2

Your network has our PERP server files

Our Registered Copyright TXu001892243 AT us COPYRIGHT OFFICE
http://www.copyright.gov/

http://cocatalog.loc.gov/cgi-bin/Pwebrecon.cgi?DB=local&PAGE=First serch
for pulsareffect

This game of ours is on this LINK https://github.com/baseball435/PERP
AND https://github.com/MagicCarpet/perp2

I have all files to prove this is our gamemode AND LEGAL COPYRIGHT
They simply took PERP game and files and are running without a license
agreements on the above ip.

Be aware we have told them they do not have our permission to run such
and are very aware they are leaked/stolen.
This is posted on our web site as well informing all.

This letter is an official notification under Section 512(c) of the
Digital Millennium Copyright Act ("DMCA"), and I seek the removal of the
aforementioned leaked Pulsar Effect Roleplay / PERP scripts from your
servers. I request that you immediately notify anyone directly involved
with this scandal, and inform them of their duty to remove the
infringing material from your server immediately, and notify them to
cease any further posting of leaked material to your server in the
future.

Please also be advised that law requires you, as a service provider, to
remove or disable access to the infringing materials upon receiving this
notice. Under US law a service provider, such as yourself, enjoys
immunity from a copyright lawsuit provided that you act with deliberate
speed to investigate and rectify ongoing copyright infringement. If
service providers do not investigate and remove or disable the
infringing material this immunity is lost. Therefore, in order for you
to remain immune from a copyright infringement action you will need to
investigate and ultimately remove or otherwise disable the infringing
material from your servers with all due speed.

I am providing this notice in good faith and with the reasonable belief
that rights my company owns are being infringed. Under penalty of
perjury I certify that the information contained in the notification is
both true and accurate, and I have the authority to act on behalf of the
owner of the copyright(s) involved.

We will provide affidavit of all that is needed of the copyright files
in question.
The scripts are copyright with the pulsareffect.com name.
We know they have deleted the copyrights on the lua files and plan on
reverse engineering of the scripts to try to rewrite own.
Which is still against the copyright laws in USA.

The scripts are being sold and passed around on hackforums &
http://dramaunlimited.org/ If you want more proof just let me know. also
read all over facepunch.

I bought pulsareffect.com and ALL PERP copyrights coded by the original
coder who goes by hunts real name withheld.

Should you wish to discuss this with me please contact me directly.

[private]
PERP copyright TXu001892243

I have provided a small list of files involve to the source code please
keep them private as they do have new updates involved. Shows our new
and original sql and some files.
Below is Stolen software.

Copyright info is now listed on copyright site
Video proof

http://www.youtube.com/watch?v=odbjY4QuttM

More Proof from the past owner posted video back in 2008 of PERP .

http://www.facepunch.com/members/members/46850

http://pulsareffect.com/forums/topic/3040-perp-license-agreements/

Our Registered Copyright TXu001892243 AT us COPYRIGHT OFFICE
http://www.copyright.gov/

http://cocatalog.loc.gov/cgi-bin/Pwebrecon.cgi?DB=local&PAGE=First serch
for pulsareffect

huntskikbut -
Please don't message me about PE or PERP - I no longer own the rights to
either, as I sold the intellectual property and brand names to Venom who
then, AFAIK, sold to Killsick. Because the gamemodes hosted by PE were
never released to the public, the current owner of the IP holds sole
rights to host and redistribute the gamemodes.

Signed: [private]
