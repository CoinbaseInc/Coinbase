To Whom It May Concern:

I am the copyright owner of www.virtualmaintenancemanager.com

The source code for my intellectual property has been posted in a public repository on github.com at this url:

https://github.com/xinyou1003/virtualMM

The owner of this repository is known by the username Xinyou1003

https://github.com/xinyou1003

I have a good faith belief that use of the copyrighted materials described above on the infringing web pages is not authorized by the copyright owner, or its agent, or the law.

I swear, under penalty of perjury, that the information in this notification is accurate and that I am the copyright owner, or am authorized to act on behalf of the owner, of an exclusive right that is allegedly infringed.

I request that GitHub remove this repository immediately as this is not authorized by me.

You may contact me as follows:

[private]

Please contact me directly with any questions and please take action to remove this repository immediately and notify me to confirm that this has been done including proof of removal.

Kind regards,

[private]
