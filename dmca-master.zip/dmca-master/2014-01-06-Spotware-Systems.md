DMCA TAKEDOWN NOTICE

Date: 6th January, 2014

Dear GitHub Copyright Agent,

The following information serves to assert my rights and request removal of
allegedly infringing programing materials under the Digital Millennium
Copyright Act (DMCA). The following is a report, in good faith, of alleged
copyright infringement. I am contacting you as the designated agent for the
party upon which the infringing work currently appears.

I am the copyright owner of the works and the following is true and
accurate.

1. The original work in a form of obfuscated HTML5 application (trading
platform), for which I claim copyright, appears, with my permission, at the
following locations online:
http://ct.spotware.com/

2. Copies of our original copyrighted work comparison are attached
(Spotware vs. Infringing Material comparison.pdf) to assist you in your
evaluation and determination.
Please note that more than 90% of code is identical, even comments have
been re-used.

3. The allegedly infringing work appears at the following location(s)
online:
https://github.com/extensible/ui_component/

4. My contact information, as copyright holder, is as follows:

Spotware Systems Ltd
19 Stratigou Timagia,
3rd Floor,
3107 Limassol,
Cyprus, European Union

Tel: [private]
Email: [priate]
Attn. of: [private]

5. The information of the alleged copyright infringer is:
https://github.com/extensible

6. I have a good faith belief the use of the above reference copyrighted
work(s) that appears on the website for which you are the designated DMCA
agent is not authorized by the copyright owner, its agent, or by law.

I declare, under penalty of perjury, this notice is true and correct and
that I am the copyright owner entitled to exclusive rights which I allege
are being infringed.

Signed this 6th day of January, 2014 in Limassol, Cyprus
[private],
[private], Spotware Systems
