Copyright	Infringement Report	

Contact	information	 	
Recipient	Information	
	
GitHub,	Inc.	
Email: support@github.com	

Sender Information	
	
[private]	
[private]
[private]	
Email: [private]

To Whom It May Concern	 	
The	following	information	is presented for the purposes	of removing	web	contents that	infringes	on our copyright per the	Digital	Millennium Copyright	Act. I appreciate	your enforcement of	copyright	law	and	support	of our rights	in this matter.

Identification of	Copyrighted	Work	 	
CakePHP	2.x	User & Acl Management	Pro	
http://codecanyon.net/item/cakephp-2x-user-acl-management-pro/4318336	

Identification of	Infringing Work	 	
Gcba	
https://github.com/cmoeser/gcba/tree/master/compApp/downloads/userLogin	

Copyright	Infringer	Information	 	
[private]

Violation	of our Copyright	 	
Gcba publishes all source	code of	CakePHP	2.x	User & Acl Management	Pro as free. I have	never	provided permission	to public is	as free.

Copyright	Owners Statement	 	
I	have a good	faith	belief that	use	of the copyright materials described above on	the	allegedly	infringing web pages is	not	authorized by	the	copyright	owner, its agent, or the law.

I	swear, under penalty of	perjury, that	the	information	in the notification	is accurate	and	that I am	the	copyright owner	or am	authorized to	act	on behalf	of the owner of	an exclusive right that	is allegedly infringed.
	
Signed on	25th April,	2014 at	[private]

[private]
