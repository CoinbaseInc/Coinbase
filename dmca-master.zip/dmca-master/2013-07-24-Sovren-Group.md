Dear Sirs:

I am the President of Sovren Group, Inc. ("Sovren"). Sovren is the author and owner of certain software, referred to as the "Sovren Resume/CV Parser" and the "Sovren Document Converter".

We have found the above Sovren copyrighted works to be resident in the following project on your site, without permission from Sovren, and illegally: https://github.com/Manojsnovaspace/TestProject/tree/master/SourceCode/Huntable/CommonDlls/Sovren

In accordance with Section 512(c)(3) of the Copyright Act, we demand that you remove or block access to the following Sovren copyrighted content on the GitHub website, which would include materials pertaining to Sovren and its software at these locations:

https://github.com/Manojsnovaspace/TestProject/tree/master/SourceCode/Huntable/CommonDlls/Sovren/SrpAllInOne.dll<https://github.com/DavidIHunt/AutoAgent/blob/master/Src/CVProcessor/bin/Debug/SrpAllInOne.dll>

https://github.com/Manojsnovaspace/TestProject/tree/master/SourceCode/Huntable/CommonDlls/Sovren/SrpAllInOne.xml

https://github.com/Manojsnovaspace/TestProject/tree/master/SourceCode/Huntable/CommonDlls/Sovren/DocumentConversion.dll<https://github.com/DavidIHunt/AutoAgent/blob/master/Src/CVProcessor/bin/Debug/DocumentConversion.dll>

https://github.com/Manojsnovaspace/TestProject/tree/master/SourceCode/Huntable/CommonDlls/Sovren/DocumentConversion.xml

I have a good faith belief that use of the copyrighted materials described above on the infringing web pages is not authorized by the copyright owner, or its agent, or the law.

Please notify me of any other references to DocumentConversion.dll and to the SrpAllinOne.dll that may be present on your servers.

If you have any questions or need further information, please contact me at your earliest possible convenience at any of the following:

      Sovren Group, Inc., 1107 RM 1431 STE 205, Marble Falls, TX 78654
      
      [private]

I swear, under penalty of perjury, that the information in this notification is accurate and that I am the copyright owner, or am authorized to act on behalf of the owner, of an exclusive right that is allegedly infringed.

I look forward to your cooperation with respect to the copyright interests of Sovren Group, Inc.

TIME IS OF THE ESSENCE IN YOUR COMPLIANCE WITH THIS REQUEST.

This letter is without prejudice to all rights and remedies of Sovren Group, Inc., which are expressly reserved to Sovren Group, Inc.

Sincerely,
 [private]