Hi there,

I have come across a copy of a book that we sell on our web site on GitHub
on this account:

* https://github.com/wuxueying/ios7-By-Tutorials

I am writing to ask you to please take this down according to your DCMA
takedown policy: https://help.github.com/articles/dmca-takedown-policy

1) This is the book for sale on our site:
http://www.raywenderlich.com/store/ios-7-by-tutorials

2) This is the copy on GitHub:
https://github.com/wuxueying/ios7-By-Tutorials/blob/master/iOS%207%20by%20Tutorials.pdf

3) You can reach me at:

[private]

4) The owner of this account: https://github.com/wuxueying

5) I have a good faith belief that use of the copyrighted materials
described above on the infringing web pages is not authorized by the
copyright owner, or its agent, or the law.

6) I swear, under penalty of perjury, that the information in this
notification is accurate and that I am the copyright owner, or am
authorized to act on behalf of the owner, of an exclusive right that is
allegedly infringed.

7) See below.

Thanks and let me know if you need anything else,


[private]
