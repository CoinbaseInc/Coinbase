Copyright Infringement Notification

Contact Information
Copyright Owner Name: Manning Publications Co.

DMCA Agent:
[private]
Email: contact AT dmcaforce.com

The following works are the copyrighted property of Manning Publications Co.:

https://github.com/Pana/node-books

A representative list of these works is available at
http://www.manningpublications.com

I state UNDER PENALTY OF PERJURY that:

1. Manning Publications Co. is the owner of the works described above, and I am its agent authorized to act on behalf of the 
owner of an exclusive right that is allegedly infringed;

2. I have a good faith belief that the use of the material in the manner complained of is not authorized by the copyright owner,
its agent, or the law; and

3. This notification is accurate.

Nothing in this notification shall serve as a waiver of any rights or remedies of Manning Publications Co. with respect to 
the alleged infringement, all of which are expressly reserved.

[private]

Dated this 17th day of September, 2014.
