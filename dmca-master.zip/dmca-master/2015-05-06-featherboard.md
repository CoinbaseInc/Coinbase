TAKEDOWN NOTICE PURSUANT TO THE DIGITAL MILLENNIUM COPYRIGHT ACT OF 1998

Dear Sir or Madam,

This is a notice in accordance with the Digital Millennium Copyright Act
of 1998 requesting that you immediately cease to provide access to
copyrighted material.

The original material is located at the following URLs:

www.spigotmc.org/resources/featherboard.2691/

The infringing material is located at the following URLs:

https://github.com/JunkyBulgaria/FeatherBoard/

My contact information is:

[private]

I have a good faith belief that the use of the described material in the
manner complained of is not authorized by the copyright owner, its
agent, or the law.

I swear that the information in the notification is accurate and, under
penalty of perjury, that I am the copyright owner or am authorized to
act on behalf of the owner of an exclusive right that is allegedly
infringed.

Signature:

[private]

Date: May 3, 2015
