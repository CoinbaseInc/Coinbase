Please find attached to this letter a list of material removed by you pursuant to 17
U.S.C. Section 512. I have a good faith belief that this material was removed or disabled
in error as a result of mistake or misidentification of the material. I declare that this is
true and accurate under penalty of perjury under the laws of the United States of
America. 

For the purposes of this matter, I consent to the jurisdiction of the Federal District
Court for the judicial district in which the service provider may be found. I also consent to service
by the person providing notification under Section 512(c)(1)(C) or that person’s agent.
However, by this letter, I do not waive any other rights, including the ability to pursue an
action for the removal or disabling of access to this material, if wrongful.

Having complied with the requirements of Section 512(g)(3), I remind you that
you must now replace the blocked or removed material and cease disabling access to it
within fourteen business days of your receipt of this notice. Please notify me when this
has been done.

I appreciate your prompt attention to this matter. If you have any questions about
this notice, please do not hesitate to contact me.
Sincerely,
______________________________________
[private]

Enclosure
URL in question: https://github.com/hikeventures/hikeventures.github.com
