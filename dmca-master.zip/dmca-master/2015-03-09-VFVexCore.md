Hi,

My name is [REDACTED] and I am lead developer at feedbacksoft.com. I have read and understand GitHub's Guide to Filing a DMCA Notice.

A website that your company hosts (https://github.com/dilide/VFVexCore) is infringing on a copyright owned by my company.
The user forked a repository of mine that was unintentionally made public and it is still publicly available on your servers without permission. I emailed the owner of the account to take the material down and received no response. The original project, to which I own the exclusive copyrights, was briefly publicly found at:
https://github.com/slcott/VFVexCore
The unauthorized and infringing copy can be found at:
https://github.com/dilide/VFVexCore
Their contact information is:
[REDACTED]

The user must remove all files that bear the copyright of my company to satisfy my complaint.

I have a good faith belief that use of the copyrighted materials described above on the infringing web pages is not authorized by the copyright owner, or its agent, or the law.

I swear, under penalty of perjury, that the information in this notification is accurate and that I am the copyright owner, or am authorized to act on behalf of the owner, of an exclusive right that is allegedly infringed.

Thank you.

[REDACTED]
