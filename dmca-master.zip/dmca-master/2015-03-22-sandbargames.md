Dear GitHub Support & Copyright,

The following is a DMCA Takedown notice for content featured on the website www.SandbarGames.com that github is hosting. See below 9 requirements. thank you.

[REDACTED]

1. I, [REDACTED], have read and understand GitHub's Guide to Filing a DMCA Notice.

2. Multiple copyrighted images and artwork are being used without my prior written consent on www.sandbargames.com - specifically on the portfolio page listed here: www.sandbargames.com/portfolio.html. I want them removed immediately.

3. **The comic artwork included under the "Islands of Chaos" logo on the portfolio page are registered artworks I created and copyrighted in 2014 ( U.S. Copyright registration number: Pau 3-752-737) . I have included attachments to this email of relevant artwork files that correspond to the infringed artwork present on sandbargames.com . These include (but are not limited to) the Islands of Chaos app logo, the cartoon characters, background art, jungle backgrounds, fish characters, and various game icons. You can also see more examples of these artworks published on my personal site www.erikreichenbachcomics.com , and on my Twitter and Facebook pages for Islands of Chaos here: https://twitter.com/islandsofchaos & https://www.facebook.com/pages/Islands-of-Chaos/304213329770048.

4. In order to remedy the infringement the site owner [REDACTED] needs to remove all my original copyrighted artwork from www.sandbargames.com. This includes all the copyrighted images and artwork I created present in the "Islands of Chaos" section on the portfolio page.

5. My contact information:
  
  [REDACTED]

6. Contact Information of infringing party:
  
  [REDACTED]

7. I, [REDACTED], have a good faith belief that use of the copyrighted materials described above on the infringing web pages are not authorized by myself, the copyright owner, or its agent, or the law.

8. I, [REDACTED], swear, under penalty of perjury, that the information in this notification is accurate and that I am the copyright owner, or am authorized to act on behalf of the owner, of an exclusive right that is allegedly infringed.

9. My Digital Signature:

  [REDACTED]

Thank you!
