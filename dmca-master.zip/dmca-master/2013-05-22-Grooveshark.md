Dear GitHub Copyright Agent:

I, the undersigned, state UNDER PENALTY OF PERJURY that:
I am, a person injured, or an agent authorized to act on behalf of a person injured by a violation of the U.S. Copyright laws, in particular section(s) 1201(a)(2) and/or 1201(b)(1) of Title 17 of the United States Code, commonly referred to as the Digital Millennium Copyright Act, or "DMCA";

I May Be Contacted At:
Name of Injured Party : ESCAPE MEDIA GROUP, Inc. ("EMG")
Name and Title: [private], In-House Counsel
Address: 201 SE 2nd Ave Suite #201
City, State, and Zip: Gainesville, FL 32601
Email address: Legaldept@Escapemg.com
Telephone: (954) 551-0889
Fax: (727) 231-8312

I have a good faith belief that the file-downloads identified below (by URL) are unlawful under these laws because, among other things, the files circumvent effective access controls and/or copyright protection measures;

Reason:
He has taken proprietary source code from inside of our application and posted it as a GitHub project, allowing users to circumvent our proprietary code and infringe our content.
Please act expeditiously to remove the file-downloads found at the following URLs:

https://github.com/wearefractal/groovr

I have a good faith belief that the circumvention of effective access controls and/or copyright protection measures identified above is not authorized by law; and
The information in this notice is accurate.

Thank you for your kind assistance.

Truthfully,

[private]

Grooveshark.com | In-House Counsel

[private]

