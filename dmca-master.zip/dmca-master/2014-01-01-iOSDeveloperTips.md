Content on this repo is lifted directly from my blog.

Here is the infringing content:

https://github.com/jbmorley/ISUtilities/blob/master/Classes/NSString%2BMD5.m

Which is taken directly from here:

http://iosdevelopertips.com/core-services/create-md5-hash-from-nsstring-nsdata-or-file.html

Contact: [private]
[private]
[private]
[private]

I have a good faith belief that use of the copyrighted materials described
above on the infringing web pages is not authorized by the copyright owner,
or its agent, or the law.

I swear, under penalty of perjury, that the information in this
notification is accurate and that I am the copyright owner, or am
authorized to act on behalf of the owner, of an exclusive right that is
allegedly infringed.

Signed: [private]
