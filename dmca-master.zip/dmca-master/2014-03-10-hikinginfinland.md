my name is [private] and I'm the author hikinginfinland.com. I host 
my website on your servers, and am very happy with your services (and 
happily would pay for them, too).

Another website which is hosted also on your service is copying my 
intellectual property nearly 1:1 and after talking with a lawyer friend 
of mine he suggested I consult with you and bring up my case with you, 
in order that his page might be taken down. The page in question is 
called hikventures.com. The complete page was modeled after my own 
design and the two owners are copying my ideas, article layout and 
design often 1:1. Here's a few examples, also see the attached 
side-by-side comparisons:

1. My "The Week In Review" 

   http://hikinginfinland.com/2014/03/the-week-in-review-lxiii.html 

   versus their "Weekly Newsletter": 

   http://hikeventures.com/hikeventures-newsletter-25/

2. My Destinations Page: 

   http://hikinginfinland.com/destinations/ 
   
   versus their Destinations page: 
   
   http://hikeventures.com/destinations/

3. My Gear Reviews Section: 

   http://hikinginfinland.com/gear-reviews/ 

   versus their Gear Reviews Section: 

   http://hikeventures.com/gear-reviews/

4. And an example of a complete copy of my post on Calazo maps: 

  http://hikinginfinland.com/2013/06/waterproof-hiking-maps.html 

  and their version: 

  http://hikeventures.com/waterproof-maps-for-sweden/

If you browse these examples you will quickly recognize the 
similarities. Hiking in Finland will be this year five years old, and 
will be running nearly two years on Octopress and Github in the spring. 
For example the idea for my "The Week In Review" dates back to April 
2010 (http://hikinginfinland.com/2010/04/the-week-in-review.html), 
whereas they just copied idea & layout since last year. As this is my 
business, and they also are aggressively trying to monetize their 
content, I'd like them to stop. As talking with them has yielded no 
result, this is the next step to take.

My contact details are

[private]

"I have a good faith belief that use of the copyrighted materials 
described above on the infringing web pages is not authorized by the 
copyright owner, or its agent, or the law."

"I swear, under penalty of perjury, that the information in this
notification is accurate and that I am the copyright owner, or am
authorized to act on behalf of the owner, of an exclusive right that is
allegedly infringed."

I'm looking forward to hear from you and what you think about this
situation.

Have a nice weekend,

/[private]
