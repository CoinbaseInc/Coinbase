Dear GitHub Copyright Agent:

I, the undersigned, state UNDER PENALTY OF PERJURY that:

[1] I am, a person injured, or an agent authorized to act on behalf of a person injured by a violation of the U.S. Copyright laws, in particular section(s) 1201(a)(2) and/or 1201(b)(1) of Title 17 of the United States Code, commonly referred to as the Digital Millennium Copyright Act, or "DMCA";

[2] I May Be Contacted At:

Name of Injured Party: SILICON LABORATORIES INC. ("Silicon Labs") 

Name and Title: [private]

Company: SILICON LABORATORIES INC.

Address: 400 West Cesar Chavez

City, State, and Zip: Austin, Texas 78701

Email address: [private]

Telephone: [private]

Fax: [private]

[3] I have a good faith belief that the file-downloads identified below (by URL) are unlawful under these laws because, among other things, the files are unauthorized copies of Silicon Labs' copyrighted code;

[4] Reason: Content Type: "Custom Firmware" files

Violation(s): Trafficking software code that circumvents effective copyright protection measures 

[5] Please act expeditiously to remove the file-downloads found at the following URLs:

https://github.com/fards/AMlogic_Meson6_030812release/blob/master/drivers/amlogic/tuners/si2176_func.c
Code listing beginning line 30 to line 3377.

https://github.com/fards/AMlogic_Meson6_030812release/blob/master/drivers/amlogic/tuners/si2176_func.h
Code listing beginning line 22 to line 2532.

[6] I have a good faith belief that the circumvention of effective access controls and/or copyright protection measures identified above is not authorized by law; and [7] The information in this notice is accurate.
Thank you for your kind assistance.

Truthfully,

[private]
