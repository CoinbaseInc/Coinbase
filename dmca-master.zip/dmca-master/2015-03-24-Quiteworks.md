Dear Sir or Madam,

the user azeneski forked my repository Quiteworks. I took down the
repository
later, so he become the new Github owner. He hasn't made any commits though.

https://github.com/azeneski/Quiteworks

I'd like him to take down his fork of my repository. My readme states my
name,
a link to my business website and the notice *All rights reserved.*

Unfortunately, I did not found a way to contact azeneski, since his account
does not list any contact information and issues are disabled for the
repository. Generally, the user does not seem to be very active on Github.

My preferred way of communication is email. Please just respond to this mail
send from my address [REDACTED]. However, my postal address is as
follows.

[REDACTED]

I have read and understand GitHub's Guide to Filing a DMCA Notice. I have a
good faith belief that use of the copyrighted materials described above on
the
infringing web pages is not authorized by the copyright owner, or its
agent, or
the law. I swear, under penalty of perjury, that the information in this
notification is accurate and that I am the copyright owner, or am
authorized to
act on behalf of the owner, of an exclusive right that is allegedly
infringed.

Sincerely,
[REDACTED]

